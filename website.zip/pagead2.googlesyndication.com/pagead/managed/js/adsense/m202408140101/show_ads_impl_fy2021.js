(function(sttc) {
    'use strict';
    var aa, ca = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function da(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ea = da(this),
        ha = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ja = {},
        ka = {};

    function ma(a, b, c) {
        if (!c || a != null) {
            c = ka[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function na(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in ja ? f = ja : f = ea;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ha && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ca(ja, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ka[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ka[d] = ha ? ea.Symbol(d) : "$jscp$" + a + "$" + d), ca(f, ka[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var pa = typeof Object.create == "function" ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ra;
    if (ha && typeof Object.setPrototypeOf == "function") ra = Object.setPrototypeOf;
    else {
        var sa;
        a: {
            var ta = {
                    a: !0
                },
                ua = {};
            try {
                ua.__proto__ = ta;
                sa = ua.a;
                break a
            } catch (a) {}
            sa = !1
        }
        ra = sa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var va = ra;

    function wa(a, b) {
        a.prototype = pa(b.prototype);
        a.prototype.constructor = a;
        if (va) va(a, b);
        else
            for (var c in b)
                if (c != "prototype")
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Tj = b.prototype
    }
    na("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    na("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    na("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        wa(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    na("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ja.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var q = this || self;

    function ya(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = q, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    }

    function Aa(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function Ba(a) {
        var b = Aa(a);
        return b == "array" || b == "object" && typeof a.length == "number"
    }

    function Da(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function Ea(a) {
        return Object.prototype.hasOwnProperty.call(a, Fa) && a[Fa] || (a[Fa] = ++Ga)
    }
    var Fa = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        Ga = 0;

    function Ha(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function Ia(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function Ja(a, b, c) {
        Ja = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? Ha : Ia;
        return Ja.apply(null, arguments)
    }

    function Ka(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function La(a, b, c) {
        a = a.split(".");
        c = c || q;
        a[0] in c || typeof c.execScript == "undefined" || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Ma(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.Tj = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.fo = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function Oa(a) {
        return a
    };
    var Pa = {
        bn: 0,
        Zm: 1,
        Ym: 2
    };

    function Qa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Qa);
        else {
            const c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    Ma(Qa, Error);
    Qa.prototype.name = "CustomError";
    var Ra;

    function Sa(a, b) {
        a = a.split("%s");
        let c = "";
        const d = a.length - 1;
        for (let e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Qa.call(this, c + a[d])
    }
    Ma(Sa, Qa);
    Sa.prototype.name = "AssertionError";

    function Ta(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ua(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Va(a, b) {
        var c = a.length;
        const d = typeof a === "string" ? a.split("") : a;
        for (--c; c >= 0; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function Wa(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Xa(a, b) {
        const c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Ya(a, b, c) {
        let d = c;
        Ua(a, function(e, f) {
            d = b.call(void 0, d, e, f, a)
        });
        return d
    }

    function $a(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function ab(a, b) {
        return Ta(a, b) >= 0
    }

    function cb(a, b) {
        b = Ta(a, b);
        let c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function db(a, b) {
        let c = 0;
        Va(a, function(d, e) {
            b.call(void 0, d, e, a) && Array.prototype.splice.call(a, e, 1).length == 1 && c++
        })
    }

    function eb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function hb(a) {
        const b = a.length;
        if (b > 0) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function ib(a, b) {
        for (let c = 1; c < arguments.length; c++) {
            const d = arguments[c];
            if (Ba(d)) {
                const e = a.length || 0,
                    f = d.length || 0;
                a.length = e + f;
                for (let g = 0; g < f; g++) a[e + g] = d[g]
            } else a.push(d)
        }
    }

    function jb(a, b, c) {
        return arguments.length <= 2 ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }

    function kb(a, b, c) {
        c = c || lb;
        let d = 0,
            e = a.length,
            f;
        for (; d < e;) {
            const g = d + (e - d >>> 1);
            let h;
            h = c(b, a[g]);
            h > 0 ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function mb(a, b) {
        if (!Ba(a) || !Ba(b) || a.length != b.length) return !1;
        const c = a.length,
            d = nb;
        for (let e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    }

    function lb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function nb(a, b) {
        return a === b
    }

    function pb(a) {
        const b = [];
        for (let c = 0; c < arguments.length; c++) {
            const d = arguments[c];
            if (Array.isArray(d))
                for (let e = 0; e < d.length; e += 8192) {
                    const f = pb.apply(null, jb(d, e, e + 8192));
                    for (let g = 0; g < f.length; g++) b.push(f[g])
                } else b.push(d)
        }
        return b
    }

    function qb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; c > 0; c--) {
            const d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };
    var rb = {
        fk: "google_adtest",
        jk: "google_ad_client",
        tk: "google_ad_intent_query",
        sk: "google_ad_intent_qetid",
        rk: "google_ad_intent_eids",
        kk: "google_ad_format",
        mk: "google_ad_height",
        Ek: "google_ad_width",
        uk: "google_ad_layout",
        vk: "google_ad_layout_key",
        wk: "google_ad_output",
        xk: "google_ad_region",
        Ak: "google_ad_slot",
        Ck: "google_ad_type",
        Dk: "google_ad_url",
        Bl: "google_gl",
        Ql: "google_enable_ose",
        am: "google_full_width_responsive",
        en: "google_rl_filtering",
        dn: "google_rl_mode",
        fn: "google_rt",
        cn: "google_rl_dest_url",
        Hm: "google_max_radlink_len",
        Mm: "google_num_radlinks",
        Nm: "google_num_radlinks_per_unit",
        ik: "google_ad_channel",
        Gm: "google_max_num_ads",
        Im: "google_max_responsive_height",
        il: "google_color_border",
        Pl: "google_enable_content_recommendations",
        yl: "google_content_recommendation_ui_type",
        xl: "google_source_type",
        wl: "google_content_recommendation_rows_num",
        vl: "google_content_recommendation_columns_num",
        ul: "google_content_recommendation_ad_positions",
        zl: "google_content_recommendation_use_square_imgs",
        kl: "google_color_link",
        jl: "google_color_line",
        ml: "google_color_url",
        gk: "google_ad_block",
        zk: "google_ad_section",
        hk: "google_ad_callback",
        el: "google_captcha_token",
        ll: "google_color_text",
        Qk: "google_alternate_ad_url",
        qk: "google_ad_host_tier_id",
        fl: "google_city",
        nk: "google_ad_host",
        pk: "google_ad_host_channel",
        Rk: "google_alternate_color",
        gl: "google_color_bg",
        Rl: "google_encoding",
        Yl: "google_font_face",
        cm: "google_hints",
        sm: "google_image_size",
        Jm: "google_mtl",
        Kn: "google_cpm",
        rl: "google_contents",
        Km: "google_native_settings_key",
        Al: "google_country",
        Cn: "google_targeting",
        Zl: "google_font_size",
        Gl: "google_disable_video_autoplay",
        Yn: "google_video_product_type",
        Xn: "google_video_doc_id",
        Wn: "google_cust_gender",
        wn: "google_cust_lh",
        vn: "google_cust_l",
        Jn: "google_tfs",
        ym: "google_kw",
        zn: "google_tag_for_child_directed_treatment",
        An: "google_tag_for_under_age_of_consent",
        hn: "google_region",
        Dl: "google_cust_criteria",
        yk: "google_safe",
        Cl: "google_ctr_threshold",
        jn: "google_resizing_allowed",
        ln: "google_resizing_width",
        kn: "google_resizing_height",
        Vn: "google_cust_age",
        Bm: "google_language",
        zm: "google_kw_type",
        Vm: "google_pucrd",
        Tm: "google_page_url",
        Bn: "google_tag_partner",
        qn: "google_restrict_data_processing",
        bk: "google_adbreak_test",
        lk: "google_ad_frequency_hint",
        dk: "google_admob_interstitial_slot",
        ek: "google_admob_rewarded_slot",
        ck: "google_admob_ads_only",
        Bk: "google_ad_start_delay_hint",
        Fm: "google_max_ad_content_rating",
        Xm: "google_ad_public_floor",
        Wm: "google_ad_private_floor",
        Un: "google_traffic_source",
        Qm: "google_overlays",
        Um: "google_privacy_treatments",
        xn: "google_special_category_data",
        Zn: "google_wrap_fullscreen_ad"
    };

    function sb(a, b) {
        this.g = a === tb && b || "";
        this.i = ub
    }
    sb.prototype.toString = function() {
        return this.g
    };

    function vb(a) {
        return a instanceof sb && a.constructor === sb && a.i === ub ? a.g : "type_error:Const"
    }
    var ub = {},
        tb = {};

    function wb() {
        return !1
    }

    function xb() {
        return !0
    }

    function yb(a) {
        const b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function zb(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function Ab(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Bb(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    }

    function Cb(a, b) {
        let c = 0;
        return function(d) {
            q.clearTimeout(c);
            const e = arguments;
            c = q.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function Db(a, b) {
        function c() {
            e = q.setTimeout(d, 63);
            let h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        let e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };
    var Eb = {
            passive: !0
        },
        Fb = Ab(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                q.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Gb(a) {
        return a ? a.passive && Fb() ? a : a.capture || !1 : !1
    }

    function Hb(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, Gb(d)), !0) : !1
    }

    function Ib(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, Gb(d)), !0) : !1
    };

    function Jb(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Kb(a) {
        var b = Lb;
        a: {
            for (const c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function Mb(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function Nb(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const Ob = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Pb(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < Ob.length; f++) c = Ob[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var Qb = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };

    function Rb(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function Sb(a) {
        if (!Tb.test(a)) return a;
        a.indexOf("&") != -1 && (a = a.replace(Ub, "&amp;"));
        a.indexOf("<") != -1 && (a = a.replace(Vb, "&lt;"));
        a.indexOf(">") != -1 && (a = a.replace(Wb, "&gt;"));
        a.indexOf('"') != -1 && (a = a.replace(Xb, "&quot;"));
        a.indexOf("'") != -1 && (a = a.replace(Yb, "&#39;"));
        a.indexOf("\x00") != -1 && (a = a.replace(Zb, "&#0;"));
        return a
    }
    var Ub = /&/g,
        Vb = /</g,
        Wb = />/g,
        Xb = /"/g,
        Yb = /'/g,
        Zb = /\x00/g,
        Tb = /[\x00&<>"']/;

    function $b(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };
    var ac;

    function bc() {
        if (ac === void 0) {
            var a = null,
                b = q.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: Oa,
                        createScript: Oa,
                        createScriptURL: Oa
                    })
                } catch (c) {
                    q.console && q.console.error(c.message)
                }
                ac = a
            } else ac = a
        }
        return ac
    };
    var cc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function dc(a) {
        return a instanceof cc && a.constructor === cc ? a.g : "type_error:TrustedResourceUrl"
    }

    function ec(a, b) {
        var c = vb(a);
        if (!fc.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(gc, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof sb ? vb(d) : encodeURIComponent(String(d))
        });
        return hc(a)
    }
    var gc = /%{(\w+)}/g,
        fc = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i"),
        ic = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;

    function jc(a, b) {
        a = ec(new sb(tb, "https://fundingchoicesmessages.google.com/i/%{id}"), a);
        a = ic.exec(dc(a).toString());
        const c = a[3] || "";
        return hc(a[1] + kc("?", a[2] || "", b) + kc("#", c))
    }
    var lc = {};

    function hc(a) {
        const b = bc();
        a = b ? b.createScriptURL(a) : a;
        return new cc(a, lc)
    }

    function kc(a, b, c) {
        if (c == null) return b;
        if (typeof c === "string") return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    g != null && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var mc = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g
            }
        },
        nc = new mc("about:invalid#zClosurez");

    function oc(a) {
        if (a instanceof mc) return a.g;
        throw Error("");
    };
    class pc {
        constructor(a) {
            this.gj = a
        }
    }

    function qc(a) {
        return new pc(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const rc = [qc("data"), qc("http"), qc("https"), qc("mailto"), qc("ftp"), new pc(a => /^[^:]*([/?#]|$)/.test(a))];

    function sc(a, b = rc) {
        if (a instanceof mc) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof pc && d.gj(a)) return new mc(a)
        }
    }

    function tc(a) {
        return sc(a, rc) || nc
    }
    var uc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function vc(a) {
        if (uc.test(a)) return a
    }

    function wc(a) {
        return a instanceof mc ? oc(a) : vc(a)
    };
    var xc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function yc(a) {
        if (a instanceof xc) return a.g;
        throw Error("");
    };
    var zc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Ac(a) {
        if (a instanceof zc) return a.g;
        throw Error("");
    };
    var Bc = new xc("");

    function Cc(a) {
        if (a instanceof mc) return 'url("' + a.toString().replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
        if (a instanceof sb) a = vb(a);
        else {
            a = String(a);
            var b = a.replace(Dc, "$1").replace(Dc, "$1").replace(Ec, "url");
            if (Fc.test(b)) {
                if (b = !Gc.test(a)) {
                    let c = b = !0;
                    for (let d = 0; d < a.length; d++) {
                        const e = a.charAt(d);
                        e == "'" && c ? b = !b : e == '"' && b && (c = !c)
                    }
                    b = b && c && Hc(a)
                }
                a = b ? Ic(a) : "zClosurez"
            } else a = "zClosurez"
        }
        if (/[{;}]/.test(a)) throw new Sa("Value does not allow [{;}], got: %s.", [a]);
        return a
    }

    function Hc(a) {
        let b = !0;
        const c = /^[-_a-zA-Z0-9]$/;
        for (let d = 0; d < a.length; d++) {
            const e = a.charAt(d);
            if (e == "]") {
                if (b) return !1;
                b = !0
            } else if (e == "[") {
                if (!b) return !1;
                b = !1
            } else if (!b && !c.test(e)) return !1
        }
        return b
    }
    const Fc = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
        Ec = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g"),
        Dc = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g"),
        Gc = /\/\*/;

    function Ic(a) {
        return a.replace(Ec, (b, c, d, e) => {
            let f = "";
            d = d.replace(/^(['"])(.*)\1$/, (g, h, k) => {
                f = h;
                return k
            });
            b = tc(d).toString();
            return c + f + b + f + e
        })
    };
    const Jc = {};

    function Kc(a) {
        return a instanceof Lc && a.constructor === Lc ? a.g : "type_error:SafeHtml"
    }

    function Mc(a) {
        const b = bc();
        a = b ? b.createHTML(a) : a;
        return new Lc(a, Jc)
    }

    function Nc(a) {
        var b = Oc;
        b = b instanceof Lc ? b : Mc(Sb(String(b)));
        const c = [],
            d = e => {
                Array.isArray(e) ? e.forEach(d) : (e = e instanceof Lc ? e : Mc(Sb(String(e))), c.push(Kc(e).toString()))
            };
        a.forEach(d);
        return Mc(c.join(Kc(b).toString()))
    }

    function Pc(a) {
        return Nc(Array.prototype.slice.call(arguments))
    }
    class Lc {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    }
    const Qc = /^[a-zA-Z0-9-]+$/,
        Rc = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        Sc = {
            APPLET: !0,
            BASE: !0,
            EMBED: !0,
            IFRAME: !0,
            LINK: !0,
            MATH: !0,
            META: !0,
            OBJECT: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        };
    var Oc = new Lc(q.trustedTypes && q.trustedTypes.emptyHTML || "", Jc);
    var Tc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Uc(a) {
        return new Tc(a[0].toLowerCase())
    };

    function Vc(a) {
        return new zc(a[0])
    };

    function Wc(a) {
        var b = {};
        if (a instanceof Lc) return a;
        a = Xc(String(a));
        b.ro && (a = a.replace(/(^|[\r\n\t ]) /g, "$1&#160;"));
        b.qo && (a = a.replace(/(\r\n|\n|\r)/g, "<br>"));
        b.so && (a = a.replace(/(\t+)/g, '<span style="white-space:pre">$1</span>'));
        return Mc(a)
    }

    function Xc(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    }

    function Yc(a) {
        const b = Wc("");
        return Mc(a.map(c => Kc(Wc(c))).join(Kc(b).toString()))
    }
    const Zc = /^[a-z][a-z\d-]*$/i,
        $c = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var ad = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const bd = ["action", "formaction", "href"];

    function cd(a, b) {
        if (!Zc.test("body")) throw Error("");
        if ($c.indexOf("BODY") !== -1) throw Error("");
        let c = "<body";
        a && (c += dd(a));
        Array.isArray(b) || (b = b === void 0 ? [] : [b]);
        ad.indexOf("BODY") !== -1 ? c += ">" : (a = Yc(b.map(d => d instanceof Lc ? d : Wc(String(d)))), c += ">" + a.toString() + "</body>");
        return Mc(c)
    }

    function dd(a) {
        var b = "";
        const c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!Zc.test(d)) throw Error("");
            if (e !== void 0 && e !== null) {
                if (/^on/i.test(d)) throw Error("");
                bd.indexOf(d.toLowerCase()) !== -1 && (e = e instanceof mc ? e.toString() : vc(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${Wc(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function ed(a) {
        const b = a.split(/\?|#/),
            c = /\?/.test(a) ? "?" + b[1] : "";
        return {
            path: b[0],
            params: c,
            hash: /#/.test(a) ? "#" + (c ? b[2] : b[1]) : ""
        }
    }

    function fd(a, ...b) {
        if (b.length === 0) return hc(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return hc(c)
    }

    function gd(a, b) {
        a = ed(dc(a).toString());
        let c = a.params,
            d = c.length ? "&" : "?";
        b.forEach((e, f) => {
            e = e instanceof Array ? e : [e];
            for (let g = 0; g < e.length; g++) {
                const h = e[g];
                h !== null && h !== void 0 && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return hc(a.path + c + a.hash)
    };

    function hd(a, ...b) {
        let c = a[0];
        for (let d = 0; d < a.length - 1; d++) c += String(b[d]) + a[d + 1];
        if (/[<>]/.test(c)) throw Error("Forbidden characters in style string: " + c);
        return new xc(c)
    };
    var id = Ab(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = Kc(Oc);
        return !b.parentElement
    });

    function jd(a, b) {
        if (id())
            for (; a.lastChild;) a.removeChild(a.lastChild);
        a.innerHTML = Kc(b)
    }
    var kd = /^[\w+/_-]+[=]{0,2}$/;

    function ld(a, b, c) {
        return Math.min(Math.max(a, b), c)
    }

    function md(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function nd(a) {
        return md.apply(null, arguments) / arguments.length
    };

    function od(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    od.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    od.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    od.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    od.prototype.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function pd(a, b) {
        this.width = a;
        this.height = b
    }

    function qd(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    aa = pd.prototype;
    aa.aspectRatio = function() {
        return this.width / this.height
    };
    aa.isEmpty = function() {
        return !(this.width * this.height)
    };
    aa.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    aa.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function rd(a) {
        var b = tc("#");
        b = wc(b);
        b !== void 0 && (a.href = b)
    };

    function sd(a, b, c) {
        var d = [Uc `width`, Uc `height`];
        if (d.length === 0) throw Error("");
        d = d.map(f => {
            if (f instanceof Tc) f = f.g;
            else throw Error("");
            return f
        });
        const e = b.toLowerCase();
        if (d.every(f => e.indexOf(f) !== 0)) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    };

    function td(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };

    function ud(a, b) {
        a.src = dc(b);
        (void 0) ? .po || (b = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };

    function vd(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };

    function wd(a, b) {
        const c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        let d;
        d = b ? b.createElement("div") : q.document.createElement("div");
        return a.replace(xd, function(e, f) {
            var g = c[e];
            if (g) return g;
            f.charAt(0) == "#" && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            if (!g) {
                g = Mc(e + " ");
                if (d.nodeType === 1 && (f = d.tagName, f === "SCRIPT" || f === "STYLE")) throw Error("");
                d.innerHTML = Kc(g);
                g = d.firstChild.nodeValue.slice(0, -1)
            }
            return c[e] = g
        })
    }
    var xd = /&([^;\s<&]+);?/g;

    function yd(a) {
        let b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function zd(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function Ad(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var Bd = ya(610401301, !1),
        Cd = ya(645172343, ya(1, !0));

    function Dd() {
        var a = q.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Ed;
    const Fd = q.navigator;
    Ed = Fd ? Fd.userAgentData || null : null;

    function Gd(a) {
        return Bd ? Ed ? Ed.brands.some(({
            brand: b
        }) => b && b.indexOf(a) != -1) : !1 : !1
    }

    function t(a) {
        return Dd().indexOf(a) != -1
    };

    function Hd() {
        return Bd ? !!Ed && Ed.brands.length > 0 : !1
    }

    function Id() {
        return Hd() ? !1 : t("Opera")
    }

    function Jd() {
        return Hd() ? !1 : t("Trident") || t("MSIE")
    }

    function Kd() {
        return t("Firefox") || t("FxiOS")
    }

    function Ld() {
        return t("Safari") && !(Od() || (Hd() ? 0 : t("Coast")) || Id() || (Hd() ? 0 : t("Edge")) || (Hd() ? Gd("Microsoft Edge") : t("Edg/")) || (Hd() ? Gd("Opera") : t("OPR")) || Kd() || t("Silk") || t("Android"))
    }

    function Od() {
        return Hd() ? Gd("Chromium") : (t("Chrome") || t("CriOS")) && !(Hd() ? 0 : t("Edge")) || t("Silk")
    }

    function Pd() {
        return t("Android") && !(Od() || Kd() || Id() || t("Silk"))
    };

    function Qd(a) {
        Qd[" "](a);
        return a
    }
    Qd[" "] = function() {};

    function Rd(a, b) {
        try {
            return Qd(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Sd = Jd(),
        Td = t("Edge") || Sd,
        Ud = t("Gecko") && !($b(Dd(), "WebKit") && !t("Edge")) && !(t("Trident") || t("MSIE")) && !t("Edge"),
        Vd = $b(Dd(), "WebKit") && !t("Edge");

    function Wd(a) {
        return a ? new Xd(Yd(a)) : Ra || (Ra = new Xd)
    }

    function Zd(a) {
        a = a.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        return new pd(a.clientWidth, a.clientHeight)
    }

    function $d(a) {
        var b = a.scrollingElement ? a.scrollingElement : Vd || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
        a = a.defaultView;
        return new od(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
    }

    function ae(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function be(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    }

    function Yd(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    }
    var ce = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        de = {
            IMG: " ",
            BR: "\n"
        };

    function ee(a) {
        var b = [];
        fe(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        a != " " && (a = a.replace(/^\s*/, ""));
        return a
    }

    function fe(a, b, c) {
        if (!(a.nodeName in ce))
            if (a.nodeType == 3) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in de) b.push(de[a.nodeName]);
        else
            for (a = a.firstChild; a;) fe(a, b, c), a = a.nextSibling
    }

    function ge(a, b, c) {
        if (!b && !c) return null;
        var d = b ? String(b).toUpperCase() : null;
        return he(a, function(e) {
            return (!d || e.nodeName == d) && (!c || typeof e.className === "string" && ab(e.className.split(/\s+/), c))
        })
    }

    function he(a, b) {
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function Xd(a) {
        this.g = a || q.document || document
    }
    aa = Xd.prototype;
    aa.Bh = function(a) {
        var b = this.g;
        return typeof a === "string" ? b.getElementById(a) : a
    };
    aa.ak = Xd.prototype.Bh;

    function ie(a, b) {
        return ae(a.g, b)
    }

    function je(a, b) {
        var c = a.g;
        a = ae(c, "DIV");
        jd(a, b);
        if (a.childNodes.length == 1) b = a.removeChild(a.firstChild);
        else
            for (b = c.createDocumentFragment(); a.firstChild;) b.appendChild(a.firstChild);
        return b
    }
    aa.da = function() {
        return this.g.defaultView
    };
    aa.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };
    aa.Ki = function(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (c == 1) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    };

    function ke() {
        return Bd && Ed ? Ed.mobile : !le() && (t("iPod") || t("iPhone") || t("Android") || t("IEMobile"))
    }

    function le() {
        return Bd && Ed ? !Ed.mobile && (t("iPad") || t("Android") || t("Silk")) : t("iPad") || t("Android") && !t("Mobile") || t("Silk")
    };
    var me = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function ne(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        c < 0 && (c = a.length);
        var d = a.indexOf("?");
        if (d < 0 || d > c) {
            d = c;
            var e = ""
        } else e = a.substring(d + 1, c);
        a = [a.slice(0, d), e, a.slice(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }

    function oe(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) oe(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    };

    function pe(a) {
        try {
            return !!a && a.location.href != null && Rd(a, "foo")
        } catch {
            return !1
        }
    }

    function qe(a, b = q) {
        b = re(b);
        let c = 0;
        for (; b && c++ < 40 && !a(b);) b = re(b)
    }

    function re(a) {
        try {
            const b = a.parent;
            if (b && b != a) return b
        } catch {}
        return null
    }

    function se(a) {
        return pe(a.top) ? a.top : null
    }

    function te(a, b) {
        const c = ue("SCRIPT", a);
        ud(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function ve(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function we() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function xe(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function ye(a) {
        const b = [];
        xe(a, function(c) {
            b.push(c)
        });
        return b
    }

    function ze(a) {
        const b = a.length;
        if (b == 0) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    }
    var Be = Ab(() => $a(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Ae) || Math.random() < 1E-4);
    const Ae = a => Dd().indexOf(a) != -1;
    var Ce = /^([0-9.]+)px$/,
        De = /^(-?[0-9.]{1,30})$/;

    function Ee(a) {
        if (!De.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function Fe(a) {
        return (a = Ce.exec(a)) ? +a[1] : null
    }
    var Ge = {
        Fk: "allow-forms",
        Gk: "allow-modals",
        Hk: "allow-orientation-lock",
        Ik: "allow-pointer-lock",
        Jk: "allow-popups",
        Kk: "allow-popups-to-escape-sandbox",
        Lk: "allow-presentation",
        Mk: "allow-same-origin",
        Nk: "allow-scripts",
        Ok: "allow-top-navigation",
        Pk: "allow-top-navigation-by-user-activation"
    };
    const He = Ab(() => ye(Ge));

    function Ie() {
        var a = ["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"];
        const b = He();
        return a.length ? Wa(b, c => !ab(a, c)) : b
    }

    function Je() {
        const a = ue("IFRAME"),
            b = {};
        Ua(He(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var Ke = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        Le = (a, b) => {
            for (let c = 0; c < 50; ++c) {
                if (Ke(a, b)) return a;
                if (!(a = re(a))) break
            }
            return null
        },
        Me = Ab(() => ke() ? 2 : le() ? 1 : 0),
        u = (a, b) => {
            xe(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        Oe = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                const c = a.length;
                for (let d = 0; d < c; d++) {
                    const e = a[d];
                    b(a[e], e, a)
                }
            } else a = Ne(a.style.cssText), xe(a, b)
        },
        Ne = a => {
            const b = {};
            if (a) {
                const c = /\s*:\s*/;
                Ua((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d &&
                            e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        Pe = a => {
            const b = /!\s*important/i;
            Oe(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const Qe = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        Re = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        Se = /.*domain\.test$/,
        Te = /\.prod\.google\.com(:\d+)?$/;
    var Ue = a => Qe[a] || Re.test(a) || Se.test(a) || Te.test(a);
    let Ve = [];
    const We = () => {
        const a = Ve;
        Ve = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var Xe = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        Ye = (a, b) => {
            if (typeof a.goog_pvsid !== "number") try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Xe(),
                    configurable: !1
                })
            } catch (c) {
                b && b.ba(784, c)
            }
            a = Number(a.goog_pvsid);
            b && (!a || a <= 0) && b.ba(784, Error(`Invalid correlator, ${a}`));
            return a || -1
        },
        Ze = (a, b) => {
            a.document.readyState === "complete" ? (Ve.push(b), Ve.length == 1 && (window.Promise ? Promise.resolve().then(We) : window.setImmediate ? setImmediate(We) : setTimeout(We, 0))) : a.addEventListener("load", b)
        },
        $e = (a,
            b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function ue(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    }
    var af = a => {
            let b = a;
            for (; a && a != a.parent;) a = a.parent, pe(a) && (b = a);
            return b
        },
        cf = a => Od() && ke() ? bf(a) : 1,
        bf = a => {
            var b = se(a);
            if (!b) return 1;
            a = Me() === 0;
            const c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
                d = b.innerWidth;
            b = b.outerWidth;
            if (d === 0) return 1;
            const e = Math.round((b / d + Number.EPSILON) * 100) / 100;
            return e === 1 ? 1 : a || c ? e : Math.round((b / d / .4 + Number.EPSILON) * 100) / 100
        };

    function df(a) {
        q.setTimeout(() => {
            throw a;
        }, 0)
    };
    Pd();
    Od();
    Ld();
    var ef = {},
        ff = null;

    function gf(a) {
        var b = 3;
        b === void 0 && (b = 0);
        hf();
        b = ef[b];
        const c = Array(Math.floor(a.length / 3)),
            d = b[64] || "";
        let e = 0,
            f = 0;
        for (; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function jf(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        return gf(b)
    }

    function kf(a) {
        var b = [];
        lf(a, function(c) {
            b.push(c)
        });
        return b
    }

    function lf(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = ff[l];
                if (m != null) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return k
        }
        hf();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function hf() {
        if (!ff) {
            ff = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                var d = a.concat(b[c].split(""));
                ef[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    ff[f] === void 0 && (ff[f] = e)
                }
            }
        }
    };

    function mf(a) {
        let b = "",
            c = 0;
        const d = a.length - 10240;
        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    }
    const nf = /[-_.]/g,
        of = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function pf(a) {
        return of[a] || ""
    }

    function qf(a) {
        return a != null && a instanceof Uint8Array
    }
    var rf = {},
        sf = typeof structuredClone != "undefined";
    let tf;

    function uf(a) {
        if (a !== rf) throw Error("illegal external caller");
    }

    function vf() {
        return tf || (tf = new wf(null, rf))
    }
    var wf = class {
        constructor(a, b) {
            uf(b);
            this.g = a;
            if (a != null && a.length === 0) throw Error("ByteString should be constructed with non-empty values");
        }
        isEmpty() {
            return this.g == null
        }
    };
    let xf = 0,
        yf = 0;

    function zf(a) {
        const b = a >>> 0;
        xf = b;
        yf = (a - b) / 4294967296 >>> 0
    }

    function Af(a) {
        if (a < 0) {
            zf(-a);
            a = xf;
            var b = yf;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            const [c, d] = [a, b];
            xf = c >>> 0;
            yf = d >>> 0
        } else zf(a)
    }

    function Bf(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Cf() {
        var a = xf,
            b = yf,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Bf(a, b);
        return c
    }

    function Df(a) {
        a.length < 16 ? Af(Number(a)) : (a = BigInt(a), xf = Number(a & BigInt(4294967295)) >>> 0, yf = Number(a >> BigInt(32) & BigInt(4294967295)))
    };

    function Ef(a) {
        return Array.prototype.slice.call(a)
    };
    var v = Symbol(),
        Ff = Symbol(),
        Gf = Symbol(),
        Hf = Symbol(),
        If = Symbol(),
        Jf = Symbol();

    function Kf(a) {
        if (4 & a) return 4096 & a ? 4096 : 8192 & a ? 8192 : 0
    }

    function Lf(a) {
        return !!((a[v] | 0) & 2)
    }

    function Mf(a) {
        a[v] |= 34;
        return a
    }

    function Nf(a) {
        a[v] |= 32;
        return a
    }

    function Of(a, b) {
        b[v] = (a | 0) & -14591
    }

    function Pf(a, b) {
        b[v] = (a | 34) & -14557
    };
    var Qf = {},
        Rf = {};

    function Sf(a) {
        return !(!a || typeof a !== "object" || a.kj !== Rf)
    }

    function Tf(a) {
        return a !== null && typeof a === "object" && !Array.isArray(a) && a.constructor === Object
    }

    function Uf(a, b, c) {
        if (a != null)
            if (typeof a === "string") a = a ? new wf(a, rf) : vf();
            else if (a.constructor !== wf)
            if (qf(a)) a = a.length ? new wf(c ? a : new Uint8Array(a), rf) : vf();
            else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    }

    function Vf(a) {
        return !Array.isArray(a) || a.length ? !1 : (a[v] | 0) & 1 ? !0 : !1
    }
    var Wf;
    const Xf = [];
    Xf[v] = 55;
    Wf = Object.freeze(Xf);

    function Yf(a) {
        if (a & 2) throw Error();
    }
    class Zf {
        constructor(a, b, c) {
            this.j = 0;
            this.g = a;
            this.i = b;
            this.l = c
        }
        next() {
            if (this.j < this.g.length) {
                const a = this.g[this.j++];
                return {
                    done: !1,
                    value: this.i ? this.i.call(this.l, a) : a
                }
            }
            return {
                done: !0,
                value: void 0
            }
        }[Symbol.iterator]() {
            return new Zf(this.g, this.i, this.l)
        }
    }
    var $f = Object.freeze({});
    Object.freeze({});
    var fg = Object.freeze({});
    let gg, hg;

    function ig(a) {
        if (hg) throw Error("");
        hg = b => {
            q.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function jg(a) {
        if (hg) try {
            hg(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function kg() {
        const a = Error();
        vd(a, "incident");
        hg ? jg(a) : df(a)
    }

    function lg(a) {
        a = Error(a);
        vd(a, "warning");
        jg(a);
        return a
    }

    function mg(a, b) {
        if (b != null) {
            var c;
            a == null ? c = gg ? ? (gg = {}) : c = a.constructor;
            a = c[b] || 0;
            a >= 4 || (c[b] = a + 1, kg())
        }
    };

    function ng(a, b) {
        const c = og;
        if (!b(a)) throw b = (typeof c === "function" ? c() : c) ? .concat("\n") ? ? "", Error(b + String(a));
    }

    function pg(a) {
        a.mo = !0;
        return a
    }
    let og = void 0;
    const qg = pg(a => a !== null && a !== void 0);
    var rg = pg(a => typeof a === "number"),
        sg = pg(a => typeof a === "string"),
        tg = pg(a => a === void 0);

    function ug() {
        var a = vg;
        return pg(b => {
            for (const c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    }
    var wg = pg(a => !!a && (typeof a === "object" || typeof a === "function"));

    function xg(a) {
        a.ej = !0;
        return a
    };

    function yg(a) {
        if (sg(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (rg(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var Bg = pg(a => a >= zg && a <= Ag);
    const zg = BigInt(Number.MIN_SAFE_INTEGER),
        Ag = BigInt(Number.MAX_SAFE_INTEGER);

    function Cg(a) {
        if (a != null && typeof a !== "number") throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function Dg(a) {
        if (typeof a !== "boolean") throw Error(`Expected boolean but got ${Aa(a)}: ${a}`);
        return a
    }
    const Eg = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Fg(a) {
        const b = typeof a;
        switch (b) {
            case "bigint":
                return !0;
            case "number":
                return Number.isFinite(a)
        }
        return b !== "string" ? !1 : Eg.test(a)
    }

    function Gg(a) {
        if (!Number.isFinite(a)) throw lg("enum");
        return a | 0
    }

    function Hg(a) {
        return a == null ? a : Gg(a)
    }

    function Ig(a) {
        return a == null ? a : Number.isFinite(a) ? a | 0 : void 0
    }

    function Jg(a) {
        if (typeof a !== "number") throw lg("int32");
        if (!Number.isFinite(a)) throw lg("int32");
        return a | 0
    }

    function Kg(a) {
        if (a == null) return a;
        if (typeof a === "string") {
            if (!a) return;
            a = +a
        }
        if (typeof a === "number") return Number.isFinite(a) ? a | 0 : void 0
    }

    function Lg(a) {
        if (typeof a !== "number") throw lg("uint32");
        if (!Number.isFinite(a)) throw lg("uint32");
        return a >>> 0
    }

    function Mg(a) {
        if (a == null) return a;
        if (typeof a === "string") {
            if (!a) return;
            a = +a
        }
        if (typeof a === "number") return Number.isFinite(a) ? a >>> 0 : void 0
    }

    function Ng(a, b = 0) {
        if (!Fg(a)) throw lg("int64");
        const c = typeof a;
        switch (b) {
            case 4096:
                switch (c) {
                    case "string":
                        return Og(a);
                    case "bigint":
                        return String(BigInt.asIntN(64, a));
                    default:
                        return Pg(a)
                }
            case 8192:
                switch (c) {
                    case "string":
                        return b = Math.trunc(Number(a)), Number.isSafeInteger(b) ? a = yg(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = yg(BigInt.asIntN(64, BigInt(a)))), a;
                    case "bigint":
                        return yg(BigInt.asIntN(64, a));
                    default:
                        return yg(Qg(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Og(a);
                    case "bigint":
                        return yg(BigInt.asIntN(64,
                            a));
                    default:
                        return Qg(a)
                }
            default:
                return td(b, "Unknown format requested type for int64")
        }
    }

    function Rg(a) {
        return a == null ? a : Ng(a, 0)
    }

    function Sg(a) {
        return a[0] === "-" ? !1 : a.length < 20 ? !0 : a.length === 20 && Number(a.substring(0, 6)) < 184467
    }

    function Tg(a) {
        return a[0] === "-" ? a.length < 20 ? !0 : a.length === 20 && Number(a.substring(0, 7)) > -922337 : a.length < 19 ? !0 : a.length === 19 && Number(a.substring(0, 6)) < 922337
    }

    function Ug(a) {
        if (a < 0) {
            Af(a);
            const b = Bf(xf, yf);
            a = Number(b);
            return Number.isSafeInteger(a) ? a : b
        }
        if (Sg(String(a))) return a;
        Af(a);
        return yf * 4294967296 + (xf >>> 0)
    }

    function Qg(a) {
        a = Math.trunc(a);
        if (!Number.isSafeInteger(a)) {
            Af(a);
            var b = xf,
                c = yf;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = c * 4294967296 + (b >>> 0);
            a = a ? -b : b
        }
        return a
    }

    function Vg(a) {
        a = Math.trunc(a);
        return a >= 0 && Number.isSafeInteger(a) ? a : Ug(a)
    }

    function Pg(a) {
        a = Math.trunc(a);
        if (Number.isSafeInteger(a)) a = String(a);
        else {
            {
                const b = String(a);
                Tg(b) ? a = b : (Af(a), a = Cf())
            }
        }
        return a
    }

    function Wg(a) {
        a = Math.trunc(a);
        if (a >= 0 && Number.isSafeInteger(a)) a = String(a);
        else {
            {
                const b = String(a);
                Sg(b) ? a = b : (Af(a), a = Bf(xf, yf))
            }
        }
        return a
    }

    function Og(a) {
        var b = Math.trunc(Number(a));
        if (Number.isSafeInteger(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Tg(a) || (Df(a), a = Cf());
        return a
    }

    function Xg(a) {
        var b = Math.trunc(Number(a));
        if (Number.isSafeInteger(b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Sg(a) || (Df(a), a = Bf(xf, yf));
        return a
    }

    function Yg(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return Bg(a) ? a = Number(a) : (a = BigInt.asIntN(64, a), a = Bg(a) ? Number(a) : String(a)), a;
        if (Fg(a)) return typeof a === "number" ? Qg(a) : Og(a)
    }

    function Zg(a, b = 0) {
        if (!Fg(a)) throw lg("uint64");
        const c = typeof a;
        switch (b) {
            case 4096:
                switch (c) {
                    case "string":
                        return Xg(a);
                    case "bigint":
                        return String(BigInt.asUintN(64, a));
                    default:
                        return Wg(a)
                }
            case 8192:
                switch (c) {
                    case "string":
                        return b = Math.trunc(Number(a)), Number.isSafeInteger(b) && b >= 0 ? a = yg(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = yg(BigInt.asUintN(64, BigInt(a)))), a;
                    case "bigint":
                        return yg(BigInt.asUintN(64, a));
                    default:
                        return yg(Vg(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Xg(a);
                    case "bigint":
                        return yg(BigInt.asUintN(64,
                            a));
                    default:
                        return Vg(a)
                }
            default:
                return td(b, "Unknown format requested type for int64")
        }
    }

    function $g(a) {
        return a == null ? a : Zg(a, 0)
    }

    function ah(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function bh(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function ch(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function dh(a, b, c, d) {
        if (a != null && typeof a === "object" && a.Hd === Qf) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? eh(b) : new b : void 0;
        let e = c = a[v] | 0;
        e === 0 && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[v] = e);
        return new b(a)
    }

    function eh(a) {
        var b = a[Ff];
        if (b) return b;
        b = new a;
        Mf(b.U);
        return a[Ff] = b
    }

    function fh(a, b, c) {
        return b ? ah(a) : ch(a) ? ? (c ? "" : void 0)
    };
    const gh = {},
        hh = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function ih(a) {
        return a
    }

    function jh(a) {
        if (a.ac & 2) throw Error("Cannot mutate an immutable Map");
    }
    var nh = class extends hh {
        constructor(a, b, c = ih, d = ih) {
            super();
            let e = a[v] | 0;
            e |= 64;
            this.ac = a[v] = e;
            this.ee = b;
            this.zc = c;
            this.Ef = this.ee ? kh : d;
            for (let f = 0; f < a.length; f++) {
                const g = a[f],
                    h = c(g[0], !1, !0);
                let k = g[1];
                b ? k === void 0 && (k = null) : k = d(g[1], !1, !0, void 0, void 0, e);
                super.set(h, k)
            }
        }
        Af(a = lh) {
            if (this.size !== 0) return this.zf(a)
        }
        zf(a = lh) {
            const b = [],
                c = super.entries();
            for (var d; !(d = c.next()).done;) d = d.value, d[0] = a(d[0]), d[1] = a(d[1]), b.push(d);
            return b
        }
        clear() {
            jh(this);
            super.clear()
        }
        delete(a) {
            jh(this);
            return super.delete(this.zc(a, !0, !1))
        }
        entries() {
            var a = this.Fg();
            return new Zf(a, mh, this)
        }
        keys() {
            return this.hj()
        }
        values() {
            var a = this.Fg();
            return new Zf(a, nh.prototype.get, this)
        }
        forEach(a, b) {
            super.forEach((c, d) => {
                a.call(b, this.get(d), d, this)
            })
        }
        set(a, b) {
            jh(this);
            a = this.zc(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.Ef(b, !0, !0, this.ee, !1, this.ac))
        }
        has(a) {
            return super.has(this.zc(a, !1, !1))
        }
        get(a) {
            a = this.zc(a, !1, !1);
            const b = super.get(a);
            if (b !== void 0) {
                var c = this.ee;
                return c ? (c = this.Ef(b, !1, !0, c, this.Zh,
                    this.ac), c !== b && super.set(a, c), c) : b
            }
        }
        Fg() {
            return Array.from(super.keys())
        }
        hj() {
            return super.keys()
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    nh.prototype.toJSON = void 0;
    nh.prototype.kj = Rf;

    function kh(a, b, c, d, e, f) {
        a = dh(a, d, c, f);
        e && (a = oh(a));
        return a
    }

    function lh(a) {
        return a
    }

    function mh(a) {
        return [a, this.get(a)]
    }
    let ph;

    function qh() {
        return ph || (ph = new nh(Mf([]), void 0, void 0, void 0, gh))
    };
    let rh;

    function sh(a, b) {
        rh = b;
        a = new a(b);
        rh = void 0;
        return a
    };

    function th(a, b) {
        return uh(b)
    }

    function uh(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (Vf(a)) return
                    } else {
                        if (qf(a)) return mf(a);
                        if (a instanceof wf) {
                            const b = a.g;
                            return b == null ? "" : typeof b === "string" ? b : a.g = mf(b)
                        }
                        if (a instanceof nh) return a.Af()
                    }
        }
        return a
    };

    function vh(a, b, c) {
        a = Ef(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function wh(a, b, c, d, e) {
        if (a != null) {
            if (Array.isArray(a)) a = Vf(a) ? void 0 : e && (a[v] | 0) & 2 ? a : xh(a, b, c, d !== void 0, e);
            else if (Tf(a)) {
                const f = {};
                for (let g in a) Object.prototype.hasOwnProperty.call(a, g) && (f[g] = wh(a[g], b, c, d, e));
                a = f
            } else a = b(a, d);
            return a
        }
    }

    function xh(a, b, c, d, e) {
        const f = d || c ? a[v] | 0 : 0;
        d = d ? !!(f & 32) : void 0;
        a = Ef(a);
        for (let g = 0; g < a.length; g++) a[g] = wh(a[g], b, c, d, e);
        c && c(f, a);
        return a
    }

    function yh(a) {
        return wh(a, zh, void 0, void 0, !1)
    }

    function zh(a) {
        a.Hd === Qf ? a = a.toJSON() : a instanceof wf ? (a = a.g || "", a = typeof a === "string" ? a : new Uint8Array(a)) : a = qf(a) ? new Uint8Array(a) : a instanceof nh ? a.Af(yh) : a;
        return a
    }

    function Ah(a) {
        return wh(a, Bh, void 0, void 0, !1)
    }

    function Bh(a) {
        return a.Hd === Qf ? a.toJSON() : a instanceof nh ? a.Af(Ah) : uh(a)
    }
    var Ch = sf ? structuredClone : a => xh(a, zh, void 0, void 0, !1);

    function Dh(a, b, c = Pf) {
        if (a != null) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[v] | 0;
                if (d & 2) return a;
                b && (b = d === 0 || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[v] = (d | 34) & -12293, a) : xh(a, Dh, d & 4 ? Pf : c, !0, !0)
            }
            a.Hd === Qf ? (c = a.U, d = c[v], a = d & 2 ? a : sh(a.constructor, Eh(c, d, !0))) : a instanceof nh && !(a.ac & 2) && (c = Mf(a.zf(Dh)), a = new nh(c, a.ee, a.zc, a.Ef));
            return a
        }
    }

    function Fh(a) {
        const b = a.U;
        return sh(a.constructor, Eh(b, b[v], !1))
    }

    function Eh(a, b, c) {
        const d = c || b & 2 ? Pf : Of,
            e = !!(b & 32);
        a = vh(a, b, f => Dh(f, e, d));
        a[v] = a[v] | 32 | (c ? 2 : 0);
        return a
    }

    function oh(a) {
        const b = a.U,
            c = b[v];
        return c & 2 ? sh(a.constructor, Eh(b, c, !1)) : a
    };

    function Gh(a) {
        var b = Hh ? .get(a);
        if (b) return b;
        if (Math.random() > .01) return a;
        if (Ih === void 0)
            if (typeof Proxy !== "function") Ih = null;
            else try {
                Ih = Proxy.toString().indexOf("[native code]") !== -1 ? Proxy : null
            } catch {
                Ih = null
            }
        b = Ih;
        if (!b) return a;
        b = new b(a, {
            set(c, d, e) {
                Jh();
                c[d] = e;
                return !0
            }
        });
        Kh(a, b);
        return b
    }

    function Jh() {
        kg()
    }
    let Hh = void 0,
        Lh = void 0;

    function Kh(a, b) {
        (Hh || (Hh = new WeakMap)).set(a, b);
        (Lh || (Lh = new WeakMap)).set(b, a)
    }
    let Ih = void 0;

    function Mh(a, b, c, d) {
        if (!(4 & b)) return !0;
        if (c == null) return !1;
        !d && c === 0 && (4096 & b || 8192 & b) && (a.constructor[If] = (a.constructor[If] | 0) + 1) < 5 && kg();
        return c === 0 ? !1 : !(c & b)
    }

    function Nh(a, b) {
        a = a.U;
        return Oh(a, a[v], b)
    }

    function Ph(a, b, c, d) {
        b = d + (+!!(b & 512) - 1);
        if (!(b < 0 || b >= a.length || b >= c)) return a[b]
    }

    function Oh(a, b, c, d) {
        if (c === -1) return null;
        const e = b >> 14 & 1023 || 536870912;
        if (c >= e) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var f = a.length;
            return d && b & 256 && (d = a[f - 1][c], d != null) ? (Ph(a, b, e, c) && mg(void 0, Gf), d) : Ph(a, b, e, c)
        }
    }

    function Qh(a, b, c) {
        const d = a.U;
        let e = d[v];
        Yf(e);
        Rh(d, e, b, c);
        return a
    }

    function Rh(a, b, c, d, e) {
        const f = b >> 14 & 1023 || 536870912;
        if (c >= f || e && !Cd) {
            let g = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (d == null) return g;
                e = a[f + (+!!(b & 512) - 1)] = {};
                g |= 256
            }
            e[c] = d;
            c < f && (a[c + (+!!(b & 512) - 1)] = void 0);
            g !== b && (a[v] = g);
            return g
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function Sh(a, b, c) {
        return Th(a, b, c, !1) !== void 0
    }

    function Uh(a, b, c, d) {
        var e = b & 2;
        let f = Oh(a, b, c, d);
        Array.isArray(f) || (f = Wf);
        const g = !!(b & 32);
        let h = f[v] | 0;
        h === 0 && g && !e ? (h |= 33, f[v] = h) : h & 1 || (h |= 1, f[v] = h);
        if (e) h & 2 || Mf(f), Object.freeze(f);
        else if (2 & h || 2048 & h) f = Ef(f), e = 1, g && (e |= 32), f[v] = e, Rh(a, b, c, f, d);
        return f
    }

    function Vh(a, b) {
        a = a.U;
        let c = a[v];
        const d = Oh(a, c, b);
        var e = d == null || typeof d === "number" ? d : d === "NaN" || d === "Infinity" || d === "-Infinity" ? Number(d) : void 0;
        e != null && e !== d && Rh(a, c, b, e);
        return e
    }

    function w(a) {
        return a === $f ? 2 : 5
    }

    function Wh(a, b, c, d, e) {
        const f = a.U;
        var g = f[v];
        const h = 2 & g ? 1 : d;
        d = Xh(f, g, b);
        var k = d[v] | 0;
        if (Mh(a, k, e, !1)) {
            if (4 & k || Object.isFrozen(d)) d = Ef(d), k = Yh(k, g), g = Rh(f, g, b, d);
            let m = a = 0;
            for (; a < d.length; a++) {
                const n = c(d[a]);
                n != null && (d[m++] = n)
            }
            m < a && (d.length = m);
            k = Zh(k, g);
            k = (k | 20) & -4097;
            k &= -8193;
            e && (k |= e);
            d[v] = k;
            2 & k && Object.freeze(d)
        }
        let l;
        h === 1 || h === 4 && 32 & k ? $h(k) || (g = k, k |= 2, k !== g && (d[v] = k), Object.freeze(d)) : (e = h !== 5 ? !1 : !!(32 & k) || $h(k) || !!Hh ? .get(d), (h === 2 || e) && $h(k) && (d = Ef(d), k = Yh(k, g), k = ai(k, g, !1), d[v] = k, g = Rh(f,
            g, b, d)), $h(k) || (b = k, k = ai(k, g, !1), k !== b && (d[v] = k)), e && (l = Gh(d)));
        return l || d
    }

    function Xh(a, b, c, d) {
        a = Oh(a, b, c, d);
        return Array.isArray(a) ? a : Wf
    }

    function Zh(a, b) {
        a === 0 && (a = Yh(a, b));
        return a | 1
    }

    function $h(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    }

    function bi(a) {
        var b = ci,
            c = a.U;
        const d = c[v];
        var e = Oh(c, d, 14);
        a = d & 2;
        a: {
            var f = e,
                g = d & 2;e = !1;
            if (f == null) {
                if (g) {
                    c = qh();
                    break a
                }
                f = []
            } else if (f.constructor === nh) {
                if ((f.ac & 2) == 0 || g) {
                    c = f;
                    break a
                }
                f = f.zf()
            } else Array.isArray(f) ? e = Lf(f) : f = [];
            if (g) {
                if (!f.length) {
                    c = qh();
                    break a
                }
                e || (e = !0, Mf(f))
            } else if (e) {
                e = !1;
                g = Ef(f);
                for (f = 0; f < g.length; f++) {
                    const h = g[f] = Ef(g[f]);
                    Array.isArray(h[1]) && (h[1] = Mf(h[1]))
                }
                f = g
            }
            e || ((f[v] | 0) & 64 ? f[v] &= -33 : 32 & d && Nf(f));e = new nh(f, b, fh, void 0);Rh(c, d, 14, e, !1);c = e
        }!a && b && (c.Zh = !0);
        return c
    }

    function di(a, b, c, d) {
        const e = a.U;
        let f = e[v];
        Yf(f);
        if (c == null) return Rh(e, f, b), a;
        c = Lh ? .get(c) || c;
        let g = c[v] | 0,
            h = g;
        var k = !!(2 & g) || Object.isFrozen(c);
        const l = !k && (void 0 === fg || !1);
        if (Mh(a, g))
            for (g = 21, k && (c = Ef(c), h = 0, g = Yh(g, f), g = ai(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (c = Ef(c), h = 0, g = Yh(g, f), g = ai(g, f, !0));
        g !== h && (c[v] = g);
        Rh(e, f, b, c);
        return a
    }

    function ei(a, b, c, d) {
        const e = a.U;
        let f = e[v];
        Yf(f);
        Rh(e, f, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function fi(a, b) {
        var c = a.U,
            d = c[v] | 0;
        Yf(a.U[v]);
        c = Uh(c, d, 3, !1);
        d = Kf(c[v] | 0) ? ? 0;
        if (Array.isArray(b))
            for (var e = 0; e < b.length; e++) c.push(Ng(b[e], d));
        else
            for (e of b) c.push(Ng(e, d));
        return a
    }

    function gi(a, b, c, d) {
        var e = a.U;
        const f = e[v];
        Yf(f);
        b = Uh(e, f, b);
        d = c(d, Kf(b[v] | 0) ? ? 0);
        b.push(d);
        return a
    }

    function hi(a, b, c, d) {
        const e = a.U;
        var f = e[v];
        Yf(f);
        if (d == null) {
            var g = ii(e);
            if (ji(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = ii(e);
            const h = ji(g, e, f, c);
            h !== b && (h && (f = Rh(e, f, h)), g.set(c, b))
        }
        Rh(e, f, b, d);
        return a
    }

    function ki(a, b) {
        a = a.U;
        return ji(ii(a), a, a[v], b)
    }

    function ii(a) {
        return a[Hf] ? ? (a[Hf] = new Map)
    }

    function ji(a, b, c, d) {
        let e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            const g = d[f];
            Oh(b, c, g) != null && (e !== 0 && (c = Rh(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Th(a, b, c, d) {
        a = a.U;
        let e = a[v];
        const f = Oh(a, e, c, d);
        b = dh(f, b, !1, e);
        b !== f && b != null && Rh(a, e, c, b, d);
        return b
    }

    function li(a, b) {
        return (a = Th(a, b, 1, !1)) ? a : eh(b)
    }

    function x(a, b, c) {
        b = Th(a, b, c, !1);
        if (b == null) return b;
        a = a.U;
        let d = a[v];
        if (!(d & 2)) {
            const e = oh(b);
            e !== b && (b = e, Rh(a, d, c, b, !1))
        }
        return b
    }

    function mi(a, b, c, d, e, f, g, h) {
        var k = !!(2 & b);
        e = k ? 1 : e;
        g = !!g;
        h && (h = !k);
        k = Xh(a, b, d, f);
        var l = k[v] | 0,
            m = !!(4 & l);
        if (!m) {
            l = Zh(l, b);
            var n = k,
                p = b;
            const y = !!(2 & l);
            y && (p |= 2);
            let D = !y,
                E = !0,
                G = 0,
                H = 0;
            for (; G < n.length; G++) {
                const z = dh(n[G], c, !1, p);
                if (z instanceof c) {
                    if (!y) {
                        const I = Lf(z.U);
                        D && (D = !I);
                        E && (E = I)
                    }
                    n[H++] = z
                }
            }
            H < G && (n.length = H);
            l |= 4;
            l = E ? l | 16 : l & -17;
            l = D ? l | 8 : l & -9;
            n[v] = l;
            y && Object.freeze(n)
        }
        if (h && !(8 & l || !k.length && (e === 1 || e === 4 && 32 & l))) {
            $h(l) && (k = Ef(k), l = Yh(l, b), b = Rh(a, b, d, k, f));
            c = k;
            h = l;
            for (n = 0; n < c.length; n++) l = c[n],
                p = oh(l), l !== p && (c[n] = p);
            h |= 8;
            h = c.length ? h & -17 : h | 16;
            l = c[v] = h
        }
        let r;
        e === 1 || e === 4 && 32 & l ? $h(l) || (b = l, l |= !k.length || 16 & l && (!m || 32 & l) ? 2 : 2048, l !== b && (k[v] = l), Object.freeze(k)) : (m = e !== 5 ? !1 : !!(32 & l) || $h(l) || !!Hh ? .get(k), (e === 2 || m) && $h(l) && (k = Ef(k), l = Yh(l, b), l = ai(l, b, g), k[v] = l, b = Rh(a, b, d, k, f)), $h(l) || (a = l, l = ai(l, b, g), l !== a && (k[v] = l)), m && (r = Gh(k)));
        return r || k
    }

    function ni(a, b, c, d) {
        a = a.U;
        const e = a[v];
        return mi(a, e, b, c, d, void 0, !1, !(2 & e))
    }

    function A(a, b, c) {
        c == null && (c = void 0);
        return Qh(a, b, c)
    }

    function B(a, b, c, d) {
        d == null && (d = void 0);
        return hi(a, b, c, d)
    }

    function oi(a, b, c) {
        const d = a.U;
        let e = d[v];
        Yf(e);
        if (c == null) return Rh(d, e, b), a;
        c = Lh ? .get(c) || c;
        let f = c[v] | 0,
            g = f;
        const h = !!(2 & f) || !!(2048 & f),
            k = h || Object.isFrozen(c),
            l = !k && (void 0 === fg || !1);
        let m = !0,
            n = !0;
        for (let r = 0; r < c.length; r++) {
            var p = c[r];
            h || (p = Lf(p.U), m && (m = !p), n && (n = p))
        }
        h || (f |= 5, f = m ? f | 8 : f & -9, f = n ? f | 16 : f & -17);
        if (l || k && f !== g) c = Ef(c), g = 0, f = Yh(f, e), f = ai(f, e, !0);
        f !== g && (c[v] = f);
        Rh(d, e, b, c);
        return a
    }

    function Yh(a, b) {
        a = (2 & b ? a | 2 : a & -3) | 32;
        return a &= -2049
    }

    function ai(a, b, c) {
        32 & b && c || (a &= -33);
        return a
    }

    function pi(a, b, c, d, e, f, g) {
        a = a.U;
        const h = a[v];
        Yf(h);
        b = mi(a, h, c, b, 2, f, !0);
        c = d != null ? d : new c;
        if (g && (typeof e !== "number" || e < 0 || e > b.length)) throw Error();
        e != void 0 ? b.splice(e, g, c) : b.push(c);
        b[v] = Lf(c.U) ? b[v] & -9 : b[v] & -17
    }

    function qi(a, b, c, d) {
        pi(a, b, c, d);
        return a
    }

    function ri(a, b) {
        return a ? ? b
    }

    function yi(a, b) {
        a = Nh(a, b);
        return a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0
    }

    function zi(a, b) {
        return Kg(Nh(a, b))
    }

    function C(a, b) {
        return ch(Nh(a, b))
    }

    function Ai(a, b) {
        return Ig(Nh(a, b))
    }

    function J(a, b, c = !1) {
        return ri(yi(a, b), c)
    }

    function Bi(a, b) {
        return ri(zi(a, b), 0)
    }

    function Ci(a, b) {
        return ri(Yg(Nh(a, b)), 0)
    }

    function Di(a, b, c = 0) {
        return ri(Vh(a, b), c)
    }

    function K(a, b) {
        return ri(C(a, b), "")
    }

    function Ei(a, b) {
        return ri(Ai(a, b), 0)
    }

    function Fi(a) {
        {
            a = Nh(a, 10);
            const b = typeof a;
            a = a == null ? a : b === "bigint" ? String(BigInt.asUintN(64, a)) : Fg(a) ? b === "string" ? Xg(a) : Wg(a) : void 0
        }
        return a ? ? "0"
    }

    function Gi(a, b, c, d) {
        c = ki(a, d) === c ? c : -1;
        return x(a, b, c)
    }

    function Hi(a, b) {
        a = zi(a, b);
        return a == null ? void 0 : a
    }

    function Ii(a) {
        a = Vh(a, 4);
        return a == null ? void 0 : a
    }

    function Ji(a, b) {
        a = Ai(a, b);
        return a == null ? void 0 : a
    }

    function Ki(a, b, c) {
        return Qh(a, b, c == null ? c : Dg(c))
    }

    function L(a, b, c) {
        return ei(a, b, c == null ? c : Dg(c), !1)
    }

    function Li(a, b, c) {
        return Qh(a, b, c == null ? c : Jg(c))
    }

    function Mi(a, b, c) {
        return ei(a, b, c == null ? c : Jg(c), 0)
    }

    function Ni(a, b, c) {
        return Qh(a, b, Rg(c))
    }

    function Oi(a, b, c) {
        return ei(a, b, Rg(c), "0")
    }

    function Pi(a, b, c) {
        return Qh(a, b, bh(c))
    }

    function Qi(a, b, c) {
        return ei(a, b, bh(c), "")
    }

    function M(a, b, c) {
        return ei(a, b, Hg(c), 0)
    };
    let Ri;

    function Si(a) {
        try {
            return Ri = !0, JSON.stringify(Ti(a), th)
        } finally {
            Ri = !1
        }
    }
    var N = class {
        constructor(a) {
            a: {
                a == null && (a = rh);rh = void 0;
                if (a == null) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error("narr");
                    b = a[v] | 0;
                    if (b & 2048) throw Error("farr");
                    if (b & 64) break a;
                    var c = a;
                    b |= 64;
                    var d = c.length;
                    if (d && (--d, Tf(c[d]))) {
                        b |= 256;
                        c = d - (+!!(b & 512) - 1);
                        if (c >= 1024) throw Error("pvtlmt");
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[v] = b
            }
            this.U = a
        }
        toJSON() {
            return Ti(this)
        }
        i() {
            const a = this.U,
                b = a[v];
            return b & 2 ? this : sh(this.constructor, Eh(a, b, !0))
        }
    };
    N.prototype.Hd = Qf;

    function Ti(a) {
        a = Ri ? a.U : xh(a.U, Bh, void 0, void 0, !1); {
            var b = !Ri;
            let l = a.length;
            if (l) {
                var c = a[l - 1],
                    d = Tf(c);
                d ? l-- : c = void 0;
                var e = a;
                if (d) {
                    b: {
                        var f = c;
                        var g = {};d = !1;
                        if (f)
                            for (var h in f) {
                                if (!Object.prototype.hasOwnProperty.call(f, h)) continue;
                                if (isNaN(+h)) {
                                    g[h] = f[h];
                                    continue
                                }
                                let m = f[h];
                                Array.isArray(m) && (Vf(m) || Sf(m) && m.size === 0) && (m = null);
                                m == null && (d = !0);
                                m != null && (g[h] = m)
                            }
                        if (d) {
                            for (let m in g) break b;
                            g = null
                        } else g = f
                    }
                    f = g == null ? c != null : g !== c
                }
                for (; l > 0; l--) {
                    h = e[l - 1];
                    if (!(h == null || Vf(h) || Sf(h) && h.size === 0)) break;
                    var k = !0
                }
                if (e !== a || f || k) {
                    if (!b) e = Array.prototype.slice.call(e, 0, l);
                    else if (k || f || g) e.length = l;
                    g && e.push(g)
                }
                k = e
            } else k = a
        }
        return k
    }

    function Ui(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        b[v] |= 128;
        return sh(a, Nf(b))
    };

    function Vi(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = sh(a, Nf(b))
            }
            return b
        }
    };
    fd `https://www.google.com/recaptcha/api2/aframe`;

    function Wi(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            const f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            ud(f, a);
            b.document.readyState !== "complete" ? Hb(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };
    async function Xi(a) {
        var b = "https://ep1.adtrafficquality.google/getconfig/sodar" + `?sv=${200}&tid=${a.g}` + `&tv=${a.i}&st=` + `${a.Wb}`;
        let c = void 0;
        try {
            c = await Yi(b)
        } catch (g) {}
        if (c) {
            b = a.yc || c.sodar_query_id;
            var d = c.rc_enable !== void 0 && a.j ? c.rc_enable : "n",
                e = c.bg_snapshot_delay_ms === void 0 ? "0" : c.bg_snapshot_delay_ms,
                f = c.is_gen_204 === void 0 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename && c.bg_binary) return {
                context: a.l,
                Uh: c.bg_hash_basename,
                Th: c.bg_binary,
                ij: a.g + "_" + a.i,
                yc: b,
                Wb: a.Wb,
                wd: d,
                Zd: e,
                ud: f
            }
        }
    }
    let Yi = a => new Promise((b, c) => {
        const d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (d.status >= 200 && d.status < 300 ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function Zi(a) {
        var b = await Xi(a);
        if (b) {
            a = window;
            let c = a.GoogleGcLKhOms;
            c && typeof c.push === "function" || (c = a.GoogleGcLKhOms = []);
            c.push({
                _ctx_: b.context,
                _bgv_: b.Uh,
                _bgp_: b.Th,
                _li_: b.ij,
                _jk_: b.yc,
                _st_: b.Wb,
                _rc_: b.wd,
                _dl_: b.Zd,
                _g2_: b.ud
            });
            if (b = a.GoogleDX5YKUSk) a.GoogleDX5YKUSk = void 0, b[1]();
            a = fd `https://ep2.adtrafficquality.google/sodar/${"sodar2"}.js`;
            Wi(a)
        }
    };

    function $i(a, b) {
        return Qi(a, 1, b)
    }
    var aj = class extends N {
        g() {
            return K(this, 1)
        }
    };

    function bj(a, b) {
        return A(a, 5, b)
    }

    function cj(a, b) {
        return Qi(a, 3, b)
    }

    function dj(a, b) {
        return L(a, 6, b)
    }
    var ej = class extends N {
        constructor() {
            super()
        }
    };

    function fj(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    }
    var gj = class {
            constructor(a) {
                this.g = a.i;
                this.i = a.j;
                this.l = a.l;
                this.yc = a.yc;
                this.win = a.da();
                this.Wb = a.Wb;
                this.wd = a.wd;
                this.Zd = a.Zd;
                this.ud = a.ud;
                this.j = a.g
            }
        },
        hj = class {
            constructor(a, b, c) {
                this.i = a;
                this.j = b;
                this.l = c;
                this.win = window;
                this.Wb = "env";
                this.wd = "n";
                this.Zd = "0";
                this.ud = "1";
                this.g = !0
            }
            da() {
                return this.win
            }
            build() {
                return new gj(this)
            }
        };

    function ij(a) {
        var b = new jj;
        return Pi(b, 1, a)
    }
    var jj = class extends N {
        getValue() {
            return K(this, 1)
        }
        getVersion() {
            return Ei(this, 5)
        }
    };
    var kj = class extends N {};
    var lj = class extends N {};

    function mj(a, b, c = null, d = !1, e = !1) {
        nj(a, b, c, d, e)
    }

    function nj(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = ue("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                d && cb(a.google_image_requests, f);
                Ib(f, "load", g);
                Ib(f, "error", g)
            };
            Hb(f, "load", g);
            Hb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var pj = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            xe(a, (d, e) => {
                if (d || d === 0) c += `&${e}=${encodeURIComponent(""+d)}`
            });
            oj(c)
        },
        oj = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : mj(b, a, void 0, !1, !1)
        };
    let qj = null;
    var rj = window;
    var sj = class extends N {
        constructor() {
            super()
        }
    };
    var tj = class extends N {
        constructor() {
            super()
        }
        getCorrelator() {
            mg(this, Jf);
            return Ci(this, 1)
        }
        setCorrelator(a) {
            return Oi(this, 1, a)
        }
    };
    var uj = class extends N {
        constructor() {
            super()
        }
    };

    function vj(a) {
        this.g = a || {
            cookie: ""
        }
    }
    aa = vj.prototype;
    aa.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        typeof c === "object" && (h = c.gh, g = c.Wd || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Cd);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        d === void 0 && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (d < 0 ? "" : d == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + d * 1E3)).toUTCString()) + (g ? ";secure" : "") + (h != null ? ";samesite=" + h : "")
    };
    aa.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = Rb(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };

    function wj(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            Cd: 0,
            path: c,
            domain: d
        })
    }
    aa.isEmpty = function() {
        return !this.g.cookie
    };
    aa.wc = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    aa.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [],
            c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = Rb(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; a >= 0; a--) wj(this, b[a])
    };

    function xj(a, b = window) {
        if (a.g()) try {
            return b.localStorage
        } catch {}
        return null
    }

    function yj(a = window) {
        try {
            return a.localStorage
        } catch {
            return null
        }
    }
    let zj;

    function Aj(a) {
        return zj ? zj : a.origin === "null" ? zj = !1 : zj = Bj(a)
    }

    function Bj(a) {
        if (!a.navigator.cookieEnabled) return !1;
        const b = new vj(a.document);
        if (!b.isEmpty()) return !0;
        b.set("TESTCOOKIESENABLED", "1", {
            Cd: 60,
            gh: a.isSecureContext ? "none" : void 0,
            Wd: a.isSecureContext || void 0
        });
        if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
        wj(b, "TESTCOOKIESENABLED");
        return !0
    }

    function Cj(a, b) {
        b = b.origin !== "null" ? b.document.cookie : null;
        return b === null ? null : (new vj({
            cookie: b
        })).get(a) || ""
    }

    function Dj(a, b, c, d) {
        d.origin !== "null" && (d.isSecureContext && (c = { ...c,
            gh: "none",
            Wd: !0
        }), (new vj(d.document)).set(a, b, c))
    };
    let Ej = null,
        Fj = null;

    function Gj() {
        if (Ej != null) return Ej;
        Ej = !1;
        try {
            const a = se(q);
            a && a.location.hash.indexOf("google_logging") !== -1 && (Ej = !0);
            yj(q) ? .getItem("google_logging") && (Ej = !0)
        } catch (a) {}
        return Ej
    }

    function Hj() {
        if (Fj != null) return Fj;
        Fj = !1;
        try {
            const a = se(q),
                b = yj(q);
            if (a && a.location.hash.indexOf("auto_ads_logging") !== -1 || b && b.getItem("auto_ads_logging")) Fj = !0
        } catch (a) {}
        return Fj
    }
    var Ij = (a, b = []) => {
        let c = !1;
        q.google_logging_queue || (c = !0, q.google_logging_queue = []);
        q.google_logging_queue.push([a, b]);
        c && Gj() && te(q.document, fd `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function Jj(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    aa = Jj.prototype;
    aa.getWidth = function() {
        return this.right - this.left
    };
    aa.getHeight = function() {
        return this.bottom - this.top
    };

    function Kj(a) {
        return new Jj(a.top, a.right, a.bottom, a.left)
    }
    aa.contains = function(a) {
        return this && a ? a instanceof Jj ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };

    function Lj(a, b) {
        return a.left <= b.right && b.left <= a.right && a.top <= b.bottom && b.top <= a.bottom
    }
    aa.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    aa.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    aa.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    aa.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function Mj(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function Nj(a, b) {
        var c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            var e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new Mj(c, e, d - c, a - e)
        }
        return null
    }

    function Oj(a, b) {
        var c = Nj(a, b);
        if (!c || !c.height || !c.width) return [new Mj(a.left, a.top, a.width, a.height)];
        c = [];
        var d = a.top,
            e = a.height,
            f = a.left + a.width,
            g = a.top + a.height,
            h = b.left + b.width,
            k = b.top + b.height;
        b.top > a.top && (c.push(new Mj(a.left, a.top, a.width, b.top - a.top)), d = b.top, e -= b.top - a.top);
        k < g && (c.push(new Mj(a.left, k, a.width, g - k)), e = k - d);
        b.left > a.left && c.push(new Mj(a.left, d, b.left - a.left, e));
        h < f && c.push(new Mj(h, d, f - h, e));
        return c
    }
    aa = Mj.prototype;
    aa.contains = function(a) {
        return a instanceof od ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    aa.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    aa.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.width *= a;
        this.top *= b;
        this.height *= b;
        return this
    };
    const Pj = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function Qj(a = q) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function Rj(a = Qj()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function Sj(a = Qj()) {
        if (a && a.container) {
            a = a.container.split(",");
            const b = [];
            for (let c = 0; c < a.length; c++) b.push(Pj[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function Tj() {
        var a = Qj();
        return a && a.initialIntersection
    }

    function Uj() {
        const a = Tj();
        return a && Da(a.rootBounds) ? new pd(a.rootBounds.width, a.rootBounds.height) : null
    }

    function Vj(a = Qj()) {
        return a ? pe(a.master) ? a.master : null : null
    }

    function Wj(a, b) {
        const c = a.ampInaboxIframes = a.ampInaboxIframes || [];
        let d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            cb(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        const f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = g.data === "amp-ini-load";
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized ||
                    g && !/^\d{15,20}$/.test(g) || a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || te(a.document, g ? fd `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : fd `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, Hb(a, "message", f), d = () => {
            Ib(a, "message", f)
        });
        return e
    };

    function Xj() {
        return a => {
            a = {
                id: "unsafeurl",
                ctx: 638,
                url: a
            };
            var b = [];
            for (c in a) oe(c, a[c], b);
            var c = ne("https://pagead2.googlesyndication.com/pagead/gen_204", b.join("&"));
            navigator.sendBeacon && navigator.sendBeacon(c, "")
        }
    };

    function Yj(a, b, c) {
        if (typeof b === "string")(b = Zj(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = Zj(c, d);
                f && (c.style[f] = e)
            }
    }
    var ak = {};

    function Zj(a, b) {
        var c = ak[b];
        if (!c) {
            var d = zd(b);
            c = d;
            a.style[d] === void 0 && (d = (Vd ? "Webkit" : Ud ? "Moz" : Sd ? "ms" : null) + Ad(d), a.style[d] !== void 0 && (c = d));
            ak[b] = c
        }
        return c
    }

    function bk(a, b) {
        var c = a.style[zd(b)];
        return typeof c !== "undefined" ? c : a.style[Zj(a, b)] || ""
    }

    function ck(a, b) {
        var c = Yd(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    }

    function dk(a, b) {
        return ck(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function ek(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function fk(a) {
        var b = Yd(a),
            c = new od(0, 0);
        if (a == (b ? Yd(b) : document).documentElement) return c;
        a = ek(a);
        b = $d(Wd(b).g);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function gk(a) {
        var b = hk;
        if (dk(a, "display") != "none") return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function hk(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Vd && !b && !c;
        return (b === void 0 || d) && a.getBoundingClientRect ? (a = ek(a), new pd(a.right - a.left, a.bottom - a.top)) : new pd(b, c)
    };
    var ik = a => typeof a === "number" && a > 0,
        kk = (a, b) => {
            a = jk(a);
            if (!a) return b;
            const c = b.slice(-1);
            return b + (c === "?" || c === "#" ? "" : "&") + a
        },
        jk = a => Object.entries(lk(a)).map(([b, c]) => `${b}=${encodeURIComponent(String(c))}`).join("&"),
        lk = a => {
            const b = {};
            xe(a, (c, d) => {
                if (c || c === 0 || c === !1) typeof c === "boolean" && (c = c ? 1 : 0), b[d] = c
            });
            return b
        },
        mk = a => {
            a = Vj(Qj(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1
        },
        nk = a => {
            a = a.google_unique_id;
            return typeof a === "number" ? a : 0
        },
        ok = a => {
            let b;
            b = a.nodeType !== 9 && a.id;
            a: {
                if (a && a.nodeName &&
                    a.parentElement) {
                    var c = a.nodeName.toString().toLowerCase();
                    const d = a.parentElement.childNodes;
                    let e = 0;
                    for (let f = 0; f < d.length; ++f) {
                        const g = d[f];
                        if (g.nodeName && g.nodeName.toString().toLowerCase() === c) {
                            if (a === g) {
                                c = "." + e;
                                break a
                            }++e
                        }
                    }
                }
                c = ""
            }
            return (a.nodeName && a.nodeName.toString().toLowerCase()) + (b ? "/" + b : "") + c
        },
        pk = a => (a = a.google_ad_format) ? a.indexOf("_0ads") > 0 : !1,
        qk = a => {
            let b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(b > 0 && c > 0)) {
                a: {
                    try {
                        const e = String(a.google_ad_format);
                        if (e && e.match) {
                            const f =
                                e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                const g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (g > 0 && h > 0) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = b > 0 ? b : a.width;c = c > 0 ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        };
    var rk = class {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const sk = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var tk = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        uk = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.Cg = !!c;
                this.depth = null
            }
        };
    let vk = null;

    function wk() {
        if (vk === null) {
            vk = "";
            try {
                let a = "";
                try {
                    a = q.top.location.hash
                } catch (b) {
                    a = q.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    vk = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return vk
    };

    function xk() {
        const a = q.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function yk() {
        const a = q.performance;
        return a && a.now ? a.now() : null
    };
    var zk = class {
        constructor(a, b) {
            var c = yk() || xk();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const Ak = q.performance,
        Bk = !!(Ak && Ak.mark && Ak.measure && Ak.clearMarks),
        Ck = Ab(() => {
            var a;
            if (a = Bk) a = wk(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function Dk(a) {
        a && Ak && Ck() && (Ak.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Ak.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Ek(a) {
        a.g = !1;
        a.i != a.j.google_js_reporting_queue && (Ck() && Ua(a.i, Dk), a.i.length = 0)
    }

    function Fk(a, b) {
        if (!a.g) return b();
        const c = a.start("491", 3);
        let d;
        try {
            d = b()
        } catch (e) {
            throw Dk(c), e;
        }
        a.end(c);
        return d
    }
    class Gk {
        constructor(a) {
            this.i = [];
            this.j = a || q;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = Ck() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new zk(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Ak && Ck() && Ak.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (yk() || xk()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Ak && Ck() && Ak.mark(b);
                !this.g || this.i.length >
                    2048 || this.i.push(a)
            }
        }
    };

    function Hk(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function Ik(a, b, c, d, e) {
        const f = [];
        xe(a, function(g, h) {
            (g = Jk(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function Jk(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c == "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(Jk(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a == "object") return e = e || 0, e < 2 ? encodeURIComponent(Ik(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Kk(a) {
        let b = 1;
        for (const c in a.i) b = c.length > b ? c.length : b;
        return 3997 - b - a.j.length - 1
    }

    function Lk(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = Kk(a) - b.length;
        if (d < 0) return "";
        a.g.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = b == null ? g : b;
                    break
                }
                let l = Ik(h[k], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = b == null ? g : b
                }
            }
        }
        a = "";
        b != null && (a = e + "trn=" + b);
        return c + a
    }
    class Mk {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.g = []
        }
    };

    function Nk(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        a.stack && (b = Ok(a.stack, b));
        return b
    }

    function Ok(a, b) {
        try {
            a.indexOf(b) == -1 && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    }
    var Qk = class {
        constructor(a, b, c = null) {
            this.Z = a;
            this.A = b;
            this.i = c;
            this.g = null;
            this.j = !1;
            this.B = this.ba
        }
        tf(a) {
            this.g = a
        }
        l(a) {
            this.j = a
        }
        vb(a, b, c) {
            let d, e;
            try {
                this.i && this.i.g ? (e = this.i.start(a.toString(), 3), d = b(), this.i.end(e)) : d = b()
            } catch (f) {
                b = this.A;
                try {
                    Dk(e), b = this.B(a, new rk(f, {
                        message: Nk(f)
                    }), void 0, c)
                } catch (g) {
                    this.ba(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        Ca(a, b, c, d) {
            return (...e) => this.vb(a, () => b.apply(c, e), d)
        }
        ba(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const F = new Mk;
                var g = F;
                g.g.push(1);
                g.i[1] = Hk("context", a);
                b.error && b.meta && b.id || (b = new rk(b, {
                    message: Nk(b)
                }));
                if (b.msg) {
                    g = F;
                    var h = b.msg.substring(0, 512);
                    g.g.push(2);
                    g.i[2] = Hk("msg", h)
                }
                var k = b.meta || {};
                b = k;
                if (this.g) try {
                    this.g(b)
                } catch (fa) {}
                if (d) try {
                    d(b)
                } catch (fa) {}
                d = F;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                d = q;
                k = [];
                b = null;
                do {
                    var l = d;
                    if (pe(l)) {
                        var m = l.location.href;
                        b = l.document && l.document.referrer || null
                    } else m = b, b = null;
                    k.push(new uk(m || "", l));
                    try {
                        d = l.parent
                    } catch (fa) {
                        d = null
                    }
                } while (d && l != d);
                for (let fa = 0, la = k.length - 1; fa <= la; ++fa) k[fa].depth = la -
                    fa;
                l = q;
                if (l.location && l.location.ancestorOrigins && l.location.ancestorOrigins.length == k.length - 1)
                    for (m = 1; m < k.length; ++m) {
                        var n = k[m];
                        n.url || (n.url = l.location.ancestorOrigins[m - 1] || "", n.Cg = !0)
                    }
                var p = k;
                let ba = new uk(q.location.href, q, !1);
                l = null;
                const bb = p.length - 1;
                for (n = bb; n >= 0; --n) {
                    var r = p[n];
                    !l && sk.test(r.url) && (l = r);
                    if (r.url && !r.Cg) {
                        ba = r;
                        break
                    }
                }
                r = null;
                const xa = p.length && p[bb].url;
                ba.depth != 0 && xa && (r = p[bb]);
                f = new tk(ba, r);
                if (f.i) {
                    p = F;
                    var y = f.i.url || "";
                    p.g.push(4);
                    p.i[4] = Hk("top", y)
                }
                var D = {
                    url: f.g.url ||
                        ""
                };
                if (f.g.url) {
                    var E = f.g.url.match(me),
                        G = E[1],
                        H = E[3],
                        z = E[4];
                    y = "";
                    G && (y += G + ":");
                    H && (y += "//", y += H, z && (y += ":" + z));
                    var I = y
                } else I = "";
                G = F;
                D = [D, {
                    url: I
                }];
                G.g.push(5);
                G.i[5] = D;
                Pk(this.Z, e, F, this.j, c)
            } catch (F) {
                try {
                    Pk(this.Z, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Nk(F),
                        url: f && f.g.url
                    }, this.j, c)
                } catch (ba) {}
            }
            return this.A
        }
        pa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.ba(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var Rk = class extends N {
        constructor() {
            super()
        }
    };

    function Sk(a, b) {
        try {
            const c = d => [{
                [d.Cf]: d.df
            }];
            return JSON.stringify([a.filter(d => d.yd).map(c), Ti(b), a.filter(d => !d.yd).map(c)])
        } catch (c) {
            return Tk(c, b), ""
        }
    }

    function Tk(a, b) {
        try {
            pj({
                m: Nk(a instanceof Error ? a : Error(String(a))),
                b: Ei(b, 1) || null,
                v: K(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }
    var Uk = class {
        constructor(a, b) {
            var c = new Rk;
            a = M(c, 1, a);
            this.i = Qi(a, 2, b).i()
        }
    };
    var Vk = class extends N {},
        Wk = [1, 2, 3];
    var Xk = class extends N {
            constructor() {
                super()
            }
        },
        Yk = [2, 4];

    function Zk(a) {
        var b = new $k;
        return Qi(b, 1, a)
    }
    var $k = class extends N {
        constructor() {
            super()
        }
    };
    var al = class extends N {
        getValue() {
            return Ei(this, 1)
        }
    };

    function bl(a) {
        var b = new cl;
        return Qh(b, 1, Hg(a))
    }
    var cl = class extends N {
        getValue() {
            return Ei(this, 1)
        }
    };
    var dl = class extends N {
        constructor() {
            super()
        }
        getValue() {
            return Ei(this, 1)
        }
    };

    function el(a, b) {
        return Oi(a, 1, b)
    }

    function fl(a, b) {
        return Oi(a, 2, b)
    }

    function gl(a, b) {
        return Oi(a, 3, b)
    }

    function hl(a, b) {
        return Oi(a, 4, b)
    }

    function il(a, b) {
        return Oi(a, 5, b)
    }

    function jl(a, b) {
        return ei(a, 8, Cg(b), 0)
    }

    function kl(a, b) {
        return ei(a, 9, Cg(b), 0)
    }
    var ll = class extends N {
        constructor() {
            super()
        }
    };

    function ml(a, b) {
        return Oi(a, 1, b)
    }

    function nl(a, b) {
        return Oi(a, 2, b)
    }
    var ol = class extends N {};

    function pl(a, b) {
        qi(a, 1, ol, b)
    }
    var ci = class extends N {
        jh(a) {
            pi(this, 1, ol, void 0, a, !1, 1);
            return this
        }
    };
    var ql = class extends N {
        constructor() {
            super()
        }
    };

    function rl(a, b) {
        return di(a, 1, b, ah)
    }

    function sl(a, b) {
        return di(a, 12, b, Zg)
    }

    function tl() {
        var a = new ul;
        return gi(a, 2, ah, "irr")
    }

    function vl(a, b) {
        return L(a, 3, b)
    }

    function wl(a, b) {
        return L(a, 4, b)
    }

    function xl(a, b) {
        return L(a, 5, b)
    }

    function yl(a, b) {
        return L(a, 7, b)
    }

    function zl(a, b) {
        return L(a, 8, b)
    }

    function Al(a, b) {
        return Oi(a, 9, b)
    }

    function Bl(a, b) {
        return oi(a, 10, b)
    }

    function Cl(a, b) {
        return di(a, 11, b, Ng)
    }
    var ul = class extends N {
        constructor() {
            super()
        }
    };

    function Dl(a) {
        var b = El();
        A(a, 1, b)
    }

    function Fl(a, b) {
        return Oi(a, 2, b)
    }

    function Gl(a, b) {
        return oi(a, 3, b)
    }

    function Hl(a, b) {
        return oi(a, 4, b)
    }

    function Il(a, b) {
        return qi(a, 4, cl, b)
    }

    function Jl(a, b) {
        return oi(a, 5, b)
    }

    function Kl(a, b) {
        return di(a, 6, b, ah)
    }

    function Ll(a, b) {
        return Oi(a, 7, b)
    }

    function Ml(a, b) {
        A(a, 9, b)
    }

    function Nl(a, b) {
        return L(a, 10, b)
    }

    function Ol(a, b) {
        return L(a, 11, b)
    }

    function Pl(a, b) {
        return L(a, 12, b)
    }
    var Ql = class extends N {
        constructor() {
            super()
        }
        H(a) {
            pi(this, 3, al, void 0, a, !1, 1);
            return this
        }
        G(a) {
            return Oi(this, 8, a)
        }
    };
    var Rl = class extends N {
        constructor() {
            super()
        }
    };
    var Sl = class extends N {};

    function Tl(a) {
        var b = new Ul;
        return M(b, 1, a)
    }
    var Ul = class extends N {
        constructor() {
            super()
        }
    };
    var Vl = class extends N {
        constructor() {
            super()
        }
    };
    var Wl = class extends N {
        constructor() {
            super()
        }
    };
    var Xl = class extends N {
        constructor() {
            super()
        }
    };
    var Yl = class extends N {
            constructor() {
                super()
            }
        },
        Zl = [1, 2];
    var $l = class extends N {
        constructor() {
            super()
        }
    };
    var am = class extends N {
            constructor() {
                super()
            }
        },
        bm = [1];

    function cm(a) {
        var b = new dm;
        return M(b, 1, a)
    }
    var dm = class extends N {
        constructor() {
            super()
        }
    };
    var em = class extends N {
        constructor() {
            super()
        }
    };
    var fm = class extends N {
        constructor() {
            super()
        }
    };
    var gm = class extends N {
        constructor() {
            super()
        }
    };
    var hm = class extends N {
        constructor() {
            super()
        }
    };
    var im = class extends N {
        constructor() {
            super()
        }
    };
    var jm = class extends N {
        constructor() {
            super()
        }
    };
    var km = class extends N {
        constructor() {
            super()
        }
        getContentUrl() {
            return K(this, 1)
        }
    };
    var lm = class extends N {
        constructor() {
            super()
        }
    };
    var mm = class extends N {
        constructor() {
            super()
        }
    };

    function nm() {
        var a = new om,
            b = new mm;
        return B(a, 1, pm, b)
    }
    var om = class extends N {
            constructor() {
                super()
            }
        },
        pm = [1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13];
    var qm = class extends N {
        constructor() {
            super()
        }
    };
    var rm = class extends N {
        constructor() {
            super()
        }
    };
    var sm = class extends N {
        constructor() {
            super()
        }
    };
    var tm = class extends N {
        constructor() {
            super()
        }
    };

    function um(a, b) {
        return ei(a, 10, $g(b), "0")
    }

    function vm(a, b) {
        return M(a, 1, b)
    }
    var wm = class extends N {};
    var xm = class extends N {
        constructor() {
            super()
        }
    };
    var ym = class extends N {
        constructor() {
            super()
        }
    };
    var Km = class extends N {
            constructor() {
                super()
            }
        },
        Lm = [4, 5];

    function Mm(a) {
        var b = new Nm;
        return Qi(b, 4, a)
    }

    function Om(a, b) {
        return Qh(a, 6, $g(b))
    }
    var Nm = class extends N {
        constructor() {
            super()
        }
    };

    function Pm(a) {
        var b = new Qm;
        return Mi(b, 2, a)
    }
    var Qm = class extends N {
        constructor() {
            super()
        }
    };
    var Rm = class extends N {
        constructor() {
            super()
        }
    };
    var Sm = class extends N {
        constructor() {
            super()
        }
    };
    var Tm = class extends N {
        constructor() {
            super()
        }
    };
    var Um = class extends N {
        constructor() {
            super()
        }
    };
    var Vm = class extends N {
        constructor() {
            super()
        }
    };
    var Wm = class extends N {
            constructor() {
                super()
            }
        },
        Xm = [2, 3];
    var Ym = class extends N {
            constructor() {
                super()
            }
        },
        Zm = [3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 16, 17];

    function $m(a, b) {
        return Oi(a, 3, b)
    }
    var an = class extends N {
            constructor() {
                super()
            }
            Ub(a) {
                return Qi(this, 2, a)
            }
        },
        bn = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14];
    var cn = class extends N {
        constructor() {
            super()
        }
    };
    var dn = class extends N {
        constructor() {
            super()
        }
    };
    var en = class extends N {
        constructor() {
            super()
        }
        getTagSessionCorrelator() {
            mg(this, Jf);
            return Ci(this, 1)
        }
    };
    var fn = class extends N {
            constructor() {
                super()
            }
        },
        gn = [4, 6];
    class hn {
        constructor(a) {
            this.Z = a;
            this.g = new jn(this.Z)
        }
    }
    class jn {
        constructor(a) {
            this.Z = a;
            this.g = new kn(this.Z)
        }
    }
    class kn {
        constructor(a) {
            this.Z = a;
            this.g = new ln(this.Z)
        }
    }
    class ln {
        constructor(a) {
            this.Z = a;
            this.i = new mn(this.Z);
            this.g = new nn(this.Z)
        }
    }
    class mn {
        constructor(a) {
            this.Z = a
        }
    }

    function on(a, b) {
        var c = pn;
        a = a.Z;
        var d = Zk("jM4CPd");
        var e = new Vk;
        e = hi(e, 2, Wk, Rg(Math.round(b.Vj)));
        d = qi(d, 4, Vk, e);
        e = new Xk;
        b = hi(e, 4, Yk, Cg(b.Qj));
        b = A(d, 3, b);
        c(a, b)
    }
    class nn {
        constructor(a) {
            this.Z = a
        }
    }
    class qn extends Uk {
        constructor() {
            super(...arguments);
            this.C = new hn(this)
        }
    }

    function pn(a, ...b) {
        a.l(...b.map(c => ({
            yd: !1,
            Cf: 1,
            df: Ti(c)
        })))
    }

    function rn(a, ...b) {
        a.l(...b.map(c => ({
            yd: !0,
            Cf: 3,
            df: Ti(c)
        })))
    }

    function sn(a, ...b) {
        a.l(...b.map(c => ({
            yd: !0,
            Cf: 7,
            df: Ti(c)
        })))
    }
    var tn = class extends qn {};
    var un = (a, b) => {
            globalThis.fetch(a, {
                method: "POST",
                body: b,
                keepalive: b.length < 65536,
                credentials: "omit",
                mode: "no-cors",
                redirect: "follow"
            }).catch(() => {})
        },
        vn = class extends tn {
            constructor(a) {
                super(2, a);
                this.g = un
            }
            l(...a) {
                try {
                    const b = Sk(a, this.i);
                    this.g("https://pagead2.googlesyndication.com/pagead/ping?e=1", b)
                } catch (b) {
                    Tk(b, this.i)
                }
            }
        },
        wn = class extends vn {};

    function xn(a) {
        a.j !== null && (clearTimeout(a.j), a.j = null);
        if (a.g.length) {
            var b = Sk(a.g, a.i);
            a.G("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var zn = class extends tn {
            constructor(a, b, c, d, e) {
                super(2, a);
                this.G = un;
                this.I = b;
                this.F = c;
                this.H = d;
                this.A = e;
                this.g = [];
                this.j = null;
                this.B = !1
            }
            l(...a) {
                try {
                    this.H && Sk(this.g.concat(a), this.i).length >= 65536 && xn(this), this.A && !this.B && (this.B = !0, yn(this.A, () => {
                        xn(this)
                    })), this.g.push(...a), this.g.length >= this.F && xn(this), this.g.length && this.j === null && (this.j = setTimeout(() => {
                        xn(this)
                    }, this.I))
                } catch (b) {
                    Tk(b, this.i)
                }
            }
        },
        An = class extends zn {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };
    var O = a => {
        var b = "Ve";
        if (a.Ve && a.hasOwnProperty(b)) return a.Ve;
        b = new a;
        return a.Ve = b
    };

    function Bn(a, b, c) {
        return b[a] || c
    };

    function Cn(a, b) {
        a.i = (c, d) => Bn(2, b, () => [])(c, 1, d);
        a.g = () => Bn(3, b, () => [])(1)
    }
    class Dn {
        i() {
            return []
        }
        g() {
            return []
        }
    }

    function En(a, b) {
        return O(Dn).i(a, b)
    };

    function Pk(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Mk ? f = c : (f = new Mk, xe(c, (h, k) => {
                var l = f;
                const m = l.l++;
                h = Hk(k, h);
                l.g.push(m);
                l.i[m] = h
            }));
            const g = Lk(f, "/pagead/gen_204?id=" + b + "&");
            g && mj(q, g)
        } catch (f) {}
    }

    function Fn(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    class Gn {
        constructor() {
            this.g = Math.random()
        }
    };
    let Hn, In;
    const Jn = new Gk(window);
    (a => {
        Hn = a ? ? new Gn;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Fn(Hn, window.google_srt);
        In = new Qk(Hn, !0, Jn);
        In.tf(() => {});
        In.l(!0);
        window.document.readyState == "complete" ? window.google_measure_js_timing || Ek(Jn) : Jn.g && Hb(window, "load", () => {
            window.google_measure_js_timing || Ek(Jn)
        })
    })();
    let Kn = (new Date).getTime();
    var Ln = {
        nm: 0,
        mm: 1,
        jm: 2,
        em: 3,
        km: 4,
        fm: 5,
        lm: 6,
        hm: 7,
        im: 8,
        dm: 9,
        gm: 10,
        om: 11
    };
    var Mn = {
        qm: 0,
        rm: 1,
        pm: 2
    };

    function Nn(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function On(a) {
        a = Xa(a, b => new Jj(b.top, b.right, b.bottom, b.left));
        a = Pn(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function Pn(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return Ya(a.slice(1), (b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, Kj(a[0]))
    };
    var Lb = {
        gn: 0,
        Sl: 1,
        Vl: 2,
        Tl: 3,
        Ul: 4,
        bm: 8,
        sn: 9,
        Dm: 10,
        Em: 11,
        on: 16,
        Fl: 17,
        El: 24,
        Am: 25,
        Zk: 26,
        Yk: 27,
        Dh: 30,
        um: 32,
        xm: 40,
        yn: 41,
        un: 42
    };
    var Qn = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        Rn = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var Sn = 728 * 1.38;

    function Tn(a, b = -1) {
        if (a !== a.top) {
            if (b < 0) a = !1;
            else {
                var c = Un(a, !0, !0),
                    d = P(a, !0);
                a = c > 0 && d > 0 && Math.abs(1 - a.screen.width / c) <= b && Math.abs(1 - a.screen.height / d) <= b
            }
            a = a ? 0 : 512
        } else a = 0;
        return a
    }

    function Vn(a, b = 420, c = !1, d = !1) {
        return (a = Un(a, c, d)) ? a > b ? 32768 : a < 320 ? 65536 : 0 : 16384
    }

    function Wn(a) {
        return Math.max(0, Xn(a, !0) - P(a))
    }

    function Yn(a) {
        a = a.document;
        let b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function P(a, b = !1) {
        const c = Yn(a).clientHeight;
        return b ? c * cf(a) : c
    }

    function Un(a, b = !1, c = !1) {
        c = Yn(a).clientWidth ? ? (c ? a.innerWidth : void 0);
        return b ? c * cf(a) : c
    }

    function Xn(a, b) {
        const c = Yn(a);
        return b ? (a = P(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function Zn(a, b) {
        return $n(b) || b === 10 || !a.adCount ? !1 : b == 1 || b == 2 ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? a >= 1 : !1
    }

    function ao(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function bo(a) {
        return a.pageYOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function co(a) {
        return a.pageXOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function eo(a) {
        const b = {};
        let c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                const d = c[a];
                if ("key" in d && "value" in d) {
                    const e = d.value;
                    b[d.key] = e == null ? null : String(e)
                }
            }
        return b
    }

    function fo(a, b, c, d) {
        Pk(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function go(a) {
        const b = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        Ua(Object.keys(b), c => {
            bk(a, c) || Yj(a, c, b[c])
        });
        Pe(a)
    }

    function $n(a) {
        return a === 26 || a === 27 || a === 40 || a === 41
    };

    function ho(a, b) {
        io(a).forEach(b, void 0)
    }

    function io(a) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function jo(a, b) {
        return a.g[ko(b)] !== void 0
    }

    function lo(a) {
        const b = [];
        for (const c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.i[c]);
        return b
    }

    function mo(a) {
        const b = [];
        for (const c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    const no = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            const c = ko(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = ko(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        wc() {
            return lo(this).length
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function ko(a) {
        return a instanceof Object ? String(Ea(a)) : a + ""
    };
    const oo = class {
        constructor(a) {
            this.g = new no;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return jo(this.g, a)
        }
    };
    const po = new oo("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function qo(a, {
        eb: b,
        Xa: c,
        Db: d
    }) {
        return d && c(b) ? b : (b = b.parentElement) ? ro(a, {
            eb: b,
            Xa: c,
            Db: !0
        }) : null
    }

    function ro(a, {
        eb: b,
        Xa: c,
        Db: d = !1
    }) {
        const e = so({
                eb: b,
                Xa: c,
                Db: d
            }),
            f = a.g.get(e);
        if (f) return f.element;
        b = qo(a, {
            eb: b,
            Xa: c,
            Db: d
        });
        a.g.set(e, {
            element: b
        });
        return b
    }
    var to = class {
        constructor() {
            this.g = new Map
        }
    };

    function so({
        eb: a,
        Xa: b,
        Db: c
    }) {
        a = Ea(a);
        b = Ea(b);
        return `${a}:${b}:${c}`
    };

    function uo(a) {
        Qd(a.document.body.offsetHeight)
    };

    function vo(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function Q() {
        this.B = this.B;
        this.G = this.G
    }
    Q.prototype.B = !1;
    Q.prototype.dispose = function() {
        this.B || (this.B = !0, this.i())
    };
    Q.prototype[ma(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function wo(a, b) {
        xo(a, Ka(vo, b))
    }

    function xo(a, b) {
        a.B ? b() : (a.G || (a.G = []), a.G.push(b))
    }
    Q.prototype.i = function() {
        if (this.G)
            for (; this.G.length;) this.G.shift()()
    };

    function yo(a) {
        a.g.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function zo(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.g.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.g.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var Ao = class extends Q {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.g = b
        }
        i() {
            yo(this);
            super.i()
        }
    };

    function Bo(a) {
        const b = new R(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function Co(a, b) {
        const c = new R({
            first: a.P,
            second: b.P
        });
        a.listen(() => c.g({
            first: a.P,
            second: b.P
        }));
        b.listen(() => c.g({
            first: a.P,
            second: b.P
        }));
        return c
    }

    function Do(...a) {
        const b = [...a],
            c = () => b.every(f => f.P),
            d = new R(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return Eo(d)
    }

    function Fo(...a) {
        const b = [...a],
            c = () => b.findIndex(f => f.P) !== -1,
            d = new R(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return Eo(d)
    }

    function Eo(a, b = Go) {
        var c = a.P;
        const d = new R(a.P);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function Ho(a, b, c) {
        return a.i(d => {
            d === b && c()
        })
    }

    function Io(a, b, c) {
        if (a.P === b) return c(), () => {};
        const d = {
            dc: null
        };
        d.dc = Ho(a, b, () => {
            d.dc && (d.dc(), d.dc = null);
            c()
        });
        return d.dc
    }

    function Jo(a, b, c) {
        Eo(a).listen(d => {
            d === b && c()
        })
    }

    function Ko(a, b) {
        a.l && a.l();
        a.l = b.listen(c => a.g(c), !0)
    }

    function Lo(a, b, c, d) {
        const e = new R(!1);
        var f = null;
        a = a.map(d);
        Ho(a, !0, () => {
            f === null && (f = b.setTimeout(() => {
                e.g(!0)
            }, c))
        });
        Ho(a, !1, () => {
            e.g(!1);
            f !== null && (b.clearTimeout(f), f = null)
        });
        return Eo(e)
    }

    function Mo(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.P
        }
    }
    class R {
        constructor(a) {
            this.P = a;
            this.j = new Map;
            this.B = 1;
            this.l = null
        }
        listen(a, b = !1) {
            const c = this.B++;
            this.j.set(c, a);
            b && a(this.P);
            return () => {
                this.j.delete(c)
            }
        }
        i(a) {
            return this.listen(a, !0)
        }
        A() {
            return this.P
        }
        g(a) {
            this.P = a;
            this.j.forEach(b => {
                b(this.P)
            })
        }
        map(a) {
            const b = new R(a(this.P));
            this.listen(c => b.g(a(c)));
            return b
        }
    }

    function Go(a, b) {
        return a == b
    };

    function No(a) {
        return new Oo(a)
    }

    function Po(a, b) {
        Ua(a.g, c => {
            c(b)
        })
    }
    var Qo = class {
        constructor() {
            this.g = []
        }
    };
    class Oo {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            const b = new Qo;
            this.listen(c => Po(b, a(c)));
            return No(b)
        }
        delay(a, b) {
            const c = new Qo;
            this.listen(d => {
                a.setTimeout(() => {
                    Po(c, d)
                }, b)
            });
            return No(c)
        }
    }

    function Ro(...a) {
        const b = new Qo;
        a.forEach(c => {
            c.listen(d => {
                Po(b, d)
            })
        });
        return No(b)
    };

    function So(a) {
        return Eo(Co(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : To(c, b)
        }))
    }
    var Vo = class {
        constructor(a) {
            this.i = a;
            this.g = new R(null);
            this.j = new R(null);
            this.l = new Qo;
            this.C = b => {
                this.g.P == null && b.touches.length == 1 && this.g.g(b.touches[0])
            };
            this.A = b => {
                const c = this.g.P;
                c != null && (b = Uo(c, b.changedTouches), b != null && (this.g.g(null), this.j.g(null), Po(this.l, To(c, b))))
            };
            this.B = b => {
                var c = this.g.P;
                c != null && (c = Uo(c, b.changedTouches), c != null && (this.j.g(c), b.preventDefault()))
            }
        }
    };

    function To(a, b) {
        return {
            xh: b.pageX - a.pageX,
            yh: b.pageY - a.pageY
        }
    }

    function Uo(a, b) {
        if (b == null) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function Wo(a) {
        return Eo(Co(a.g, a.i).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : Xo(c, b)
        }))
    }
    var Yo = class {
        constructor(a, b) {
            this.l = a;
            this.A = b;
            this.g = new R(null);
            this.i = new R(null);
            this.j = new Qo;
            this.G = c => {
                this.g.g(c)
            };
            this.B = c => {
                const d = this.g.P;
                d != null && (this.g.g(null), this.i.g(null), Po(this.j, Xo(d, c)))
            };
            this.C = c => {
                this.g.P != null && (this.i.g(c), c.preventDefault())
            }
        }
    };

    function Xo(a, b) {
        return {
            xh: b.screenX - a.screenX,
            yh: b.screenY - a.screenY
        }
    };
    var ap = (a, b, c) => {
        const d = new Zo(a, b, c);
        return () => $o(d)
    };

    function $o(a) {
        if (a.g) return !1;
        if (a.i == null) return bp(a), !0;
        const b = a.i + a.A - (new Date).getTime();
        if (b < 1) return bp(a), !0;
        cp(a, b);
        return !0
    }

    function bp(a) {
        a.i = (new Date).getTime();
        a.l()
    }

    function cp(a, b) {
        a.g = !0;
        a.j.setTimeout(() => {
            a.g = !1;
            bp(a)
        }, b)
    }
    class Zo {
        constructor(a, b, c) {
            this.j = a;
            this.A = b;
            this.l = c;
            this.i = null;
            this.g = !1
        }
    };

    function dp(a) {
        return ep(Wo(a.g), So(a.i))
    }

    function fp(a) {
        return Ro(No(a.g.j), No(a.i.l))
    }
    var gp = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function ep(a, b) {
        return Co(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };
    var hp = class {
        constructor() {
            this.cache = new Map
        }
        getBoundingClientRect(a) {
            var b = this.cache.get(a);
            if (b) return b;
            b = a.getBoundingClientRect();
            this.cache.set(a, b);
            return b
        }
    };

    function ip(a) {
        a.A == null && (a.A = new R(a.C.getBoundingClientRect()));
        return a.A
    }
    class jp extends Q {
        constructor(a, b) {
            super();
            this.j = a;
            this.C = b;
            this.F = !1;
            this.A = null;
            this.l = () => {
                ip(this).g(this.C.getBoundingClientRect())
            }
        }
        g() {
            this.F || (this.F = !0, this.j.addEventListener("resize", this.l), this.j.addEventListener("scroll", this.l));
            return ip(this)
        }
        i() {
            this.j.removeEventListener("resize", this.l);
            this.j.removeEventListener("scroll", this.l);
            super.i()
        }
    };

    function kp(a, b) {
        return new lp(a, b)
    }

    function mp(a) {
        a.win.requestAnimationFrame(() => {
            a.B || a.j.g(new pd(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function np(a) {
        a.g || (a.g = !0, a.l.observe(a.element));
        return Eo(a.j, qd)
    }
    var lp = class extends Q {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.g = !1;
            this.j = new R(new pd(this.element.offsetWidth, this.element.offsetHeight));
            this.l = new ResizeObserver(() => {
                mp(this)
            })
        }
        i() {
            this.l.disconnect();
            super.i()
        }
    };

    function op(a, b) {
        return {
            top: a.g - b,
            right: a.j + a.i,
            bottom: a.g + b,
            left: a.j
        }
    }
    class pp {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
    };

    function qp(a, b) {
        a = a.getBoundingClientRect();
        return new rp(a.top + bo(b), a.bottom - a.top)
    }

    function sp(a) {
        return new rp(Math.round(a.g), Math.round(a.i))
    }
    class rp {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getHeight() {
            return this.i
        }
    };
    var up = (a, b) => {
        const c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new oo(c);
        b = b.filter(e => !d.contains(e));
        b.length && (tp(a, b), ib(c, b))
    };

    function tp(a, b) {
        for (const f of b) {
            b = ue("LINK", a.document);
            b.type = "text/css";
            var c = fd `//fonts.googleapis.com/css`,
                d = Xj(),
                e = b;
            c = gd(c, new Map([
                ["family", f]
            ]));
            if (c instanceof cc) d = c;
            else a: {
                if (c instanceof mc) {
                    d = c;
                    break a
                }
                const g = tc(c);g === nc && d(c);d = g
            }
            e.rel = "stylesheet";
            if ($b("stylesheet", "stylesheet")) {
                e.href = dc(d).toString();
                a: if (d = (e.ownerDocument && e.ownerDocument.defaultView || q).document, d.querySelector) {
                    if ((d = d.querySelector('style[nonce],link[rel="stylesheet"][nonce]')) && (d = d.nonce || d.getAttribute("nonce")) &&
                        kd.test(d)) break a;
                    d = ""
                } else d = "";
                d && e.setAttribute("nonce", d)
            } else d instanceof cc ? d = dc(d).toString() : (d = wc(d), d = d === void 0 ? nc.toString() : d), e.href = d;
            a.document.head.appendChild(b)
        }
    };

    function vp(a, b) {
        a.F ? b(a.l) : a.j.push(b)
    }

    function wp(a, b) {
        a.F = !0;
        a.l = b;
        a.j.forEach(c => {
            c(a.l)
        });
        a.j = []
    }
    class xp extends Q {
        constructor(a) {
            super();
            this.g = a;
            this.j = [];
            this.F = !1;
            this.C = this.l = null;
            this.H = ap(a, 1E3, () => {
                if (this.C != null) {
                    var b = Xn(this.g, !0) - this.C;
                    b > 1E3 && wp(this, b)
                }
            });
            this.A = null
        }
        J(a, b) {
            a == null ? (this.C = a = Xn(this.g, !0), this.g.addEventListener("scroll", this.H), b != null && b(a)) : this.A = this.g.setTimeout(() => {
                this.J(void 0, b)
            }, a)
        }
        i() {
            this.A != null && this.g.clearTimeout(this.A);
            this.g.removeEventListener("scroll", this.H);
            this.j = [];
            this.l = null;
            super.i()
        }
    };
    var yp = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    class zp {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            var a = 48271 * this.g % 2147483647;
            this.g = a * 2147483647 < 0 ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function Ap(a, b, c) {
        const d = [];
        for (const e of a.g) b(e) ? d.push(e) : c(e);
        return new Bp(d)
    }

    function Cp(a) {
        return a.g.slice(0)
    }

    function Dp(a, b = 1) {
        a = Cp(a);
        const c = new zp(b);
        qb(a, () => c.next());
        return new Bp(a)
    }
    const Bp = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Bp(Wa(this.g, a))
        }
        apply(a) {
            return new Bp(a(Cp(this)))
        }
        sort(a) {
            return new Bp(Cp(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = Cp(this);
            b.push(a);
            return new Bp(b)
        }
    };
    class Ep {
        constructor(a) {
            this.g = new oo(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function Fp(a) {
        return new Gp({
            value: a
        }, null)
    }

    function Hp(a) {
        return new Gp(null, Error(a))
    }

    function Ip(a) {
        try {
            return Fp(a())
        } catch (b) {
            return new Gp(null, b)
        }
    }

    function Jp(a) {
        return a.g != null ? a.getValue() : null
    }

    function Kp(a, b) {
        a.g != null && b(a.getValue());
        return a
    }

    function Lp(a, b) {
        return a.g != null ? a : new Gp(null, b(a.i))
    }

    function Mp(a, b) {
        return Lp(a, c => Error(`${b}${c.message}`))
    }

    function Np(a, b) {
        a.g != null || b(a.i);
        return a
    }
    class Gp {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return this.g != null ? (a = a(this.getValue()), a instanceof Gp ? a : Fp(a)) : this
        }
    };
    class Op {
        constructor() {
            this.g = new no
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new oo, this.g.set(a, c));
            c.add(b)
        }
    };

    function Pp(a) {
        return !a
    }

    function Qp(a) {
        return b => {
            for (const c of a) c(b)
        }
    };

    function Rp(a) {
        return a !== null
    };
    var Sp = class extends N {
        getId() {
            return C(this, 3)
        }
    };
    class Tp {
        constructor(a, {
            Sf: b,
            Fh: c,
            Xi: d,
            eh: e
        }) {
            this.A = a;
            this.j = c;
            this.l = new Bp(b || []);
            this.i = e;
            this.g = d
        }
    };
    var Up = a => {
            var b = a.split("~").filter(c => c.length > 0);
            a = new no;
            for (const c of b) b = c.indexOf("."), b == -1 ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        Wp = a => {
            var b = Vp(a);
            a = [];
            for (let c of b) b = String(c.ic), a.push(c.yb + "." + (b.length <= 20 ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const Vp = a => {
            const b = [],
                c = a.l;
            c && c.g.length && b.push({
                yb: "a",
                ic: Xp(c)
            });
            a.j != null && b.push({
                yb: "as",
                ic: a.j
            });
            a.g != null && b.push({
                yb: "i",
                ic: String(a.g)
            });
            a.i != null && b.push({
                yb: "rp",
                ic: String(a.i)
            });
            b.sort(function(d, e) {
                return d.yb.localeCompare(e.yb)
            });
            b.unshift({
                yb: "t",
                ic: Yp(a.A)
            });
            return b
        },
        Yp = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        Xp = a => {
            a = Cp(a).map(Zp);
            a = JSON.stringify(a);
            return ze(a)
        },
        Zp = a => {
            const b = {};
            C(a, 7) != null && (b.q = C(a, 7));
            zi(a, 2) != null &&
                (b.o = zi(a, 2));
            zi(a, 5) != null && (b.p = zi(a, 5));
            return b
        };

    function $p() {
        var a = new aq;
        return Qh(a, 2, Hg(1))
    }
    var aq = class extends N {
        setLocation(a) {
            return Qh(this, 1, Hg(a))
        }
        g() {
            return Ji(this, 1)
        }
    };

    function bq(a) {
        const b = [].slice.call(arguments).filter(zb(e => e === null));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.ag || []);
            d = Object.assign(d, e.xc())
        });
        return new cq(c, d)
    }

    function dq(a) {
        switch (a) {
            case 1:
                return new cq(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new cq(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new cq(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new cq(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function eq(a) {
        return a == null ? null : new cq(null, {
            google_ml_rank: a
        })
    }

    function fq(a) {
        return a == null ? null : new cq(null, {
            google_placement_id: Wp(a)
        })
    }

    function gq({
        ni: a,
        Hi: b = null
    }) {
        if (a == null) return null;
        a = {
            google_daaos_ts: a
        };
        b != null && (a.google_erank = b + 1);
        return new cq(null, a)
    }
    class cq {
        constructor(a, b) {
            this.ag = a;
            this.g = b
        }
        xc() {
            return this.g
        }
    };
    var hq = class extends N {};
    var iq = class extends N {};
    var jq = class extends N {
        B() {
            return C(this, 2)
        }
        A() {
            return C(this, 5)
        }
        g() {
            return ni(this, iq, 3, w())
        }
        j() {
            return zi(this, 4)
        }
        l() {
            return Vh(this, 6)
        }
        C() {
            return Sh(this, hq, 7)
        }
    };
    var kq = class extends N {};
    var lq = class extends N {
        l() {
            return J(this, 12, !1)
        }
        j() {
            return Yg(Nh(this, 13))
        }
        g() {
            const a = yi(this, 23);
            return a == null ? void 0 : a
        }
    };
    var mq = class extends N {
        constructor() {
            super()
        }
    };
    var nq = class extends N {
        g() {
            return Ai(this, 3)
        }
        j() {
            return yi(this, 6)
        }
    };
    var oq = class extends N {};
    var pq = class extends N {};
    var qq = class extends N {
        ja() {
            return x(this, Sp, 1)
        }
        g() {
            return Ai(this, 2)
        }
    };
    var rq = class extends N {};
    var sq = class extends N {};
    var tq = class extends N {
            getName() {
                return C(this, 4)
            }
        },
        uq = [1, 2, 3];
    var vq = class extends N {
        g() {
            return x(this, nq, 10)
        }
    };
    var wq = class extends N {
        g() {
            return yi(this, 2)
        }
        j() {
            return yi(this, 3)
        }
    };
    var xq = class extends N {
        g() {
            return Yg(Nh(this, 1))
        }
    };
    var yq = class extends N {};
    var zq = class extends N {
        g() {
            return Ci(this, 1)
        }
    };
    var Aq = class extends N {
        g() {
            return K(this, 1)
        }
        j() {
            return K(this, 2)
        }
    };
    var Bq = class extends N {};
    var Cq = class extends N {
        l() {
            return J(this, 1)
        }
        A() {
            return J(this, 3)
        }
        B() {
            return J(this, 7)
        }
        g() {
            return J(this, 4)
        }
        j() {
            return J(this, 5)
        }
    };
    var Dq = class extends N {
        j() {
            return x(this, Aq, 5)
        }
        g() {
            return x(this, zq, 6)
        }
        A() {
            return K(this, 8)
        }
        B() {
            return J(this, 9)
        }
        C() {
            return K(this, 13)
        }
        G() {
            return J(this, 11)
        }
        l() {
            return x(this, Cq, 12)
        }
    };
    var Eq = class extends N {};
    var Fq = class extends N {
        g() {
            return x(this, Eq, 1)
        }
    };
    var Gq = class extends N {};
    var Hq = class extends N {};
    var Iq = class extends N {
        g(a) {
            return ni(this, Hq, 1, w(a))
        }
    };
    var Jq = class extends N {
        setProperty(a) {
            return Pi(this, 1, a)
        }
        getValue() {
            return C(this, 2)
        }
    };
    var Kq = class extends N {};
    var Lq = class extends N {};
    var Mq = class extends N {
        ja() {
            return x(this, Sp, 1)
        }
        g() {
            return Ai(this, 2)
        }
    };
    var Nq = class extends N {};
    var Oq = class extends N {};
    var Pq = class extends N {
        g() {
            return Wh(this, 6, ch, w())
        }
    };
    var Qq = class extends N {
        Oe() {
            return Sh(this, Oq, 2)
        }
    };
    var Rq = class extends N {
        g() {
            return Ci(this, 1)
        }
    };
    var Sq = class extends N {};
    var Uq = class extends N {
            g() {
                return Gi(this, Sq, 2, Tq)
            }
        },
        Tq = [1, 2];
    var Vq = class extends N {
        g() {
            return x(this, Uq, 3)
        }
    };
    var Wq = class extends N {};
    var Xq = class extends N {
        g() {
            return ni(this, Wq, 1, w())
        }
    };
    var Yq = class extends N {
        g() {
            return Wh(this, 1, ch, w())
        }
        j() {
            return x(this, Vq, 3)
        }
    };
    var Zq = Vi(class extends N {
        g() {
            return x(this, lq, 15)
        }
    });
    var $q = class extends N {},
        ar = Vi($q);

    function br(a) {
        try {
            const b = a.localStorage.getItem("google_ama_settings");
            return b ? ar(b) : null
        } catch (b) {
            return null
        }
    }

    function cr(a, b) {
        if (a.He !== void 0) {
            var c = br(b);
            c || (c = new $q);
            a.He !== void 0 && Ki(c, 2, a.He);
            a = Date.now() + 864E5;
            Number.isFinite(a) && Ni(c, 1, Math.round(a));
            c = Si(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else if ((c = br(b)) && Yg(Nh(c, 1)) < Date.now()) try {
            b.localStorage.removeItem("google_ama_settings")
        } catch (d) {}
    };
    var dr = {
            qb: "ama_success",
            Qa: .1,
            Va: !0,
            rb: !0
        },
        er = {
            qb: "ama_failure",
            Qa: .1,
            Va: !0,
            rb: !0
        },
        fr = {
            qb: "ama_coverage",
            Qa: .1,
            Va: !0,
            rb: !0
        },
        gr = {
            qb: "ama_opt",
            Qa: .1,
            Va: !0,
            rb: !1
        },
        hr = {
            qb: "ama_auto_rs",
            Qa: 1,
            Va: !0,
            rb: !1
        },
        ir = {
            qb: "ama_improv",
            Qa: .1,
            Va: !0,
            rb: !1
        },
        jr = {
            qb: "ama_constraints",
            Qa: 0,
            Va: !0,
            rb: !0
        };

    function kr(a, b) {
        lr(a.i, hr, { ...b,
            evt: "place",
            vh: P(a.win),
            eid: a.g.g() ? .g() || 0,
            hl: a.g.j() ? .g() || ""
        })
    }

    function mr(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && Ok(c.stack, "") || "");
        kr(a, b)
    }
    var nr = class {
        constructor(a, b, c) {
            this.win = a;
            this.i = b;
            this.g = c
        }
    };
    const or = ["-webkit-text-fill-color"];

    function pr(a) {
        if (Td) {
            {
                const c = ve(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = qr(a)
                } else a = rr()
            }
        } else a = rr();
        return a
    }
    var rr = () => {
        const a = {
            all: "initial"
        };
        Ua(or, b => {
            a[b] = "unset"
        });
        return a
    };

    function qr(a) {
        Ua(or, b => {
            delete a[b]
        });
        return a
    };
    var sr = class {
        constructor(a) {
            this.g = a
        }
        Ja(a) {
            const b = a.document.createElement("div");
            u(b, pr(a));
            u(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            const c = a.document.createElement("div");
            u(c, pr(a));
            u(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };

    function tr(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function ur(a) {
        return io(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };
    var S = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        T = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        vr = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        wr = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        },
        xr = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var yr = new S(1321, !0),
        zr = new T(619278254, 10),
        Ar = new S(1325, !0),
        Br = new S(1310, !0),
        Cr = new S(1355, !0),
        Dr = new S(1351, !0),
        Er = new T(1130, 100),
        Fr = new S(1331, !0),
        Gr = new S(1352, !0),
        Hr = new S(1330, !0),
        Ir = new T(1339, .3),
        Jr = new T(1032, 200),
        Kr = new vr(14),
        Lr = new T(1224, .01),
        Mr = new S(654220660),
        Nr = new T(1346, 6),
        Or = new T(1347, 3),
        Pr = new S(1320, !0),
        Qr = new S(1367),
        Rr = new S(1260),
        Sr = new S(1239),
        Tr = new S(1196),
        Ur = new S(1160),
        Vr = new S(316),
        Wr = new S(1290),
        Xr = new S(334),
        Yr = new T(1263, -1),
        Zr = new T(54),
        $r = new T(1323, -1),
        as =
        new T(1265, -1),
        bs = new T(1264, -1),
        cs = new S(1291),
        ds = new S(1267, !0),
        es = new S(1266),
        fs = new S(313),
        gs = new T(66, -1),
        hs = new T(65, -1),
        is = new S(1256),
        js = new S(369),
        ks = new S(1241, !0),
        ls = new S(368),
        ms = new S(1300, !0),
        ns = new wr(1273, ["en", "de"]),
        os = new S(1223, !0),
        ps = new wr(1261, ["44786015", "44786016"]),
        qs = new S(1309),
        rs = new S(1250),
        ss = new S(1151),
        ts = new S(1361),
        us = new S(1349),
        vs = new T(1072, .75),
        ws = new S(290),
        xs = new S(1222),
        ys = new S(1354),
        zs = new S(1341),
        As = new S(1237),
        Bs = new T(1366),
        Cs = new T(1365),
        Ds = new T(1364,
            300),
        Es = new S(1350),
        Fs = new S(1356),
        Gs = new S(626390500),
        Hs = new xr(627094447, "1 2 4 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 24 30 34".split(" ")),
        Is = new T(643258048),
        Js = new T(643258049),
        Ks = new T(579884443, .7),
        Ls = new vr(622128249),
        Ms = new vr(622128250),
        Ns = new xr(641845510, ["33"]),
        Os = new S(566279275),
        Ps = new S(622128248, !0),
        Qs = new S(566279276),
        Rs = new vr(589752731, "#FFFFFF"),
        Ss = new vr(589752730, "#1A73E8"),
        Ts = new xr(635821288, ["30_19"]),
        Us = new xr(631402549),
        Vs = new xr(636146137, ["30_6"]),
        Ws = new S(579884441, !0),
        Xs = new S(636570127),
        Ys = new xr(627094446, "1 2 4 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 24 30 34".split(" ")),
        Zs = new T(579884442, .7),
        $s = new S(657249372),
        at = new T(652486359),
        bt = new T(626062006, 670),
        ct = new T(658370512),
        dt = new S(626062008),
        et = new S(643258050),
        ft = new S(506914611),
        gt = new S(655991266, !0),
        ht = new S(597181299),
        it = new S(626062007),
        jt = new S(658722541, !0),
        kt = new S(1120),
        lt = new xr(630330362),
        mt = new T(618163195, 15E3),
        nt = new T(624950166, 15E3),
        ot = new T(623405755, 300),
        pt = new T(508040914, 100),
        qt = new T(547455356, 49),
        rt = new T(650548030, 5),
        st = new T(650548032, 300),
        tt = new T(650548031, 2),
        ut = new T(655966487),
        vt = new T(655966486),
        wt = new T(561668774, .1),
        xt = new T(469675170, 6E4),
        yt = new S(562896595),
        zt = new S(644381219),
        At = new S(644381220),
        Bt = new S(661251189),
        Ct = new S(570863962, !0),
        Dt = new vr(570879859, "control_1\\.\\d"),
        Et = new T(570863961, 50),
        Ft = new S(570879858, !0),
        Gt = new T(63, 30),
        Ht = new S(1134),
        It = new S(562874197),
        Jt = new S(562874196),
        Kt = new S(555237685, !0),
        Lt = new S(45460956),
        Mt = new S(45414947, !0),
        Nt = new T(472785970, 500),
        Ot = new T(550718588, 250),
        Pt = new S(45545710),
        Qt = new T(624290870, 50),
        Rt = new T(629793592, .8),
        St = new S(506738118),
        Tt = new S(77),
        Ut = new S(78),
        Vt = new S(83),
        Wt = new S(80),
        Xt = new S(76),
        Yt = new S(84),
        Zt = new S(1973),
        $t = new S(188),
        au = new S(485990406);
    var bu = class {
        constructor() {
            const a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.B = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? a[b] : c;
            this.l = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.i = () => {}
        }
    };

    function U(a) {
        return O(bu).j(a.g, a.defaultValue)
    }

    function V(a) {
        return O(bu).A(a.g, a.defaultValue)
    }

    function cu(a) {
        return O(bu).B(a.g, a.defaultValue)
    }

    function du(a) {
        return O(bu).l(a.g, a.defaultValue)
    };

    function eu(a, b) {
        a = ie(new Xd(a), "DIV");
        const c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function fu(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        tr(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function gu(a) {
        if (a && a.parentNode) {
            const b = a.parentNode;
            b.removeChild(a);
            tr(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var iu = (a, b, c, d = 0) => {
            var e = hu(b, c, d);
            if (e.J) {
                for (c = b = e.J; c = e.pd(c);) b = c;
                e = {
                    anchor: b,
                    position: e.Qd
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            fu(a, e.anchor, e.position)
        },
        ju = (a, b, c, d = 0) => {
            U(fs) ? iu(a, b, c, d) : fu(a, b, c)
        };

    function hu(a, b, c) {
        const d = f => {
                f = ku(f);
                return f == null ? !1 : c < f
            },
            e = f => {
                f = ku(f);
                return f == null ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    J: lu(a.previousSibling, d),
                    pd: f => lu(f.previousSibling, d),
                    Qd: 0
                };
            case 2:
                return {
                    J: lu(a.lastChild, d),
                    pd: f => lu(f.previousSibling, d),
                    Qd: 0
                };
            case 3:
                return {
                    J: lu(a.nextSibling, e),
                    pd: f => lu(f.nextSibling, e),
                    Qd: 3
                };
            case 1:
                return {
                    J: lu(a.firstChild, e),
                    pd: f => lu(f.nextSibling, e),
                    Qd: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function ku(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function lu(a, b) {
        return a && b(a) ? a : null
    };

    function mu(a, b) {
        try {
            const c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function nu(a, b) {
        const c = a.google_reactive_ad_format === 40,
            d = a.google_reactive_ad_format === 16;
        return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
    }

    function ou(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function pu(a, b, c) {
        a = mu(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function qu(a, b) {
        b = b.parentElement;
        return b ? (a = ve(b, a)) ? a.direction : "" : ""
    }

    function ru(a, b, c) {
        if (pu(a, b, c) !== 0) {
            ou(b, c, "0px");
            var d = pu(a, b, c);
            ou(b, c, `${-1*d}px`);
            a = pu(a, b, c);
            a !== 0 && a !== d && ou(b, c, `${d/(a-d)*d}px`)
        }
    };
    const su = RegExp("(^| )adsbygoogle($| )");

    function tu(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = zd(d.property);
            a[e] = d.value
        }
    }

    function uu(a, b, c, d, e, f) {
        a = vu(a, e);
        a.ua.setAttribute("data-ad-format", d ? d : "auto");
        wu(a, b, c, f);
        return a
    }

    function xu(a, b, c = null) {
        a = vu(a, {});
        wu(a, b, null, c);
        return a
    }

    function wu(a, b, c, d) {
        var e = [];
        if (d = d && d.ag) a.nb.className = d.join(" ");
        a = a.ua;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function vu(a, b) {
        const c = eu(a, b.clearBoth || !1);
        var d = c.style;
        d.textAlign = "center";
        b.Pd && tu(d, b.Pd);
        a = ie(new Xd(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.Bf && (d.marginTop = b.Bf);
        b.ue && (d.marginBottom = b.ue);
        b.Yb && tu(d, b.Yb);
        c.appendChild(a);
        return {
            nb: c,
            ua: a
        }
    }

    function yu(a, b, c) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        const d = {
            element: b
        };
        c = c && c.xc();
        if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (e) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (d.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(d)
    }

    function zu(a) {
        const b = ur(a.document);
        Ua(b, function(c) {
            const d = Au(a, c);
            var e;
            if (e = d) {
                e = (e = mu(c, a)) ? e.y : 0;
                const f = P(a);
                e = !(e < f)
            }
            e && (c.setAttribute("data-pub-vars", JSON.stringify(d)), c.removeAttribute("height"), c.style.removeProperty("height"), c.removeAttribute("width"), c.style.removeProperty("width"), yu(a, c))
        })
    }

    function Au(a, b) {
        b = b.getAttribute("google_element_uid");
        a = a.google_sv_map;
        if (!b || !a || !a[b]) return null;
        a = a[b];
        b = {};
        for (let c in rb) a[rb[c]] && (b[rb[c]] = a[rb[c]]);
        return b
    };
    var Cu = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement;
        const e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; d < 10 && b;) {
            if (b == c) return !0;
            if (Bu(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const Bu = (a, b) => {
        if (b.nodeType == 3) return b.nodeType == 3 ? (b = b.data, a = b.indexOf("&") != -1 ? wd(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (b.nodeType == 1) {
            var c = a.getComputedStyle(b);
            if (c.opacity == "0" || c.display == "none" || c.visibility == "hidden") return !1;
            if ((c = b.tagName) && po.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (Bu(a, b[c])) return !0
        }
        return !1
    };
    var Du = a => {
        if (a >= 460) return a = Math.min(a, 1200), Math.ceil(a < 800 ? a / 4 : 200);
        a = Math.min(a, 600);
        return a <= 420 ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    const Eu = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        i(a, b, c, d) {
            return uu(d.document, a, null, null, this.g, b)
        }
        j(a) {
            return Du(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };

    function Fu(a) {
        var b = [];
        ho(a.getElementsByTagName("p"), function(c) {
            Gu(c) >= 100 && b.push(c)
        });
        return b
    }

    function Gu(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        var b = 0;
        ho(a.childNodes, function(c) {
            b += Gu(c)
        });
        return b
    }

    function Hu(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Iu(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function Ju(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.l)
        } catch (g) {}
        if (!c.length) return [];
        b = hb(c);
        b = Iu(a, b);
        typeof a.i === "number" && (c = a.i, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.j === "number") {
            c = [];
            for (var d = 0; d < b.length; d++) {
                var e = Fu(b[d]),
                    f = a.j;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    const Ku = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.l,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };
    class Lu {
        constructor() {
            var a = fd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.g = null;
            this.i = !1;
            this.A = Math.random();
            this.j = this.ba;
            this.B = a
        }
        tf(a) {
            this.g = a
        }
        l(a) {
            this.i = a
        }
        ba(a, b, c = .01, d, e = "jserror") {
            if ((this.i ? this.A : Math.random()) > c) return !1;
            b.error && b.meta && b.id || (b = new rk(b, {
                context: a,
                id: e
            }));
            if (d || this.g) b.meta = {}, this.g && this.g(b.meta), d && d(b.meta);
            q.google_js_errors = q.google_js_errors || [];
            q.google_js_errors.push(b);
            q.error_rep_loaded || (te(q.document, this.B), q.error_rep_loaded = !0);
            return !1
        }
        vb(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.j(a, d, .01, c, "jserror")) throw d;
            }
        }
        Ca(a, b, c, d) {
            return (...e) => this.vb(a, () => b.apply(c, e), d)
        }
        pa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.ba(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    const Mu = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    };
    var Nu = (a, b, c, d, e = !1) => {
            const f = d || window,
                g = typeof queueMicrotask !== "undefined";
            return function() {
                e && g && queueMicrotask(() => {
                    f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                    f.google_rum_task_id_counter += 1
                });
                const h = yk();
                let k, l = 3;
                try {
                    k = b.apply(this, arguments)
                } catch (m) {
                    l = 13;
                    if (!c) throw m;
                    c(a, m)
                } finally {
                    f.google_measure_js_timing && h && Mu({
                        label: a.toString(),
                        value: h,
                        duration: (yk() || 0) - h,
                        type: l,
                        ...(e && g && {
                            taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                        })
                    }, f)
                }
                return k
            }
        },
        Ou = (a, b, c, d = !1) => Nu(a, b, (e, f) => {
            (new Lu).ba(e, f)
        }, c, d);

    function Pu(a, b, c) {
        return Nu(a, b, void 0, c, !0).apply()
    }

    function Qu(a, b) {
        return Ou(754, a, b, !0).apply()
    }

    function Ru(a) {
        if (!a) return null;
        var b = C(a, 7);
        if (C(a, 1) || a.getId() || Wh(a, 4, ch, w()).length > 0) {
            var c = C(a, 3),
                d = C(a, 1),
                e = Wh(a, 4, ch, w($f));
            b = zi(a, 2);
            var f = zi(a, 5);
            a = Su(Ai(a, 6));
            var g = "";
            d && (g += d);
            c && (g += "#" + Hu(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Hu(e[c]);
            b = (e = g) ? new Ku(e, b, f, a) : null
        } else b = b ? new Ku(b, zi(a, 2), zi(a, 5), Su(Ai(a, 6))) : null;
        return b
    }
    var Tu = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Su(a) {
        return a == null ? a : Tu[a]
    }

    function Uu(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = C(a[c], 1),
                e = C(a[c], 2);
            if (d && e != null) {
                var f = {};
                f.property = d;
                f.value = e;
                b.push(f)
            }
        }
        return b
    }

    function Vu(a, b) {
        var c = {};
        a && (c.Bf = C(a, 1), c.ue = C(a, 2), c.clearBoth = !!yi(a, 3));
        b && (c.Pd = Uu(ni(b, Jq, 3, w($f))), a = ni(b, Jq, 4, w($f)), c.Yb = Uu(a));
        return c
    }
    var Wu = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        Xu = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    const Yu = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            return uu(d.document, a, null, null, this.g, b)
        }
        j() {
            return null
        }
    };
    class Zu {
        constructor(a) {
            this.i = a
        }
        g(a) {
            a = Math.floor(a.i);
            const b = Du(a);
            return new cq(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.i,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    const $u = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
        i() {
            return this.l
        }
        g() {
            return this.j
        }
    };
    const av = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            var e = ni(this.g, Kq, 9, w()).length > 0 ? ni(this.g, Kq, 9, w())[0] : null,
                f = Vu(x(this.g, Lq, 3), e);
            if (!e) return null;
            if (e = C(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = ie(new Xd(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                g == "A" && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.Pd && tu(c.style, f.Pd);
                d = ie(new Xd(d), "INS");
                f.Yb && tu(d.style, f.Yb);
                c.appendChild(d);
                f = {
                    nb: c,
                    ua: d
                };
                f.ua.setAttribute("data-ad-type", "text");
                f.ua.setAttribute("data-native-settings-key",
                    e);
                wu(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        j() {
            var a = ni(this.g, Kq, 9, w()).length > 0 ? ni(this.g, Kq, 9, w())[0] : null;
            if (!a) return null;
            a = ni(a, Jq, 3, w());
            for (var b = 0; b < a.length; b++) {
                var c = a[b];
                if (C(c, 1) == "height" && parseInt(C(c, 2), 10) > 0) return parseInt(C(c, 2), 10)
            }
            return null
        }
    };
    const bv = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            if (!this.g) return null;
            const e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    const k = c.item(h);
                    k !== "width" && k !== "height" && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    Yb: g
                }
            } else c = {};
            a = uu(d.document, a, f, e, c, b);
            a.ua.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        j() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        xc() {
            return this.g
        }
    };
    class cv {
        constructor(a) {
            this.i = a
        }
        g() {
            return new cq([], {
                google_ad_type: this.i,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    const dv = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
        g() {
            return this.j
        }
        i(a) {
            a = Ju(this.l, a.document);
            return a.length > 0 ? a[0] : null
        }
    };

    function ev(a, b, c) {
        const d = [];
        for (let r = 0; r < a.length; r++) {
            var e = a[r];
            var f = r,
                g = b,
                h = c,
                k = e.ja();
            if (k) {
                var l = Ru(k);
                if (l) {
                    var m = Ai(e, 2);
                    m = Wu[m];
                    var n = m === void 0 ? null : m;
                    if (n === null) e = null;
                    else {
                        m = (m = x(e, Lq, 3)) ? yi(m, 3) : null;
                        l = new dv(l, n);
                        n = Wh(e, 10, Ig, w()).slice(0);
                        zi(k, 5) != null && n.push(1);
                        var p = h ? h : {};
                        h = zi(e, 12);
                        k = Sh(e, aq, 4) ? x(e, aq, 4) : null;
                        Ai(e, 8) == 1 ? (p = p.Rh || null, e = new fv(l, new Yu(Vu(x(e, Lq, 3), null)), p, m, 0, n, k, g, f, h, e)) : e = Ai(e, 8) == 2 ? new fv(l, new av(e), p.Yi || new cv("text"), m, 1, n, k, g, f, h, e) : null
                    }
                } else e =
                    null
            } else e = null;
            e !== null && d.push(e)
        }
        return d
    }

    function gv(a) {
        return a.A
    }

    function hv(a) {
        return a.Ea
    }

    function iv(a) {
        return U(Tr) ? (a.O || (a.O = a.F.i(a.j)), a.O) : a.F.i(a.j)
    }

    function jv(a) {
        var b = a.H;
        a = a.j.document.createElement("div");
        U(Tr) ? a.className = "google-auto-placed-ad-placeholder" : a.className = "google-auto-placed";
        var c = a.style;
        c.textAlign = "center";
        c.width = "100%";
        c.height = "0px";
        c.clear = b ? "both" : "none";
        return a
    }

    function kv(a) {
        return a.C instanceof bv ? a.C.xc() : null
    }

    function lv(a, b, c) {
        jo(a.I, b) || a.I.set(b, []);
        a.I.get(b).push(c)
    }

    function mv(a, b) {
        a.A = !0;
        U(Tr) && (a.i && gu(a.i), a.i = null);
        b != null && a.ca.push(b)
    }

    function nv(a) {
        return eu(a.j.document, a.H || !1)
    }

    function ov(a) {
        return a.C.j(a.j)
    }

    function pv(a, b = null, c = null) {
        return new fv(a.F, b || a.C, c || a.R, a.H, a.Lb, a.Ac, a.Xd, a.j, a.ta, a.G, a.l, a.B, a.ia)
    }
    class fv {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.F = a;
            this.C = b;
            this.R = c;
            this.H = d;
            this.Lb = e;
            this.Ac = f;
            this.Xd = g ? g : new aq;
            this.j = h;
            this.ta = k;
            this.G = l;
            this.l = m;
            (a = !m) || (a = !(m.ja() && zi(m.ja(), 5) != null));
            this.Ea = !a;
            this.B = n;
            this.ia = p;
            this.ca = [];
            this.A = !1;
            this.I = new no;
            this.O = this.i = null
        }
        da() {
            return this.j
        }
        g() {
            return this.F.g()
        }
    };

    function qv(a, b, c, d, e, f) {
        const g = $p();
        return new fv(new $u(c, e), new Eu, new Zu(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function rv(a, b, c, d, e) {
        const f = $p();
        return new fv(new $u(b, d), new Yu({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var sv = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.win = c
        }
        da() {
            return this.win
        }
        A(a) {
            return qv(a, this.articleStructure, this.element, this.win, 3, null)
        }
        j() {
            return rv(this.articleStructure, this.element, this.win, 3, null)
        }
    };
    const tv = {
        TABLE: {
            mc: new Ep([1, 2])
        },
        THEAD: {
            mc: new Ep([0, 3, 1, 2])
        },
        TBODY: {
            mc: new Ep([0, 3, 1, 2])
        },
        TR: {
            mc: new Ep([0, 3, 1, 2])
        },
        TD: {
            mc: new Ep([0, 3])
        }
    };

    function uv(a, b, c, d) {
        const e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (const f of c) c = Ta(e, f), c < 0 || b.push(new vv(a, [f], c, f, 3, ee(f).trim(), d));
        return b
    }

    function wv(a, b, c) {
        let d = [];
        const e = [],
            f = b.childNodes,
            g = f.length;
        let h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (l.nodeType == 1 || l.nodeType == 3) {
                if (l.nodeType != 1) var m = null;
                else l.tagName == "BR" ? m = l : (m = c.getComputedStyle(l).getPropertyValue("display"), m = m == "inline" || m == "inline-block" ? null : l);
                m ? (d.length && k && e.push(new vv(a, d, n - 1, m, 0, k, c)), d = [], h = n + 1, k = "") : (d.push(l), l = ee(l).trim(), k += l && k ? " " + l : l)
            }
        }
        d.length && k && e.push(new vv(a, d, h, b, 2, k, c));
        return e
    }

    function xv(a, b) {
        return a.g - b.g
    }
    class vv {
        constructor(a, b, c, d, e, f, g) {
            this.l = a;
            this.Zc = b.slice(0);
            this.g = c;
            this.fe = d;
            this.ge = e;
            this.B = f;
            this.i = g
        }
        da() {
            return this.i
        }
        A(a) {
            return qv(a, this.l, this.fe, this.i, this.ge, this.g)
        }
        j() {
            return rv(this.l, this.fe, this.i, this.ge, this.g)
        }
    };

    function yv(a) {
        return eb(a.B ? wv(a.i, a.g, a.j) : [], a.A ? uv(a.i, a.A, a.g, a.j) : []).filter(b => {
            var c = b.fe.tagName;
            c ? (c = tv[c.toUpperCase()], b = c != null && c.mc.contains(b.ge)) : b = !1;
            return !b
        })
    }
    class zv {
        constructor(a, b, c) {
            this.g = a;
            this.A = b.Wc;
            this.B = b.mg;
            this.i = b.articleStructure;
            this.j = c;
            this.l = b.Rf
        }
    };

    function Av(a, b) {
        if (!b) return !1;
        const c = Ea(b),
            d = a.g.get(c);
        if (d != null) return d;
        if (b.nodeType == 1 && (b.tagName == "UL" || b.tagName == "OL") && a.i.getComputedStyle(b).getPropertyValue("list-style-type") != "none") return a.g.set(c, !0), !0;
        b = Av(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function Bv(a, b) {
        return $a(b.Zc, c => Av(a, c))
    }
    class Cv {
        constructor(a) {
            this.g = new no;
            this.i = a
        }
    };
    class Dv {
        constructor(a, b) {
            this.l = a;
            this.g = [];
            this.i = [];
            this.j = b
        }
    };
    var Fv = (a, {
            zg: b = !1,
            uf: c = !1,
            Ig: d = c || U(Sr) ? 2 : 3,
            sf: e = null
        } = {}) => {
            a = yv(a);
            return Ev(a, {
                zg: b,
                uf: c,
                Ig: d,
                sf: e
            })
        },
        Ev = (a, {
            zg: b = !1,
            uf: c = !1,
            Ig: d = c || U(Sr) ? 2 : 3,
            sf: e = null
        } = {}) => {
            if (d < 2) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort(xv);
            a = [];
            b = new Dv(b, e);
            for (const g of f) {
                e = {
                    Rd: g,
                    rd: g.B.length < 51 ? !1 : b.j != null ? !Bv(b.j, g) : !0
                };
                if (b.l || e.rd) b.g.length ? (f = b.g[b.g.length - 1].Rd, f = Cu(f.da(), f.Zc[f.Zc.length - 1], e.Rd.Zc[0])) : f = !0, f ? (b.g.push(e), e.rd && b.i.push(e.Rd)) : (b.g = [e], b.i = e.rd ? [e.Rd] : []);
                if (b.i.length >= d) {
                    e = b;
                    f = c || U(Sr) ? 0 : 1;
                    if (f < 0 || f >= e.i.length) e = null;
                    else {
                        for (f = e.i[f]; e.g.length && !e.g[0].rd;) e.g.shift();
                        e.g.shift();
                        e.i.shift();
                        e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var Hv = (a, b, c = !1) => {
            a = Gv(a, b);
            const d = new Cv(b);
            return yp(a, e => Fv(e, {
                uf: c,
                sf: d
            }))
        },
        Iv = (a, b) => {
            a = Gv(a, b);
            const c = new Cv(b);
            return yp(a, d => {
                if (d.l) {
                    var e = d.i;
                    var f = d.j;
                    d = d.g.querySelectorAll(d.l);
                    var g = [];
                    for (var h of d) g.push(new sv(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        const m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if (l.name.toLowerCase() === "style" && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k =
                            h.element.tagName;k = k === "IMG" || k === "SVG"
                        }(k || h.element.textContent.length > 1) && !Av(c, f.element) && Cu(m.da(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        Gv = (a, b) => {
            const c = new no;
            a.forEach(d => {
                var e = Ru(x(d, Sp, 1));
                if (e) {
                    var f = e.toString();
                    jo(c, f) || c.set(f, {
                        articleStructure: d,
                        Kh: e,
                        Wc: null,
                        mg: !1,
                        Rf: null
                    });
                    e = c.get(f);
                    (f = (f = x(d, Sp, 2)) ? C(f, 7) : null) ? e.Wc = e.Wc ? e.Wc + "," + f : f: e.mg = !0;
                    d = x(d, Sp, 4);
                    e.Rf = d ? C(d, 7) : null
                }
            });
            return mo(c).map(d => {
                const e = Ju(d.Kh, b.document);
                return e.length ? new zv(e[0],
                    d, b) : null
            }).filter(d => d != null)
        };
    var Jv = a => a ? .google_ad_slot ? Fp(new Tp(1, {
            Fh: a.google_ad_slot
        })) : Hp("Missing dimension when creating placement id"),
        Lv = a => {
            switch (a.Lb) {
                case 0:
                case 1:
                    var b = a.l;
                    b == null ? a = null : (a = b.ja(), a == null ? a = null : (b = Ai(b, 2), a = b == null ? null : new Tp(0, {
                        Sf: [a],
                        eh: b
                    })));
                    return a != null ? Fp(a) : Hp("Missing dimension when creating placement id");
                case 2:
                    return a = Kv(a), a != null ? Fp(a) : Hp("Missing dimension when creating placement id");
                default:
                    return Hp("Invalid type: " + a.Lb)
            }
        };
    const Kv = a => {
        if (a == null || a.B == null) return null;
        const b = x(a.B, Sp, 1),
            c = x(a.B, Sp, 2);
        if (b == null || c == null) return null;
        const d = a.ia;
        if (d == null) return null;
        a = a.g();
        return a == null ? null : new Tp(0, {
            Sf: [b, c],
            Xi: d,
            eh: Xu[a]
        })
    };

    function Mv(a) {
        const b = kv(a.ha);
        return (b ? Jv(b) : Lv(a.ha)).map(c => Wp(c))
    }

    function Nv(a) {
        a.g = a.g || Mv(a);
        return a.g
    }

    function Ex(a, b) {
        if (a.ha.A) throw Error("AMA:AP:AP");
        ju(b, a.ja(), a.ha.g());
        mv(a.ha, b)
    }
    const Fx = class {
        constructor(a, b, c) {
            this.ha = a;
            this.i = b;
            this.la = c;
            this.g = null
        }
        ja() {
            return this.i
        }
        fill(a, b) {
            var c = this.ha;
            (a = c.C.i(a, b, this.i, c.j)) && Ex(this, a.nb);
            return a
        }
    };

    function Gx(a, b) {
        return Qu(() => {
            if (U(Tr)) {
                var c = [],
                    d = [];
                for (var e = 0; e < a.length; e++) {
                    var f = a[e],
                        g = iv(f);
                    if (g) {
                        if (!f.i && !f.A) {
                            a: {
                                var h = null;
                                try {
                                    var k = iv(f);
                                    if (k) {
                                        h = jv(f);
                                        ju(h, k, f.g());
                                        var l = h;
                                        break a
                                    }
                                    l = null;
                                    break a
                                } catch (r) {
                                    throw gu(h), r;
                                }
                                l = void 0
                            }
                            f.i = l
                        }(h = f.i) && d.push({
                            Aj: f,
                            anchorElement: g,
                            Ji: h
                        })
                    }
                }
                if (d.length > 0)
                    for (l = bo(b), k = co(b), e = 0; e < d.length; e++) {
                        const {
                            Aj: r,
                            anchorElement: y,
                            Ji: D
                        } = d[e];
                        f = Hx(D, k, l);
                        c.push(new Fx(r, y, f))
                    }
                l = c
            } else {
                l = [];
                k = [];
                try {
                    const r = [];
                    for (let y = 0; y < a.length; y++) {
                        var m = a[y],
                            n = iv(m);
                        n && r.push({
                            Vg: m,
                            anchorElement: n
                        })
                    }
                    for (n = 0; n < r.length; n++) {
                        m = k;
                        g = m.push; {
                            var p = r[n];
                            const y = p.anchorElement,
                                D = p.Vg,
                                E = jv(D);
                            try {
                                ju(E, y, D.g()), h = E
                            } catch (G) {
                                throw gu(E), G;
                            }
                        }
                        g.call(m, h)
                    }
                    c = bo(b);
                    d = co(b);
                    for (g = 0; g < k.length; g++) e = Hx(k[g], d, c), f = r[g], l.push(new Fx(f.Vg, f.anchorElement, e))
                } finally {
                    for (c = 0; c < k.length; c++) gu(k[c])
                }
            }
            return l
        }, b)
    }

    function Hx(a, b, c) {
        a = a.getBoundingClientRect();
        return new pp(a.left + b, a.top + c, a.right - a.left)
    };
    const Ix = {
            1: "0.5vp",
            2: "300px"
        },
        Jx = {
            1: 700,
            2: 1200
        },
        Kx = {
            [1]: {
                mh: "3vp",
                wf: "1vp",
                lh: "0.3vp"
            },
            [2]: {
                mh: "900px",
                wf: "300px",
                lh: "90px"
            }
        };

    function Lx(a, b, c) {
        var d = Mx(a),
            e = P(a) || Jx[d],
            f = void 0;
        c && (f = (c = (c = Nx(ni(c, jq, 2, w()), d)) ? x(c, hq, 7) : void 0) ? Ox(c, e) : void 0);
        c = f;
        f = Mx(a);
        a = P(a) || Jx[f];
        const g = Px(Kx[f].wf, a);
        a = g === null ? Qx(f, a) : new Rx(g, g, Sx(g, 8), 8, .3, c);
        c = Px(Kx[d].mh, e);
        f = Px(Kx[d].wf, e);
        d = Px(Kx[d].lh, e);
        e = a.j;
        c && d && f && b !== void 0 && (e = b <= .5 ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) * (f - d));
        return new Rx(e, e, Sx(e, a.i), a.i, a.l, a.g)
    }

    function Tx(a, b) {
        const c = Yg(Nh(a, 4));
        a = Vh(a, 5);
        return c == null || a == null ? b : new Rx(a, 0, [], c, 1)
    }

    function Ux(a, b) {
        const c = Mx(a);
        a = P(a) || Jx[c];
        if (!b) return Qx(c, a);
        if (b = Nx(ni(b, jq, 2, w()), c))
            if (b = Vx(b, a)) return b;
        return Qx(c, a)
    }

    function Wx(a) {
        const b = Mx(a);
        a = P(a) || Jx[b];
        return Qx(b, a)
    }

    function Xx(a, b) {
        let c = {
            Hc: a.j,
            tb: a.B
        };
        for (let d of a.A) d.adCount <= b && (c = d.Nc);
        return c
    }

    function Yx(a, b, c) {
        var d = yi(b, 2);
        b = x(b, jq, 1);
        var e = Mx(c);
        var f = P(c) || Jx[e];
        c = Px(b ? .B(), f) ? ? a.j;
        e = Px(b ? .A(), f) ? ? a.B;
        d = d ? [] : Zx(b ? .g(), f) ? ? a.A;
        const g = b ? .j() ? ? a.i,
            h = b ? .l() ? ? a.l;
        a = (b ? .C() ? Ox(x(b, hq, 7), f) : null) ? ? a.g;
        return new Rx(c, e, d, g, h, a)
    }

    function $x(a, b) {
        var c = Mx(b);
        const d = new kq,
            e = new jq;
        let f = !1;
        var g = V(Yr);
        g >= 0 && (Li(e, 4, g), f = !0);
        g = null;
        c === 1 ? (c = V(bs), c >= 0 && (g = c + "vp")) : (c = V(as), c >= 0 && (g = c + "px"));
        c = V($r);
        c >= 0 && (g = c + "px");
        g !== null && (Pi(e, 2, g), f = !0);
        c = U(ds) ? "0px" : null;
        c !== null && (Pi(e, 5, c), f = !0);
        if (U(es)) Ki(d, 2, !0), f = !0;
        else if (c !== null || g !== null) {
            const m = [];
            for (const n of a.A) {
                var h = m,
                    k = h.push;
                var l = new iq;
                l = Li(l, 1, n.adCount);
                l = Pi(l, 3, c ? ? n.Nc.tb + "px");
                l = Pi(l, 2, g ? ? n.Nc.Hc + "px");
                k.call(h, l)
            }
            oi(e, 3, m)
        }
        return f ? (A(d, 1, e), Yx(a, d, b)) : a
    }
    class Rx {
        constructor(a, b, c, d, e, f) {
            this.j = a;
            this.B = b;
            this.A = c.sort((g, h) => g.adCount - h.adCount);
            this.i = d;
            this.l = e;
            this.g = f
        }
    }

    function Nx(a, b) {
        for (let c of a)
            if (Ai(c, 1) == b) return c;
        return null
    }

    function Zx(a, b) {
        if (a === void 0) return null;
        const c = [];
        for (let d of a) {
            a = zi(d, 1);
            const e = Px(C(d, 2), b),
                f = Px(C(d, 3), b);
            if (typeof a !== "number" || e === null) return null;
            c.push({
                adCount: a,
                Nc: {
                    Hc: e,
                    tb: f
                }
            })
        }
        return c
    }

    function Vx(a, b) {
        const c = Px(C(a, 2), b),
            d = Px(C(a, 5), b);
        if (c === null) return null;
        const e = zi(a, 4);
        if (e == null) return null;
        var f = a.g();
        f = Zx(f, b);
        if (f === null) return null;
        const g = x(a, hq, 7);
        b = g ? Ox(g, b) : void 0;
        return new Rx(c, d, f, e, Vh(a, 6), b)
    }

    function Qx(a, b) {
        a = Px(Ix[a], b);
        return U(Wr) ? new Rx(a === null ? Infinity : a, null, [], 8, .3) : new Rx(a === null ? Infinity : a, null, [], 3, null)
    }

    function Px(a, b) {
        if (!a) return null;
        const c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function Mx(a) {
        a = Un(a) >= 900;
        return ke() && !a ? 1 : 2
    }

    function Sx(a, b) {
        if (b < 4) return [];
        const c = Math.ceil(b / 2);
        return [{
            adCount: c,
            Nc: {
                Hc: a * 2,
                tb: a * 2
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            Nc: {
                Hc: a * 3,
                tb: a * 3
            }
        }]
    }

    function Ox(a, b) {
        const c = Px(C(a, 2), b) || 0,
            d = zi(a, 3) || 1;
        a = Px(C(a, 1), b) || 0;
        return {
            Jg: c,
            Hg: d,
            ec: a
        }
    };

    function ay(a, b, c) {
        return Nn({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function by(a) {
        if (!a.length) return null;
        const b = On(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.i, 0);
        return new cy(b, a)
    }
    class cy {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };
    let dy, W;
    const ey = new Gk(q);
    ((a, b = !0) => {
        dy = a || new Gn;
        typeof q.google_srt !== "number" && (q.google_srt = Math.random());
        Fn(dy, q.google_srt);
        W = new Qk(dy, b, ey);
        W.l(!0);
        q.document.readyState == "complete" ? q.google_measure_js_timing || Ek(ey) : ey.g && Hb(q, "load", () => {
            q.google_measure_js_timing || Ek(ey)
        })
    })();
    var fy = (a, b) => W.vb(a, b),
        gy = (a, b) => W.Ca(a, b),
        hy = (a, b, c) => {
            const d = O(Dn).g();
            !b.eid && d.length && (b.eid = d.toString());
            Pk(dy, a, b, !0, c)
        },
        iy = (a, b, c) => {
            W.pa(a, b, c)
        };

    function jy(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    var oy = (a, b) => {
        var c = hb(b.document.querySelectorAll(".google-auto-placed"));
        const d = hb(b.document.querySelectorAll("ins.adsbygoogle[data-anchor-status]")),
            e = ky(b),
            f = ly(b),
            g = my(b),
            h = hb(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = hb(b.document.querySelectorAll("div.googlepublisherpluginad")),
            l = hb(b.document.querySelectorAll("html > ins.adsbygoogle"));
        let m = [].concat(hb(b.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), hb(b.document.querySelectorAll("body ins.adsbygoogle")));
        b = [];
        for (const [n, p] of [
                [a.qd, c],
                [a.Kb, d],
                [a.Vi, e],
                [a.Se, f],
                [a.Te, g],
                [a.Ti, h],
                [a.Ui, k],
                [a.Wi, l]
            ]) n === !1 ? b = b.concat(p) : m = m.concat(p);
        a = ny(m);
        c = ny(b);
        a = a.slice(0);
        for (const n of c)
            for (c = 0; c < a.length; c++)(n.contains(a[c]) || a[c].contains(n)) && a.splice(c, 1);
        return a
    };
    const py = a => {
            const b = jy(a);
            return b ? Wa(Xa(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
        },
        ky = a => hb(a.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]")),
        ly = a => (py(a) || hb(a.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(hb(a.document.querySelectorAll("iframe[id^=google_ads_iframe]"))),
        my = a => hb(a.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"));
    var ny = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };
    var qy = W.Ca(453, oy),
        ry;
    ry = W.Ca(454, (a, b) => {
        const c = hb(b.document.querySelectorAll(".google-auto-placed")),
            d = hb(b.document.querySelectorAll("ins.adsbygoogle[data-anchor-status]")),
            e = ky(b),
            f = ly(b),
            g = my(b),
            h = hb(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = hb(b.document.querySelectorAll("div.googlepublisherpluginad"));
        b = hb(b.document.querySelectorAll("html > ins.adsbygoogle"));
        return ny([].concat(a.qd === !0 ? c : [], a.Kb === !0 ? d : [], a.Vi === !0 ? e : [], a.Se === !0 ? f : [], a.Te === !0 ? g : [], a.Ti === !0 ? h : [], a.Ui === !0 ? k : [], a.Wi ===
            !0 ? b : []))
    });

    function sy(a, b, c) {
        const d = ty(a);
        b = uy(d, b, c);
        return new vy(a, d, b)
    }

    function wy(a) {
        return (a.bottom - a.top) * (a.right - a.left) > 1
    }

    function xy(a) {
        return a.g.map(b => b.box)
    }

    function yy(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    class vy {
        constructor(a, b, c) {
            this.j = a;
            this.g = b.slice(0);
            this.l = c.slice(0);
            this.i = null
        }
    }

    function ty(a) {
        const b = qy({
                Kb: !1
            }, a),
            c = co(a),
            d = bo(a);
        return b.map(e => {
            const f = e.getBoundingClientRect();
            return (e = !!e.className && e.className.indexOf("google-auto-placed") != -1) || wy(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                ao: e ? 1 : 0
            } : null
        }).filter(zb(e => e === null))
    }

    function uy(a, b, c) {
        return b != void 0 && a.length <= (c != void 0 ? c : 8) ? zy(a, b) : Xa(a, d => new cy(d.box, 1))
    }

    function zy(a, b) {
        a = Xa(a, d => new cy(d.box, 1));
        const c = [];
        for (; a.length > 0;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (ay(d, a[f], b)) {
                        d = by([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function Ay(a, b, c) {
        const d = op(c, b);
        return !$a(a, e => Nn(e, d))
    }

    function By(a, b, c, d, e) {
        e = e.la;
        const f = op(e, b),
            g = op(e, c),
            h = op(e, d);
        return !$a(a, k => Nn(k, g) || Nn(k, f) && !Nn(k, h))
    }

    function Cy(a, b, c, d) {
        const e = xy(a);
        if (Ay(e, b, d.la)) return !0;
        if (!By(e, b, c.Jg, c.ec, d)) return !1;
        const f = new cy(op(d.la, 0), 1);
        a = Wa(a.l, g => ay(g, f, c.ec));
        b = Ya(a, (g, h) => g + h.i, 1);
        return a.length === 0 || b > c.Hg ? !1 : !0
    };
    var Dy = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function Ey(a, b) {
        const c = new Op,
            d = new oo;
        b.forEach(e => {
            if (Gi(e, rq, 1, uq)) {
                e = Gi(e, rq, 1, uq);
                if (x(e, qq, 1) && x(e, qq, 1).ja() && x(e, qq, 2) && x(e, qq, 2).ja()) {
                    const g = Fy(a, x(e, qq, 1).ja()),
                        h = Fy(a, x(e, qq, 2).ja());
                    if (g && h)
                        for (var f of Dy({
                                anchor: g,
                                position: Ai(x(e, qq, 1), 2)
                            }, {
                                anchor: h,
                                position: Ai(x(e, qq, 2), 2)
                            })) c.set(Ea(f.anchor), f.position)
                }
                x(e, qq, 3) && x(e, qq, 3).ja() && (f = Fy(a, x(e, qq, 3).ja())) && c.set(Ea(f), Ai(x(e, qq, 3), 2))
            } else Gi(e, sq, 2, uq) ? Gy(a, Gi(e, sq, 2, uq), c) : Gi(e, pq, 3, uq) && Hy(a, Gi(e, pq, 3, uq), d)
        });
        return new Iy(c,
            d)
    }
    class Iy {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    }
    const Gy = (a, b, c) => {
            x(b, qq, 2) ? (b = x(b, qq, 2), (a = Fy(a, b.ja())) && c.set(Ea(a), Ai(b, 2))) : x(b, Sp, 1) && (a = Jy(a, x(b, Sp, 1))) && a.forEach(d => {
                d = Ea(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        Hy = (a, b, c) => {
            x(b, Sp, 1) && (a = Jy(a, x(b, Sp, 1))) && a.forEach(d => {
                c.add(Ea(d))
            })
        },
        Fy = (a, b) => (a = Jy(a, b)) && a.length > 0 ? a[0] : null,
        Jy = (a, b) => (b = Ru(b)) ? Ju(b, a) : null;
    var Ky = class {
        constructor() {
            this.g = Xe();
            this.i = 0
        }
    };

    function Ly(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (My(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function Ny(a) {
        a = Oy(a);
        return a.has("all") || a.has("after")
    }

    function Py(a) {
        a = Oy(a);
        return a.has("all") || a.has("before")
    }

    function Oy(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function My(a) {
        const b = Oy(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var Qy = class {
        constructor() {
            this.g = new Set;
            this.i = new Ky
        }
    };

    function Ry(a) {
        return function(b) {
            return Gx(b, a)
        }
    }

    function Sy(a) {
        const b = P(a);
        return b ? Ka(Ty, b + bo(a)) : wb
    }

    function Uy(a, b, c) {
        if (a < 0) throw Error("ama::ead:nd");
        if (a === Infinity) return wb;
        const d = xy(c || sy(b));
        return e => Ay(d, a, e.la)
    }

    function Vy(a, b, c, d) {
        if (a < 0 || b.Jg < 0 || b.Hg < 0 || b.ec < 0) throw Error("ama::ead:nd");
        return a === Infinity ? wb : e => Cy(d || sy(c, b.ec), a, b, e)
    }

    function Wy(a) {
        if (!a.length) return wb;
        const b = new Ep(a);
        return c => b.contains(c.Lb)
    }

    function Xy(a) {
        return function(b) {
            for (let c of b.Ac)
                if (a.indexOf(c) > -1) return !1;
            return !0
        }
    }

    function Yy(a) {
        return a.length ? function(b) {
            const c = b.Ac;
            return a.some(d => c.indexOf(d) > -1)
        } : xb
    }

    function Zy(a, b) {
        if (a <= 0) return xb;
        const c = Yn(b).scrollHeight - a;
        return function(d) {
            return d.la.g <= c
        }
    }

    function $y(a) {
        const b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[Ai(c.Xd, 2) || 0]
        }
    }

    function az(a) {
        return a.length ? b => a.includes(Ai(b.Xd, 1) || 0) : xb
    }

    function bz(a, b) {
        const c = Ey(a, b);
        return function(d) {
            var e = d.ja();
            d = Xu[d.ha.g()];
            var f = c.i,
                g = Ea(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(Ea(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(Ea(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function cz() {
        const a = new Qy;
        return function(b) {
            var c = b.ja(),
                d = Xu[b.ha.g()];
            a: switch (d) {
                case 1:
                    b = Ny(c.previousElementSibling) || Py(c);
                    break a;
                case 4:
                    b = Ny(c) || Py(c.nextElementSibling);
                    break a;
                case 2:
                    b = Py(c.firstElementChild);
                    break a;
                case 3:
                    b = Ny(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = Ly(a, c, d);
            d = a.i;
            hy("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.i++,
                dvc: Me()
            }, .1);
            return !(b || c)
        }
    }
    const Ty = (a, b) => b.la.g >= a,
        dz = (a, b, c) => {
            c = c.la.i;
            return a <= c && c <= b
        };

    function ez(a, b, c, d, e) {
        var f = fz(gz(a, b), a);
        if (f.length === 0) {
            var g = !!x(b, Iq, 6) ? .g() ? .length;
            f = x(b, Dq, 28) ? .l() ? .j() && g ? fz(hz(a, b), a) : f
        }
        if (f.length === 0) return mr(d, "pfno"), [];
        b = f;
        a = e.hd ? iz(a, b, c) : {
            kb: b,
            kd: null
        };
        const {
            kb: h,
            kd: k
        } = a;
        f = h;
        return f.length === 0 && k ? (mr(d, k), []) : [f[e.Xj ? 0 : e.Wj ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function iz(a, b, c) {
        c = c ? ni(c, tq, 5, w($f)) : [];
        const d = bz(a.document, c),
            e = cz();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            kb: [],
            kd: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            kb: [],
            kd: "pfet"
        } : {
            kb: b,
            kd: null
        }
    }

    function jz(a, b) {
        return a.la.g - b.la.g
    }

    function gz(a, b) {
        const c = x(b, Iq, 6);
        if (!c) return [];
        b = x(b, Dq, 28) ? .l();
        return (b ? .g() ? Iv(c.g($f), a) : Hv(c.g($f), a, !!b ? .l())).map(d => d.j())
    }

    function hz(a, b) {
        b = ni(b, Mq, 1, w($f)) || [];
        return ev(b, a, {}).filter(c => !c.Ac.includes(6))
    }

    function fz(a, b) {
        a = Gx(a, b);
        const c = Sy(b);
        a = a.filter(d => c(d));
        return a.sort(jz)
    };
    var kz = {},
        lz = {},
        mz = {},
        nz = {};

    function oz() {
        throw Error("Do not instantiate directly");
    }
    oz.prototype.cg = null;
    oz.prototype.Ja = function() {
        return this.content
    };
    oz.prototype.toString = function() {
        return this.content
    };

    function pz(a) {
        if (a.dg !== kz) throw Error("Sanitized content was not of kind HTML.");
        return Mc(a.toString())
    }

    function qz() {
        oz.call(this)
    }
    Ma(qz, oz);
    qz.prototype.dg = kz;

    function rz(a) {
        if (a != null) switch (a.cg) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function sz(a) {
        return tz(a, kz) ? a : a instanceof Lc ? uz(Kc(a).toString()) : uz(String(String(a)).replace(vz, wz), rz(a))
    }
    var uz = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            d !== void 0 && (c.cg = d);
            return c
        }
    }(qz);

    function xz(a) {
        return yz(String(a), () => "").replace(zz, "&lt;")
    }
    const Az = RegExp.prototype.hasOwnProperty("sticky"),
        Bz = new RegExp((Az ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", Az ? "gy" : "g");

    function yz(a, b) {
        const c = [],
            d = a.length;
        let e = 0,
            f = [],
            g, h, k = 0;
        for (; k < d;) {
            switch (e) {
                case 0:
                    var l = a.indexOf("<", k);
                    if (l < 0) {
                        if (c.length === 0) return a;
                        c.push(a.substring(k));
                        k = d
                    } else c.push(a.substring(k, l)), h = l, k = l + 1, Az ? (Bz.lastIndex = k, l = Bz.exec(a)) : (Bz.lastIndex = 0, l = Bz.exec(a.substring(k))), l ? (f = ["<", l[0]], g = l[1], e = 1, k += l[0].length) : c.push("<");
                    break;
                case 1:
                    l = a.charAt(k++);
                    switch (l) {
                        case "'":
                        case '"':
                            let m = a.indexOf(l, k);
                            m < 0 ? k = d : (f.push(l, a.substring(k, m + 1)), k = m + 1);
                            break;
                        case ">":
                            f.push(l);
                            c.push(b(f.join(""),
                                g));
                            e = 0;
                            f = [];
                            h = g = null;
                            break;
                        default:
                            f.push(l)
                    }
                    break;
                default:
                    throw Error();
            }
            e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
        }
        return c.join("")
    }

    function Cz(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    }

    function Dz(a) {
        return tz(a, kz) ? String(xz(a.Ja())).replace(Ez, wz) : String(a).replace(vz, wz)
    }

    function Fz(a) {
        return tz(a, kz) ? String(xz(a.Ja())).replace(Gz, wz) : String(a).replace(Hz, wz)
    }
    const Iz = /['()]/g;

    function Jz(a) {
        return "%" + a.charCodeAt(0).toString(16)
    }

    function X(a) {
        tz(a, nz) ? a = Cz(a.Ja()) : a == null ? a = "" : a instanceof xc ? a = Cz(yc(a)) : a instanceof zc ? a = Cz(Ac(a)) : (a = String(a), a = Kz.test(a) ? a : "zSoyz");
        return a
    }

    function tz(a, b) {
        return a != null && a.dg === b
    }
    const Lz = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function wz(a) {
        return Lz[a]
    }
    const Mz = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function Nz(a) {
        return Mz[a]
    }
    const Oz = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function Pz(a) {
        return Oz[a]
    }
    const vz = /[\x00\x22\x26\x27\x3c\x3e]/g,
        Ez = /[\x00\x22\x27\x3c\x3e]/g,
        Hz = /[\x00\x09-\x0d \x22\x26\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        Gz = /[\x00\x09-\x0d \x22\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        Qz = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        Rz = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Kz = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\((?:(?:(?:(?:\/(?![\/\*]))|(?:\*(?!\/)))?[-\u0020\t,+.!#%_0-9a-zA-Z]+)*|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\((?:(?:(?:\/(?![\/\*]))|(?:\*(?!\/)))?[-\u0020\t,+.!#%_0-9a-zA-Z]+)*\))+\)|[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e-?[0-9]+)?(?:[a-z]{1,4}|%)?|(?:(?:\/(?![\/\*]))|(?:\*(?!\/)))|!important)(?:\s*[,\u0020]\s*|$))*$/i,
        Sz =
        /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i,
        zz = /</g;
    /* 
     
     
     Copyright Mathias Bynens <http://mathiasbynens.be/> 
     
     Permission is hereby granted, free of charge, to any person obtaining 
     a copy of this software and associated documentation files (the 
     "Software"), to deal in the Software without restriction, including 
     without limitation the rights to use, copy, modify, merge, publish, 
     distribute, sublicense, and/or sell copies of the Software, and to 
     permit persons to whom the Software is furnished to do so, subject to 
     the following conditions: 
     
     The above copyright notice and this permission notice shall be 
     included in all copies or substantial portions of the Software. 
     
     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
     EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
     MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
     NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
     LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
     OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
     WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
    */
    const Tz = Math.floor;
    var Uz = /^xn--/,
        Vz = /[\x2E\u3002\uFF0E\uFF61]/g;
    const Wz = {
        Pm: "Overflow: input needs wider integers to process",
        Lm: "Illegal input >= 0x80 (not a basic code point)",
        wm: "Invalid input"
    };

    function Xz(a) {
        throw RangeError(Wz[a]);
    }

    function Yz(a, b) {
        const c = a.split("@");
        let d = "";
        c.length > 1 && (d = c[0] + "@", a = c[1]);
        a = a.replace(Vz, ".");
        a = a.split(".").map(b).join(".");
        return d + a
    }

    function Zz(a) {
        return Yz(a, b => {
            if (Uz.test(b) && b.length > 4) {
                b = b.slice(4).toLowerCase();
                const h = [],
                    k = b.length;
                let l = 0,
                    m = 128;
                var c = 72,
                    d = b.lastIndexOf("-");
                d < 0 && (d = 0);
                for (var e = 0; e < d; ++e) b.charCodeAt(e) >= 128 && Xz("Illegal input >= 0x80 (not a basic code point)"), h.push(b.charCodeAt(e));
                for (d = d > 0 ? d + 1 : 0; d < k;) {
                    e = l;
                    for (let n = 1, p = 36;; p += 36) {
                        d >= k && Xz("Invalid input");
                        var f = b.charCodeAt(d++);
                        f = f - 48 < 10 ? f - 22 : f - 65 < 26 ? f - 65 : f - 97 < 26 ? f - 97 : 36;
                        (f >= 36 || f > Tz((2147483647 - l) / n)) && Xz("Overflow: input needs wider integers to process");
                        l += f * n;
                        var g = p <= c ? 1 : p >= c + 26 ? 26 : p - c;
                        if (f < g) break;
                        f = 36 - g;
                        n > Tz(2147483647 / f) && Xz("Overflow: input needs wider integers to process");
                        n *= f
                    }
                    f = h.length + 1;
                    c = l - e;
                    g = 0;
                    c = e == 0 ? Tz(c / 700) : c >> 1;
                    for (c += Tz(c / f); c > 455; g += 36) c = Tz(c / 35);
                    c = Tz(g + 36 * c / (c + 38));
                    Tz(l / f) > 2147483647 - m && Xz("Overflow: input needs wider integers to process");
                    m += Tz(l / f);
                    l %= f;
                    h.splice(l++, 0, m)
                }
                b = String.fromCodePoint.apply(null, h)
            }
            return b
        })
    };
    const $z = new sb(tb, "558153351");

    function aA(a, b, c) {
        var d = a.Oa.contentWindow;
        const e = !a.A && typeof a.g === "number";
        a.B ? (b = {
            action: "search",
            searchTerm: b,
            rsToken: c
        }, e && (b.experimentId = a.g), a.i.length > 0 && (b.adfiliateWp = a.i), d.postMessage(b, "https://www.gstatic.com")) : (d = d.google.search.cse.element.getElement(a.C), c = {
            rsToken: c,
            hostName: a.host
        }, e && (c.afsExperimentId = a.g), a.i.length > 0 && (c.adfiliateWp = a.i), d.execute(b, void 0, c))
    }
    var bA = class {
        constructor(a, b, c, d, e, f, g, h, k, l, m, n = !1, p = !1, r = !1, y = "") {
            this.Oa = a;
            this.l = b;
            this.C = c;
            this.j = d;
            this.O = e;
            this.host = f.host;
            this.origin = f.origin;
            this.language = g;
            this.G = h;
            this.g = k;
            this.H = n;
            this.B = l;
            this.F = m;
            this.I = p;
            this.A = r;
            this.i = y
        }
        J() {
            this.Oa.setAttribute("id", "prose-iframe");
            this.Oa.setAttribute("width", "100%");
            this.Oa.setAttribute("height", "100%");
            var a = hd `box-sizing:border-box;border:unset;`;
            this.Oa.style.cssText = yc(a);
            var b = tc("https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(this.host)),
                c = Zz(this.host.startsWith("www.") ? this.host.slice(4) : this.host);
            a = this.C;
            var d = this.j,
                e = this.O;
            const f = this.host;
            c = this.G.replace("${website}", c);
            const g = this.I;
            var h = uz,
                k = "<style>.cse-favicon {display: block; float: left; height: 16px; position: absolute; left: 15px; width: 16px;}.cse-header {font-size: 16px; font-family: Arial; margin-left: 35px; margin-top: 6px; margin-bottom: unset; line-height: 16px;}.gsc-search-box {max-width: 520px !important;}.gsc-input {padding-right: 0 !important;}.gsc-input-box {border-radius: 16px 0 0 16px !important;}.gsc-search-button-v2 {border-left: 0 !important; border-radius: 0 16px 16px 0 !important; min-height: 30px !important; margin-left: 0 !important;}.gsc-cursor-page, .gsc-cursor-next-page, .gsc-cursor-numbered-page {color: #1a73e8 !important;}.gsc-cursor-chevron {fill: #1a73e8 !important;}.gsc-cursor-box {text-align: center !important;}.gsc-cursor-current-page {color: #000 !important;}.gcsc-find-more-on-google-root, .gcsc-find-more-on-google {display: none !important;}.prose-container {max-width: 652px;}#prose-empty-serp-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 52px; position: relative; width: 248px; height: 259px; margin: auto; top: 100px;}#prose-empty-serp-icon-image {display: flex; flex-direction: row; justify-content: center; align-items: center; padding: 30px; gap: 10px; width: 124px; height: 124px; border-radius: 62px; flex: none; order: 1; flex-grow: 0; position: absolute; top: 0;}#prose-empty-serp-text-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 19px; width: 248px; height: 83px; flex: none; order: 2; align-self: stretch; flex-grow: 0; position: absolute; top: 208px;}#prose-empty-serp-text-div {display: flex; flex-direction: column; align-items: flex-start; padding: 0; gap: 11px; width: 248px; height: 83px; flex: none; order: 0; align-self: stretch; flex-grow: 0;}#prose-empty-serp-supporting-text {width: 248px; height: 40px; font-family: 'Arial'; font-style: normal; font-weight: 400; font-size: 14px; line-height: 20px; text-align: center; letter-spacing: 0.2px; color: #202124; flex: none; order: 1; align-self: stretch; flex-grow: 0;}</style>" +
                (this.H ? '<script>window.__gcse={initializationCallback:function(){top.postMessage({action:"init",adChannel:"' + String(e).replace(Qz, Nz) + '"},top.location.origin);}};\x3c/script>' : "") + '<div class="prose-container"><img class="cse-favicon" src="';
            tz(b, lz) || tz(b, mz) ? b = String(b).replace(Rz, Pz) : b instanceof mc ? b = String(oc(b)).replace(Rz, Pz) : b instanceof cc ? b = String(dc(b).toString()).replace(Rz, Pz) : (b = String(b), b = Sz.test(b) ? b.replace(Rz, Pz) : "about:invalid#zSoyz");
            a = h(k + Dz(b) + '" alt="' + Dz(f) + ' icon"><p class="cse-header"><strong>' +
                sz(c) + '</strong></p><div class="gcse-search" data-gname="' + Dz(a) + '" data-adclient="' + Dz(d) + '" data-adchannel="' + Dz(e) + '" data-as_sitesearch="' + Dz(f) + '" data-personalizedAds="false"></div></div>' + (g ? "<div id=\"prose-empty-serp-container\"><img id='prose-empty-serp-icon-image' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI0IiBoZWlnaHQ9IjEyNCIgdmlld0JveD0iMCAwIDEyNCAxMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjQiIGhlaWdodD0iMTI0IiByeD0iNjIiIGZpbGw9IiNGMUYzRjQiLz4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02OS4zNiA2NS4zODY3TDg0LjY0IDgwLjY2NjdMODAuNjY2NyA4NC42NEw2NS4zODY3IDY5LjM2QzYyLjUzMzMgNzEuNDEzMyA1OS4wOTMzIDcyLjY2NjcgNTUuMzMzMyA3Mi42NjY3QzQ1Ljc2IDcyLjY2NjcgMzggNjQuOTA2NyAzOCA1NS4zMzMzQzM4IDQ1Ljc2IDQ1Ljc2IDM4IDU1LjMzMzMgMzhDNjQuOTA2NyAzOCA3Mi42NjY3IDQ1Ljc2IDcyLjY2NjcgNTUuMzMzM0M3Mi42NjY3IDU5LjA5MzMgNzEuNDEzMyA2Mi41MzMzIDY5LjM2IDY1LjM4NjdaTTU1LjMzMzMgNDMuMzMzM0M0OC42OTMzIDQzLjMzMzMgNDMuMzMzMyA0OC42OTMzIDQzLjMzMzMgNTUuMzMzM0M0My4zMzMzIDYxLjk3MzMgNDguNjkzMyA2Ny4zMzMzIDU1LjMzMzMgNjcuMzMzM0M2MS45NzMzIDY3LjMzMzMgNjcuMzMzMyA2MS45NzMzIDY3LjMzMzMgNTUuMzMzM0M2Ny4zMzMzIDQ4LjY5MzMgNjEuOTczMyA0My4zMzMzIDU1LjMzMzMgNDMuMzMzM1oiIGZpbGw9IiM5QUEwQTYiLz4KPC9zdmc+Cg==' alt=''><div id='prose-empty-serp-text-container'><div id='prose-empty-serp-text-div'><div id='prose-empty-serp-supporting-text'>Search this website by entering a keyword.</div></div></div></div>" :
                    ""));
            a = pz(a);
            this.B ? (a = this.Oa, d = ec(new sb(tb, "https://www.gstatic.com/prose/protected/%{version}/iframe.html?cx=%{cxId}&host=%{host}&hl=%{lang}&lrh=%{lrh}&client=%{client}&origin=%{origin}"), {
                version: this.F || $z,
                cxId: this.l,
                host: this.host,
                lang: this.language,
                lrh: this.G,
                client: this.j,
                origin: this.origin
            }), a.src = dc(d).toString()) : (d = new Map([
                ["cx", this.l],
                ["language", this.language]
            ]), this.A && (e = Array.isArray(this.g) ? this.g : [this.g], e.length && d.set("fexp", e.join())), e = gd(fd `https://cse.google.com/cse.js`,
                d), d = {}, e = `<script src="${Xc(dc(e).toString())}"`, d.async && (e += " async"), d.ki && (e += ` custom-element="${Xc(d.ki)}"`), d.defer && (e += " defer"), d.id && (e += ` id="${Xc(d.id)}"`), d.nonce && (e += ` nonce="${Xc(d.nonce)}"`), d.type && (e += ` type="${Xc(d.type)}"`), d.ii && (e += ` crossorigin="${Xc(d.ii)}"`), d = Mc(e + ">\x3c/script>"), a = cd({
                style: hd `margin:${0};`
            }, [a, d]), this.Oa.srcdoc = Kc(a))
        }
    };

    function cA(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = [])) : a.google_reactive_ads_global_state = new dA;
        return a.google_reactive_ads_global_state
    }
    class dA {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new eA;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map;
            this.sideRailPlasParam = new Map;
            this.sideRailMutationCallbacks = [];
            this.g =
                null;
            this.clickTriggeredInterstitialMayBeDisplayed = !1
        }
    }
    var eA = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };

    function fA(a, b) {
        return new gA(a, b)
    }

    function hA(a) {
        const b = iA(a);
        Ua(a.g.maxZIndexListeners, c => c(b))
    }

    function iA(a) {
        a = ye(a.g.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function jA(a, b) {
        db(a.g.maxZIndexListeners, c => c === b)
    }
    class kA {
        constructor(a) {
            this.g = cA(a).floatingAdsStacking
        }
    }

    function lA(a) {
        if (a.g == null) {
            var b = a.i,
                c = a.j;
            const d = b.g.nextRestrictionId++;
            b.g.maxZIndexRestrictions[d] = c;
            hA(b);
            a.g = d
        }
    }

    function mA(a) {
        if (a.g != null) {
            var b = a.i;
            delete b.g.maxZIndexRestrictions[a.g];
            hA(b);
            a.g = null
        }
    }
    class gA {
        constructor(a, b) {
            this.i = a;
            this.j = b;
            this.g = null
        }
    };

    function nA(a) {
        a = a.activeElement;
        const b = a ? .shadowRoot;
        return b ? nA(b) || a : a
    }

    function oA(a, b) {
        return pA(b, a.document.body).flatMap(c => qA(c))
    }

    function pA(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = ((e = c.mode && c.host ? c : null) == null ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function qA(a) {
        const b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function rA(a) {
        a.g !== null && (a.g.Di.forEach(b => {
            b.inert = !1
        }), a.g.Cj ? .focus(), a.g = null)
    }

    function sA(a, b) {
        rA(a);
        const c = nA(a.win.document);
        b = oA(a.win, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.g = {
            Cj: c,
            Di: b
        }
    }
    var tA = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
        de() {
            rA(this)
        }
    };

    function uA(a) {
        return new vA(a, new Ao(a, a.document.body), new Ao(a, a.document.documentElement), new Ao(a, a.document.documentElement))
    }

    function wA(a) {
        zo(a.j, "scroll-behavior", "auto");
        const b = xA(a.win);
        b.activePageScrollPreventers.add(a);
        b.previousWindowScroll === null && (b.previousWindowScroll = a.win.scrollY);
        zo(a.g, "position", "fixed");
        zo(a.g, "top", `${-b.previousWindowScroll}px`);
        zo(a.g, "width", "100%");
        zo(a.g, "overflow-x", "hidden");
        zo(a.g, "overflow-y", "hidden");
        zo(a.i, "overflow-x", "hidden");
        zo(a.i, "overflow-y", "hidden")
    }

    function yA(a) {
        yo(a.g);
        yo(a.i);
        const b = xA(a.win);
        b.activePageScrollPreventers.delete(a);
        b.activePageScrollPreventers.size === 0 && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        yo(a.j)
    }
    var vA = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.g = b;
            this.i = c;
            this.j = d
        }
    };

    function xA(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function zA(a) {
        return a.googPageScrollPreventerInfo && a.googPageScrollPreventerInfo.activePageScrollPreventers.size > 0 ? !0 : !1
    };

    function AA(a, b) {
        return BA(`#${a}`, b)
    }

    function CA(a, b) {
        return BA(`.${a}`, b)
    }

    function BA(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function DA(a, b) {
        const c = a.document.createElement("div");
        u(c, pr(a));
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            Za: c,
            shadowRoot: a
        }
    };

    function EA(a, b) {
        b = DA(a, b);
        a.document.body.appendChild(b.Za);
        return b
    }

    function FA(a, b) {
        const c = new R(b.P);
        Jo(b, !0, () => void c.g(!0));
        Jo(b, !1, () => {
            a.setTimeout(() => {
                b.P || c.g(!1)
            }, 700)
        });
        return Eo(c)
    };

    function GA(a) {
        const b = a.md;
        var c = a.pf,
            d = a.jd;
        const e = a.Yc,
            f = a.Wf,
            g = a.qe,
            h = a.Na;
        a = "<style>#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(a.zIndex) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            X(b) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ";
        c = c ? h ? 20 : 16 : 0;
        a += X(c) + "px; transition: transform " + X(g) + "s ease-in-out;" + (d ? "left: 0; border-top-right-radius: " + X(c) + "px; border-bottom-right-radius: " + X(c) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + X(c) + "px; border-bottom-left-radius: " + X(c) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {" + (h ?
                "height: 24px;" : "padding: 5px;") + "}.hd-control-button {border: none; background: none; cursor: pointer;" + (h ? "" : "padding: 5px;") + "}#hd-back-arrow-button {" + (d ? "float: right;" : "float: left;") + "}#hd-close-button {" + (d ? "float: left;" : "float: right;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' +
            Dz(f) + '">';
        d = h ? "#5F6368" : "#444746";
        a += '<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + Dz(d) + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button><button id="hd-close-button" class="hd-control-button" aria-label="' + Dz(e) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + Dz(d) + '"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button></div><div id="hd-content-container"></div></div></div>';
        return uz(a)
    };

    function HA(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && b.pushState && typeof b.pushState === "function" ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new IA(a, b);
        b.J();
        return b ? a.googNavStack = b : null
    }

    function JA(a, b) {
        return b ? b.googNavStackId === a.j ? b : null : null
    }

    function KA(a, b) {
        for (let c = b.length - 1; c >= 0; --c) {
            const d = c === 0;
            a.K.requestAnimationFrame(() => void b[c].Mj({
                isFinal: d
            }))
        }
    }

    function LA(a, b) {
        b = kb(a.stack, b, (c, d) => c - d.vg.googNavStackStateId);
        if (b >= 0) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class IA extends Q {
        constructor(a, b) {
            super();
            this.K = a;
            this.g = b;
            this.stack = [];
            this.j = Math.random() * 1E9 >>> 0;
            this.A = 0;
            this.l = c => {
                (c = JA(this, c.state)) ? KA(this, LA(this, c.googNavStackStateId + .5)): KA(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            const a = {
                    googNavStackId: this.j,
                    googNavStackStateId: this.A++
                },
                b = new Promise(c => {
                    this.stack.push({
                        Mj: c,
                        vg: a
                    })
                });
            this.g.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    const c = LA(this, a.googNavStackStateId);
                    var d;
                    if (d = c.length > 0) {
                        d = c[0].vg;
                        const e = JA(this, this.g.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.g.go(-c.length);
                    KA(this, c)
                }
            }
        }
        J() {
            this.K.addEventListener("popstate", this.l)
        }
        i() {
            this.K.removeEventListener("popstate", this.l);
            super.i()
        }
    };

    function MA(a) {
        return (a = HA(a)) ? new NA(a) : null
    }

    function OA(a) {
        if (!a.g) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.l.pushEvent();
            a.g = c;
            b.then(() => {
                a.g && !a.B && (a.g = null, Po(a.j))
            })
        }
    }
    var NA = class extends Q {
        constructor(a) {
            super();
            this.l = a;
            this.j = new Qo;
            this.g = null
        }
    };

    function PA(a, b, c) {
        var d = c.Fe ? null : new tA(a);
        const e = fA(new kA(a), c.zIndex - 1);
        b = QA(a, b, c);
        d = new RA(a, b, d, c.tc, uA(a), e);
        d.J();
        (c.jg || c.jg === void 0) && SA(d);
        c.oc && ((a = MA(a)) ? TA(d, a, c.gf) : c.gf ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function SA(a) {
        a.A = b => {
            b.key === "Escape" && a.g.P && a.collapse()
        };
        a.win.document.body.addEventListener("keydown", a.A)
    }

    function TA(a, b, c) {
        Jo(a.g, !0, () => {
            try {
                OA(b)
            } catch (d) {
                c ? .(d)
            }
        });
        Jo(a.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        No(b.j).listen(() => void a.collapse());
        wo(a, b)
    }

    function UA(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.C
    }

    function VA(a) {
        a.win.setTimeout(() => {
            a.g.P && UA(a).Ga.focus()
        }, 500)
    }

    function WA(a) {
        const {
            ff: b,
            bi: c
        } = UA(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function XA(a) {
        Jo(a.j, !1, () => {
            UA(a).Ga.classList.add("hd-hidden")
        })
    }
    var RA = class extends Q {
        constructor(a, b, c, d = !0, e, f) {
            super();
            this.win = a;
            this.C = b;
            this.l = c;
            this.tc = d;
            this.g = new R(!1);
            this.j = FA(a, this.g);
            Jo(this.j, !0, () => {
                wA(e);
                lA(f)
            });
            Jo(this.j, !1, () => {
                yA(e);
                mA(f)
            })
        }
        show({
            hg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            UA(this).Ga.classList.remove("hd-hidden");
            uo(this.win);
            UA(this).Ga.classList.add("hd-revealed");
            this.g.g(!0);
            this.l && (sA(this.l, UA(this).bb.Za), this.tc && VA(this));
            a && Jo(this.j, !1, () => {
                this.dispose()
            })
        }
        collapse() {
            UA(this).Ga.classList.remove("hd-revealed");
            this.g.g(!1);
            this.l ? .de()
        }
        isVisible() {
            return this.j
        }
        J() {
            WA(this);
            XA(this)
        }
        i() {
            this.A && this.win.document.body.removeEventListener("keydown", this.A);
            const a = this.C.bb.Za,
                b = a.parentNode;
            b && b.removeChild(a);
            this.l ? .de();
            super.i()
        }
    };

    function QA(a, b, c) {
        const d = EA(a, c.Ge),
            e = d.shadowRoot;
        e.appendChild(je(new Xd(a.document), pz(GA({
            md: c.md,
            pf: c.pf ? ? !0,
            jd: c.jd || !1,
            Yc: c.Yc,
            Wf: c.Wf || "",
            zIndex: c.zIndex,
            qe: .5,
            Na: c.Na || !1
        }))));
        const f = AA("hd-drawer-container", e);
        c.Le ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = AA("hd-content-container", e);
        c.appendChild(b);
        uo(a);
        return {
            Ga: f,
            ff: AA("hd-modal-background", e),
            Ae: c,
            bi: AA("hd-close-button", e),
            eo: AA("hd-back-arrow-button", e),
            bb: d
        }
    };

    function YA(a) {
        const b = a.wj,
            c = a.Ni;
        var d = a.qe;
        const e = a.Na;
        a = "<style>#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(a.zIndex) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
            X(c) + "%; transition: transform " + X(d) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round ";
        d = e ? 20 : 28;
        a += X(d) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
            X(b / c * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + X((c - b) / c * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
            X(b / c * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + X(b / c * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + X(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
            X(d) + "px " + X(d) + "px 0 0; background: white; display: flex; height: " + X(30) + "px; justify-content: center; cursor: grab;}.ved-handle-icon {" + (e ? "background: #dadce0; width: 50px;" : "background: #747775; opacity: 0.4; width: 32px;") + 'border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">' +
            ZA("ved-moving-handle") + '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">' + ZA("ved-fixed-handle") + "</div></div></div>";
        return uz(a)
    }

    function ZA(a) {
        return uz('<div class="ved-handle" id="' + Dz(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function $A(a) {
        return dp(a.g).map(b => b ? aB(a, b) : 0)
    }

    function aB(a, b) {
        switch (a.direction) {
            case 0:
                return bB(-b.yh);
            case 1:
                return bB(-b.xh);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function cB(a) {
        return fp(a.g).map(b => aB(a, b))
    }
    var dB = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function bB(a) {
        return a === 0 ? 0 : a
    };

    function Y(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.C
    }

    function eB(a) {
        a.win.setTimeout(() => {
            a.g.P && Y(a).Ga.focus()
        }, 500)
    }

    function fB(a) {
        Y(a).Ga.classList.remove("ved-hidden");
        uo(a.win);
        const {
            qa: b,
            Ya: c
        } = Y(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || gB(a);
        Y(a).Ga.classList.add("ved-revealed");
        a.g.g(!0);
        a.j && (sA(a.j, Y(a).bb.Za), a.tc && eB(a))
    }

    function hB(a) {
        return FA(a.win, a.g)
    }

    function iB(a, b) {
        const c = new R(b());
        No(a.H).listen(() => void c.g(b()));
        return Eo(c)
    }

    function jB(a) {
        const {
            qa: b,
            Ld: c
        } = Y(a);
        return iB(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function kB(a) {
        const {
            qa: b,
            Ld: c
        } = Y(a);
        return iB(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function lB(a) {
        const {
            qa: b
        } = Y(a);
        return iB(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function mB(a) {
        return Fo(jB(a), lB(a))
    }

    function nB(a) {
        const {
            qa: b,
            Ya: c
        } = Y(a);
        return iB(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function gB(a) {
        Y(a).Ya.classList.add("ved-snap-point-top");
        var b = oB(a, Y(a).Ya);
        Y(a).qa.scrollTop = b;
        pB(a)
    }

    function qB(a) {
        Ho(jB(a), !0, () => {
            const {
                og: b,
                Mc: c
            } = Y(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        Ho(jB(a), !1, () => {
            const {
                og: b,
                Mc: c
            } = Y(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function rB(a) {
        const b = kp(a.win, Y(a).Ae);
        np(b).i(() => void sB(a));
        wo(a, b)
    }

    function tB(a) {
        Ho(uB(a), !0, () => {
            Y(a).Pg.classList.remove("ved-hidden")
        });
        Ho(uB(a), !1, () => {
            Y(a).Pg.classList.add("ved-hidden")
        })
    }

    function vB(a) {
        const b = () => void Po(a.F),
            {
                ff: c,
                Ya: d,
                Mi: e
            } = Y(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        Jo(wB(a), !0, b)
    }

    function xB(a) {
        Jo(hB(a), !1, () => {
            gB(a);
            Y(a).Ga.classList.add("ved-hidden")
        })
    }

    function pB(a) {
        Io(a.l, !1, () => void Po(a.H))
    }

    function sB(a) {
        if (!a.l.P) {
            var {
                eg: b,
                Ae: c
            } = Y(a), d = c.getBoundingClientRect().height;
            d = Math.max(yB(a), d);
            a.l.g(!0);
            var e = zB(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    a.l.g(!1)
                })
            })
        }
    }

    function uB(a) {
        const {
            qa: b,
            Ya: c
        } = Y(a);
        return iB(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function wB(a) {
        return Do(a.A.map(Pp), AB(a))
    }

    function AB(a) {
        return iB(a, () => Y(a).qa.scrollTop === 0)
    }

    function oB(a, b) {
        ({
            Mc: a
        } = Y(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function BB(a, b) {
        a.A.g(!0);
        const {
            Mc: c,
            qa: d
        } = Y(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void CB(a, b)
    }

    function CB(a, b) {
        const {
            Mc: c,
            qa: d
        } = Y(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        Y(a).qa.scrollTop = b;
        pB(a);
        a.A.g(!1)
    }

    function zB(a) {
        const b = Y(a).qa.scrollTop;
        BB(a, b);
        return () => void CB(a, b)
    }

    function yB(a) {
        const {
            qa: b,
            Ld: c,
            eg: d,
            Ya: e
        } = Y(a);
        a = b.getBoundingClientRect();
        const f = c.getBoundingClientRect();
        var g = d.getBoundingClientRect();
        const h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var DB = class extends Q {
        constructor(a, b, c, d, e = !0) {
            super();
            this.win = a;
            this.C = b;
            this.I = c;
            this.j = d;
            this.tc = e;
            this.F = new Qo;
            this.H = new Qo;
            this.g = new R(!1);
            this.A = new R(!1);
            this.l = new R(!1)
        }
        J() {
            gB(this);
            qB(this);
            rB(this);
            tB(this);
            vB(this);
            xB(this);
            Y(this).qa.addEventListener("scroll", () => void pB(this))
        }
        i() {
            const a = this.C.bb.Za,
                b = a.parentNode;
            b && b.removeChild(a);
            this.j ? .de();
            super.i()
        }
    };

    function EB(a, b, c) {
        const d = EA(a, c.Ge),
            e = d.shadowRoot;
        e.appendChild(je(new Xd(a.document), pz(YA({
            wj: c.Tg * 100,
            Ni: c.pg * 100,
            zIndex: c.zIndex,
            qe: .5,
            Na: c.Na || !1
        }))));
        const f = AA("ved-drawer-container", e);
        c.Le ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = AA("ved-content-container", e);
        c.appendChild(b);
        uo(a);
        return {
            Ga: f,
            ff: AA("ved-modal-background", e),
            qh: AA("ved-ui-revealer", e),
            qa: AA("ved-scroller", e),
            Mc: AA("ved-scrolled-stack", e),
            Mi: AA("ved-fully-closed-anchor", e),
            Ya: AA("ved-partially-extended-anchor", e),
            eg: AA("ved-content-sizer",
                e),
            Ae: c,
            no: AA("ved-moving-handle", e),
            Ld: AA("ved-moving-handle-holder", e),
            Li: AA("ved-fixed-handle", e),
            og: AA("ved-fixed-handle-holder", e),
            Pg: AA("ved-over-scroll-block", e),
            bb: d
        }
    };

    function FB(a, b, c) {
        var d = fA(new kA(a), c.zIndex - 1);
        b = EB(a, b, c);
        const e = c.Fe ? null : new tA(a);
        var f = b.Li;
        f = new gp(new Yo(a, f), new Vo(f));
        var g = f.g;
        g.A.addEventListener("mousedown", g.G);
        g.l.addEventListener("mouseup", g.B);
        g.l.addEventListener("mousemove", g.C, {
            passive: !1
        });
        g = f.i;
        g.i.addEventListener("touchstart", g.C);
        g.i.addEventListener("touchend", g.A);
        g.i.addEventListener("touchmove", g.B, {
            passive: !1
        });
        b = new DB(a, b, new dB(f), e, c.tc);
        b.J();
        d = new GB(a, b, uA(a), d);
        wo(d, b);
        d.J();
        c.oc && ((a = MA(a)) ? HB(d, a, c.gf) :
            c.gf ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function HB(a, b, c) {
        Jo(a.g.g, !0, () => {
            try {
                OA(b)
            } catch (d) {
                c ? .(d)
            }
        });
        Jo(a.g.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        No(b.j).listen(() => void a.collapse());
        wo(a, b)
    }

    function IB(a) {
        Jo(Do(mB(a.g), nB(a.g)), !0, () => {
            Y(a.g).Ya.classList.remove("ved-snap-point-top")
        });
        Ho(kB(a.g), !0, () => {
            Y(a.g).qa.classList.add("ved-no-snap")
        });
        Ho(kB(a.g), !1, () => {
            Y(a.g).qa.classList.remove("ved-no-snap")
        });
        Jo(kB(a.g), !1, () => {
            var b = a.g;
            var c = Y(b).Ld;
            c = BB(b, oB(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function JB(a) {
        const b = a.g.I;
        $A(b).listen(c => {
            c = -c;
            if (c > 0) {
                const {
                    qh: d
                } = Y(a.g);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                qh: c
            } = Y(a.g)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        cB(b).listen(c => {
            -c > 30 && a.collapse()
        })
    }
    var GB = class extends Q {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.g = b;
            Jo(hB(b), !0, () => {
                wA(c);
                lA(d)
            });
            Jo(hB(b), !1, () => {
                yA(c);
                mA(d)
            })
        }
        show({
            hg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            fB(this.g);
            a && Jo(hB(this.g), !1, () => {
                this.dispose()
            })
        }
        collapse() {
            var a = this.g;
            Y(a).Ga.classList.remove("ved-revealed");
            a.g.g(!1);
            a.j ? .de()
        }
        isVisible() {
            return hB(this.g)
        }
        J() {
            No(this.g.F).listen(() => {
                this.collapse()
            });
            IB(this);
            JB(this);
            uo(this.win)
        }
    };

    function KB(a, b) {
        return Me() === 2 ? FB(a.win, b, {
            Tg: .95,
            pg: .95,
            zIndex: 2147483645,
            oc: !0,
            Na: !0
        }) : PA(a.win, b, {
            md: "min(65vw, 768px)",
            Yc: "",
            jd: !1,
            zIndex: 2147483645,
            oc: !0,
            pf: !1,
            Na: !0
        })
    }

    function LB(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.win, "_googCsa");
        const b = a.R.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.H,
                styleId: "5134551505",
                hl: a.language,
                fexp: a.C,
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.Bb.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.I
            };
        a.ta && (c.adLoadedCallback = a.La.bind(a));
        a.j && a.A instanceof
        Array && (c.fexp = a.A.join(","));
        a.win._googCsa("relatedsearch", c, b)
    }

    function MB(a) {
        a.win.addEventListener("message", b => {
            b.origin === "https://www.gstatic.com" && b.data.action === "resize" && (a.g.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var NB = class extends Q {
        constructor(a, b, c, d, e, f, g, h, k, l = () => {}) {
            super();
            this.win = a;
            this.R = b;
            this.O = e;
            this.C = f;
            this.l = h;
            this.Ea = k;
            this.ib = l;
            this.language = d ? .g() || "en";
            this.hb = d ? .j() || "Search results from ${website}";
            this.ta = U(ks);
            this.H = c.replace("ca", "partner");
            this.ca = new Xd(a.document);
            this.g = ie(this.ca, "IFRAME");
            this.I = g.i ? g.g : "9d449ff4a772956c6";
            this.A = (this.j = U(qs)) ? O(Dn).g().concat(this.C) : this.C;
            this.F = new bA(this.g, this.I, "auto-rs-prose", this.H, "AutoRsVariant", a.location, this.language, this.hb,
                this.A, this.l, this.Ea, this.j);
            this.ia = KB(this, this.g);
            wo(this, this.ia)
        }
        J() {
            this.R.length !== 0 && (this.ta || Pu(1075, () => {
                this.F.J()
            }, this.win), Pu(1076, () => {
                const a = ie(this.ca, "SCRIPT");
                ud(a, fd `https://www.google.com/adsense/search/async-ads.js`);
                this.win.document.head.appendChild(a)
            }, this.win), LB(this), kr(this.O, {
                sts: "ok"
            }), this.l && MB(this))
        }
        La(a, b) {
            b ? Pu(1075, () => {
                this.F.J()
            }, this.win) : (this.ib(), mr(this.O, "pfns"))
        }
        Bb(a, b) {
            aA(this.F, a, b);
            (() => {
                if (!this.l) {
                    const c = new ResizeObserver(async e => {
                            this.g.height =
                                "0";
                            await new Promise(f => {
                                this.win.requestAnimationFrame(f)
                            });
                            this.g.height = e[0].target.scrollHeight.toString()
                        }),
                        d = () => {
                            const e = this.g.contentDocument ? .documentElement;
                            e ? c.observe(e) : (console.warn("iframe body missing"), setTimeout(d, 1E3))
                        };
                    d()
                }
                this.ia.show()
            })()
        }
    };
    var OB = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };

    function PB(a) {
        const b = nv(a.l.ha),
            c = a.B.Ja(a.G, () => a.i());
        b.appendChild(c);
        a.A && (b.className = a.A);
        return {
            zi: b,
            hi: c
        }
    }
    class QB {
        constructor(a, b, c, d) {
            this.G = a;
            this.l = b;
            this.B = c;
            this.A = d || null;
            this.g = null;
            this.j = new R(null)
        }
        J() {
            const a = PB(this);
            this.g = a.zi;
            Ex(this.l, this.g);
            this.j.g(a.hi)
        }
        i() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.j.g(null)
        }
        C() {
            return this.j
        }
    };
    async function RB(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    SB(a)
                } catch (c) {
                    mr(a.i, "pfere", c)
                }
                b()
            })
        })
    }

    function SB(a) {
        if ((!a.hd || !TB(a.config, a.aa, a.i)) && UB(a.g ? .j(), a.i)) {
            var b = a.g ? .l();
            b = ez(a.win, a.config, a.aa, a.i, {
                Xj: !!b ? .A(),
                hd: a.hd,
                oo: !!b ? .g(),
                Wj: !!b ? .B()
            });
            b = VB(b, a.win);
            var c = Object.keys(b),
                d = Object.values(b),
                e = a.g ? .g() ? .g() || 0,
                f = WB(a.g),
                g = !!a.g ? .B(),
                h = String(a.g ? .C());
            if (!x(a.config, wq, 25) ? .g()) {
                var k = () => {
                    d.forEach(l => {
                        l.i()
                    })
                };
                Pu(1074, () => {
                    (new NB(a.win, c, a.webPropertyCode, a.g ? .j(), a.i, e, f, g, h, k)).J()
                }, a.win)
            }
        }
    }
    var XB = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.aa = e;
            this.hd = f;
            this.i = new nr(a, b, x(this.config, Dq, 28) || new Dq);
            this.g = x(this.config, Dq, 28)
        }
    };

    function TB(a, b, c) {
        a = x(a, Dq, 28) ? .g() ? .g() || 0;
        const d = O(bu).g(ps.g, ps.defaultValue);
        return d && d.includes(a.toString()) ? !1 : (b ? Wh(b, 2, Ig, w()) : []).length === 0 ? (mr(c, "pfeu"), !0) : !1
    }

    function UB(a, b) {
        const c = O(bu).g(ns.g, ns.defaultValue);
        a = a ? .g() || "";
        return c && c.length !== 0 && !c.includes(a.toString()) ? (mr(b, "pflna"), !1) : !0
    }

    function VB(a, b) {
        const c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            const f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new QB(b, d, new sr(g), "autors-widget");
            d.J();
            c[f] = d
        }
        return c
    }

    function WB(a) {
        const b = a ? .G() || !1;
        a = a ? .A() || "";
        return new OB(b, a)
    };
    var YB = (a, b) => {
        const c = [];
        x(a, Nq, 18) && c.push(2);
        b.aa && c.push(0);
        x(a, Dq, 28) && Ei(x(a, Dq, 28), 1) == 1 && c.push(1);
        x(a, Bq, 31) && Ei(x(a, Bq, 31), 1) == 1 && c.push(5);
        x(a, yq, 32) && c.push(6);
        x(a, Qq, 34) && J(x(a, Qq, 34), 3) && c.push(7);
        return c
    };

    function ZB(a, b) {
        const c = ie(Wd(a), "IMG");
        $B(a, c);
        c.src = "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg";
        u(c, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: b == null ? "auto" : "pointer"
        });
        b && c.addEventListener("click", d => {
            b();
            d.stopPropagation()
        });
        return c
    }

    function aC(a, b) {
        const c = b.document.createElement("button");
        $B(b, c);
        u(c, {
            display: "inline",
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.i));
        c.addEventListener("click", d => {
            a.j();
            d.stopPropagation()
        });
        return c
    }

    function bC(a, b, c) {
        const d = ie(Wd(b), "IMG");
        d.src = "https://www.gstatic.com/adsense/autoads/icons/arrow_left_24px_grey_800.svg";
        d.setAttribute("aria-label", a.l);
        $B(b, d);
        u(d, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        d.addEventListener("click", e => {
            c();
            e.stopPropagation()
        });
        return d
    }

    function cC(a) {
        const b = a.document.createElement("ins");
        $B(a, b);
        u(b, {
            "float": "left",
            display: "inline-flex",
            padding: "8px 0px",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 2px 0px rgba(60,64,67,0.3), 0px 1px 3px 1px rgba(60,64,67,0.15)"
        });
        return b
    }
    class dC {
        constructor(a, b, c) {
            this.i = a;
            this.l = b;
            this.j = c;
            this.g = new R(!1)
        }
        Ja(a, b, c, d) {
            const e = ZB(a, d),
                f = ZB(a),
                g = aC(this, a),
                h = bC(this, a, c);
            a = cC(a);
            a.appendChild(e);
            a.appendChild(f);
            a.appendChild(g);
            a.appendChild(h);
            this.g.listen(k => {
                u(e, {
                    display: k ? "none" : "inline"
                });
                u(f, {
                    display: k ? "inline" : "none"
                });
                k ? (u(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), u(h, {
                        margin: "0px 12px 0px 8px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 100ms 50ms, opacity 50ms 50ms, width 100ms 50ms"
                    })) :
                    (u(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), u(h, {
                        margin: "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 100ms, opacity 50ms, width 100ms"
                    }))
            }, !0);
            return a
        }
        qg() {
            return 40
        }
        Ng() {
            this.g.g(!1);
            return 0
        }
        Og() {
            this.g.g(!0)
        }
    }

    function $B(a, b) {
        u(b, pr(a));
        u(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#3C4043",
            "user-select": "none"
        })
    };
    var eC = a => a.googlefc = a.googlefc || {},
        fC = a => {
            a = a.googlefc = a.googlefc || {};
            return a.ccpa = a.ccpa || {}
        },
        gC = a => {
            a = a.googlefc = a.googlefc || {};
            return a.__fcusi = a.__fcusi || {}
        },
        hC = a => {
            a = a.googlefc = a.googlefc || {};
            if (!a.getFloatingToolbarTranslatedMessages) return null;
            if (a = a.getFloatingToolbarTranslatedMessages()) {
                var b = new Eq;
                b = Pi(b, 1, a.defaultFloatingToolbarToggleExpansionText);
                b = Pi(b, 2, a.defaultFloatingToolbarTogglePrivacySettings);
                a = Pi(b, 3, a.defaultFloatingToolbarDismissPrivacySettings).i()
            } else a = null;
            return a
        };

    function iC(a, b) {
        const c = b.document.createElement("button");
        jC(a, b, c);
        b = {
            width: "100%",
            "text-align": "center",
            display: "block",
            padding: "8px 0px",
            "background-color": a.i
        };
        a.g && (b["border-top"] = a.g, b["border-bottom"] = a.g);
        u(c, b);
        c.addEventListener("click", d => {
            a.B();
            d.stopPropagation()
        });
        return c
    }

    function kC(a, b, c, d) {
        const e = b.document.createElement("div");
        u(e, pr(b));
        u(e, {
            "align-items": "center",
            "background-color": a.i,
            display: "flex",
            "justify-content": "center"
        });
        const f = b.document.createElement("span");
        f.appendChild(b.document.createTextNode(d));
        u(f, pr(b));
        u(f, {
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            padding: "8px 0px"
        });
        b = b.matchMedia("(min-width: 768px)");
        d = g => {
            g.matches ? (u(e, {
                    "flex-direction": "row"
                }), a.g && u(e, {
                    "border-top": a.g,
                    "border-bottom": a.g
                }), u(f, {
                    "margin-left": "8px",
                    "text-align": "start"
                }),
                u(c, {
                    border: "0",
                    "margin-right": "8px",
                    width: "auto"
                })) : (u(e, {
                border: "0",
                "flex-direction": "column"
            }), u(f, {
                "margin-left": "0",
                "text-align": "center"
            }), u(c, {
                "margin-right": "0",
                width: "100%"
            }), a.g && u(c, {
                "border-top": a.g,
                "border-bottom": a.g
            }))
        };
        d(b);
        b.addEventListener("change", d);
        e.appendChild(c);
        e.appendChild(f);
        return e
    }

    function jC(a, b, c) {
        u(c, pr(b));
        u(c, {
            "font-family": "Arial,sans-serif",
            "font-weight": a.C,
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: a.G,
            "user-select": "none",
            cursor: "pointer"
        })
    }
    class lC {
        constructor(a, b, c, d, e, f = null, g = null, h = null) {
            this.A = a;
            this.B = b;
            this.G = c;
            this.i = d;
            this.C = e;
            this.l = f;
            this.g = g;
            this.j = h
        }
        Ja(a) {
            const b = a.document.createElement("div");
            jC(this, a, b);
            u(b, {
                display: "inline-flex",
                padding: "8px 0px",
                "background-color": this.i
            });
            if (this.l) {
                var c = ie(Wd(a), "IMG");
                c.src = this.l;
                jC(this, a, c);
                u(c, {
                    margin: "0px 8px 0px 0px",
                    width: "24px",
                    height: "24px"
                })
            } else c = null;
            c && b.appendChild(c);
            c = a.document.createElement("span");
            jC(this, a, c);
            u(c, {
                "line-height": "24px"
            });
            c.appendChild(a.document.createTextNode(this.A));
            b.appendChild(c);
            c = iC(this, a);
            c.appendChild(b);
            return this.j ? kC(this, a, c, this.j) : c
        }
    };

    function mC(a, b) {
        b = b.filter(c => x(c, aq, 4) ? .g() === 5 && Ji(c, 8) === 1);
        b = ev(b, a);
        a = Gx(b, a);
        a.sort((c, d) => d.la.g - c.la.g);
        return a[0] || null
    };

    function nC({
        be: a,
        ed: b,
        Nd: c,
        ce: d,
        gd: e,
        Od: f
    }) {
        const g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (k === 0 ? 0 : h / k) * (b - a),
                    y: d + (m === 0 ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function oC(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function pC(a, b) {
        var c = nC({
            be: b.left,
            ed: b.right,
            Nd: 10,
            ce: b.top,
            gd: b.bottom,
            Od: 10
        });
        b = new Set;
        for (const d of c)(c = qC(a, d)) && b.add(c);
        return b
    }

    function rC(a, b) {
        for (const c of b)
            if (b = qC(a, c)) return b;
        return null
    }

    function sC(a, b, c) {
        if (dk(b, "position") !== "fixed") return null;
        var d = b.getAttribute("class") === "GoogleActiveViewInnerContainer" || gk(b).width <= 1 && gk(b).height <= 1 || a.g.Bi && !a.g.Bi(b) ? !0 : !1;
        a.g.ng && a.g.ng(b, c, d);
        return d ? null : b
    }

    function qC(a, b) {
        var c = oC(a.K.document, b);
        if (c) {
            var d;
            if (!(d = sC(a, c, b))) a: {
                d = a.K.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    const e = sC(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    }
    var tC = class {
        constructor(a, b = {}) {
            this.K = a;
            this.g = b
        }
    };

    function uC({
        K: a,
        qj: b,
        lj: c,
        ai: d,
        vo: e,
        wo: f,
        Z: g
    }) {
        let h = 0;
        try {
            h |= Tn(a, f);
            const m = Math.min(a.screen.width || 0, a.screen.height || 0);
            h |= m ? m < 320 ? 8192 : 0 : 2048;
            h |= a.navigator && vC(a.navigator.userAgent) ? 1048576 : 0;
            if (b) {
                f = h;
                const n = a.innerHeight;
                var k = cf(a) * n >= b;
                var l = f | (k ? 0 : 1024)
            } else l = h | (a.innerHeight >= a.innerWidth ? 0 : 8);
            h = l;
            h |= Vn(a, c, !0, e)
        } catch {
            h |= 32
        }
        switch (d) {
            case 2:
                wC(a, g) && (h |= 16777216);
                break;
            case 1:
                xC(a, g) && (h |= 16777216)
        }
        return h
    }

    function vC(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }
    var wC = (a, b = null) => {
            const c = nC({
                be: 0,
                ed: a.innerWidth,
                Nd: 3,
                ce: 0,
                gd: Math.min(Math.round(a.innerWidth / 320 * 50), yC) + 15,
                Od: 3
            });
            return rC(zC(a, b), c) != null
        },
        xC = (a, b = null) => {
            const c = a.innerWidth,
                d = a.innerHeight,
                e = Math.min(Math.round(a.innerWidth / 320 * 50), yC) + 15,
                f = nC({
                    be: 0,
                    ed: c,
                    Nd: 3,
                    ce: d - e,
                    gd: d,
                    Od: 3
                });
            e > 25 && f.push({
                x: c - 25,
                y: d - 25
            });
            return rC(zC(a, b), f) != null
        };

    function AC(a, b) {
        var c = U(Br);
        a: {
            const e = a.innerWidth,
                f = a.innerHeight;
            let g = f;
            for (; g > b;) {
                var d = nC({
                    be: 0,
                    ed: e,
                    Nd: 9,
                    ce: g - b,
                    gd: g,
                    Od: 9
                });
                d = rC(zC(a), d);
                if (!d) {
                    a = f - g;
                    break a
                }
                g = c ? Math.min(d.getBoundingClientRect().top - 1, g - 1) : d.getBoundingClientRect().top - 1
            }
            a = null
        }
        return a
    }

    function zC(a, b = null) {
        return new tC(a, {
            ng: BC(a, b)
        })
    }

    function BC(a, b = null) {
        if (b) return (c, d, e) => {
            Pk(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }
    const yC = 90 * 1.38;

    function CC(a) {
        a = new DC(a);
        a.J();
        return a
    }

    function EC(a) {
        if (!zA(a.win)) {
            if (a.j.P) {
                const b = bo(a.win);
                if (b > a.g + 100 || b < a.g - 100) a.j.g(!1), a.g = Wn(a.win)
            }
            a.l && a.win.clearTimeout(a.l);
            a.l = a.win.setTimeout(() => void FC(a), 200)
        }
    }

    function FC(a) {
        if (!zA(a.win)) {
            var b = Wn(a.win);
            a.g && a.g > b && (a.g = b);
            b = bo(a.win);
            b >= a.g - 100 && (a.g = Math.max(a.g, b), a.j.g(!0))
        }
    }
    var DC = class extends Q {
        constructor(a) {
            super();
            this.win = a;
            this.j = new R(!1);
            this.g = 0;
            this.l = null;
            this.A = () => void EC(this)
        }
        J() {
            this.win.addEventListener("scroll", this.A);
            this.g = Wn(this.win);
            FC(this)
        }
        i() {
            this.win.removeEventListener("scroll", this.A);
            this.j.g(!1);
            super.i()
        }
    };

    function GC(a) {
        a.g || (a.g = HC(a));
        u(a.g, {
            display: "block"
        });
        a.A.Og();
        a.j.g(a.B)
    }

    function IC(a) {
        const b = a.A.Ng();
        switch (b) {
            case 0:
                a.j.g(a.B);
                break;
            case 1:
                a.g && (u(a.g, {
                    display: "none"
                }), a.j.g(null));
                break;
            default:
                throw Error("Unhandled OnHideOutcome: " + b);
        }
    }

    function HC(a) {
        var b = AC(a.l, a.A.qg() + 60);
        b = b == null ? 30 : b + 30;
        const c = a.l.document.createElement("div");
        u(c, pr(a.l));
        u(c, {
            position: "fixed",
            left: "0px",
            bottom: b + "px",
            width: "100vw",
            "text-align": "center",
            "z-index": 2147483642,
            display: "none",
            "pointer-events": "none"
        });
        a.B = a.A.Ja(a.l, () => a.i(), () => {
            a.G.dispose();
            IC(a)
        }, () => {
            a.G.dispose();
            GC(a)
        });
        c.appendChild(a.B);
        a.F && (c.className = a.F);
        a.l.document.body.appendChild(c);
        return c
    }
    class JC {
        constructor(a, b, c) {
            this.l = a;
            this.A = b;
            this.B = null;
            this.j = new R(null);
            this.F = c || null;
            this.G = CC(a);
            this.g = null
        }
        J() {
            const a = Eo(this.G.j);
            Ho(a, !0, () => void GC(this));
            Jo(a, !1, () => void IC(this))
        }
        i() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.G.dispose();
            this.j.g(null)
        }
        C() {
            return this.j
        }
    };

    function KC(a) {
        a.G.g(0);
        a.l != null && (a.l.i(), a.l = null);
        a.j != null && (a.j.i(), a.j = null)
    }

    function LC(a) {
        a.j = new JC(a.B, a.I, a.F);
        a.j.J();
        Ko(a.A, a.j.C());
        a.G.g(2)
    }
    class MC {
        constructor(a, b, c, d, e) {
            this.B = a;
            this.H = b;
            this.O = c;
            this.I = d;
            this.F = e;
            this.G = new R(0);
            this.A = new R(null);
            this.j = this.l = this.g = null
        }
        J() {
            this.H ? (this.l = new QB(this.B, this.H, this.O, this.F), this.l.J(), Ko(this.A, this.l.C()), this.G.g(1), this.g == null && (this.g = new xp(this.B), this.g.J(2E3)), vp(this.g, () => {
                KC(this);
                LC(this)
            })) : LC(this)
        }
        i() {
            KC(this);
            this.g && (this.g.dispose(), this.g = null)
        }
        C() {
            return this.A
        }
    };
    var NC = class {
        constructor(a, b, c) {
            this.position = a;
            this.Ab = b;
            this.Pe = c
        }
    };

    function OC(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    };

    function PC(a, b, c) {
        var d = P(a);
        d = new NC(b.Tb.Kg(b.mb), b.Ab + 2 * b.mb, Math.min(d, b.Dd) - b.Tb.od() + 2 * b.mb);
        d = d.position.fg(a, d.Ab, d.Pe);
        var e = Un(a),
            f = P(a);
        c = QC(a, new Jj(ld(d.top, 0, f - 1), ld(d.right, 0, e - 1), ld(d.bottom, 0, f - 1), ld(d.left, 0, e - 1)), c);
        f = RC(c);
        let g = d.top;
        e = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && e.push(new OC(g, f[h].start)), g = f[h].end;
        g < d.bottom && e.push(new OC(g, d.bottom));
        a = P(a);
        d = [];
        for (f = e.length - 1; f >= 0; f--) d.push(new OC(a - e[f].end, a - e[f].start));
        a: {
            for (const h of d)
                if (a = h.start + b.mb, a > b.Tb.od() +
                    b.bf ? a = null : (d = Math.min(h.end - b.mb, b.Dd) - a, a = d < b.ef ? null : {
                        position: b.Tb.wh(a),
                        Ec: d
                    }), a) {
                    b = a;
                    break a
                }
            b = null
        }
        return {
            te: b,
            co: c
        }
    }

    function QC(a, b, c) {
        const d = pC(new tC(a), b);
        c.forEach(e => void d.delete(e));
        return d
    }

    function RC(a) {
        return Array.from(a).map(SC).sort((b, c) => b.start - c.start)
    }

    function SC(a) {
        a = a.getBoundingClientRect();
        return new OC(a.top, a.bottom)
    };

    function TC({
        ga: a,
        sa: b
    }) {
        return new UC(a, b)
    }
    var UC = class {
        constructor(a, b) {
            this.ga = a;
            this.sa = b
        }
        Kg(a) {
            return new UC(this.ga - a, this.sa - a)
        }
        fg(a, b, c) {
            a = P(a) - this.ga - c;
            return new Jj(a, this.sa + b, a + c, this.sa)
        }
        Tf(a) {
            a.bottom = `${this.ga}px`;
            a.left = `${this.sa}px`;
            a.right = ""
        }
        rg() {
            return 0
        }
        od() {
            return this.ga
        }
        wh(a) {
            return new UC(a, this.sa)
        }
    };

    function VC({
        ga: a,
        Ba: b
    }) {
        return new WC(a, b)
    }
    var WC = class {
        constructor(a, b) {
            this.ga = a;
            this.Ba = b
        }
        Kg(a) {
            return new WC(this.ga - a, this.Ba - a)
        }
        fg(a, b, c) {
            var d = Un(a);
            a = P(a) - this.ga - c;
            d = d - this.Ba - b;
            return new Jj(a, d + b, a + c, d)
        }
        Tf(a) {
            a.bottom = `${this.ga}px`;
            a.right = `${this.Ba}px`;
            a.left = ""
        }
        rg() {
            return 1
        }
        od() {
            return this.ga
        }
        wh(a) {
            return new WC(a, this.Ba)
        }
    };

    function XC(a) {
        const b = a.Gi,
            c = a.di,
            d = a.Wh,
            e = a.Sj,
            f = a.Xh;
        a = a.Vh;
        return uz('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500,700" rel="stylesheet"><style>.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: ' + X(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " +
            X(d) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + X(a) + "px; border-radius: " + X(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " + X(a) + "px; margin: 0; border-radius: " + X(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            X(d) + "px; height: " + X(d) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + X(d) + "px; margin-bottom: " + X(f) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + X(d) + "px; width: " + X(d) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            X(d - 6) + "px; width: " + X(d - 6) + "px; border-radius: " + X(d / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            X(e) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + X(d) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            X(16) + "px; max-width: calc(90vw - " + X(d * 2) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + X(d + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + X(d + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            X(d * 2) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0; text-align: start;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            Dz(b) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + Dz(c) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function YC(a) {
        const b = a.googleIconName,
            c = a.ariaLabel,
            d = a.backgroundColorCss,
            e = a.iconColorCss;
        a = a.li;
        return uz('<div class="ft-button ft-collapsible ft-collapsed ft-last-button">' + ((a instanceof oz ? a.Ja() : a) ? "<style>@scope {" + X(a) + "}</style>" : "") + '<button class="ft-styless-button" aria-label="' + Dz(c) + '" style="background-color: ' + Dz(X(d)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + Dz(X(e)) + '" aria-hidden="true">' + sz(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const ZC = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function $C(a, b) {
        a = new aD(a, b, bD(a, b));
        a.J();
        return a
    }

    function cD() {
        ({
            hc: a
        } = {
            hc: 2
        });
        var a;
        return a > 1 ? 50 : 120
    }

    function dD(a, b, c) {
        eD(a) === 0 && b.classList.remove("ft-collapsed");
        fD(b, c);
        uo(a.win);
        b.classList.remove("ft-collapsed");
        gD(a);
        return () => void hD(a, b, c)
    }

    function iD(a) {
        jD(a.g.ka.Gc).length === 0 ? (a.l.P ? .Gj(), a.l.g(null), a.g.ka.Oe.g(!1), a.g.ka.Bg.g(!1), a.g.ka.We.g(!1)) : (a.g.ka.Oe.g(!0), kD(a))
    }

    function lD(a, {
        Gh: b = 0,
        bo: c = 0
    }) {
        b = Math.max(jD(a.g.Eb).length + b, 0);
        c = Math.max(jD(a.g.lb).length + c, 0);
        const d = b + c;
        let e = d * 50;
        b > 0 && c > 0 && (e += 11);
        e += Math.max(0, d - 1) * 10;
        d >= a.j.hc && (e += 60);
        d > 1 && (e += 10);
        return e
    }

    function eD(a) {
        const b = a.g.lb;
        return jD(a.g.Eb).length + jD(b).length
    }

    function gD(a) {
        const b = a.g.lb,
            c = a.g.separator;
        jD(a.g.Eb).length > 0 && jD(b).length > 0 ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        eD(a) >= a.j.hc ? a.g.Ag.g(!0) : a.g.Ag.g(!1);
        eD(a) > 1 ? a.g.ug.g(!0) : a.g.ug.g(!1);
        eD(a) > 0 ? a.g.isVisible.g(!0) : a.g.isVisible.g(!1);
        mD(a);
        nD(a)
    }

    function hD(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), gD(a), a.win.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function mD(a) {
        const b = jD(a.g.Eb).concat(jD(a.g.lb));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        eD(a) >= a.j.hc || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function nD(a) {
        const b = jD(a.g.Eb).concat(jD(a.g.lb)).filter(c => !c.classList.contains("ft-reg-button"));
        a.F.g(b.length > 0)
    }

    function oD(a) {
        ho(a.g.ka.Gc.children, b => {
            const c = a.g.ka.Kc;
            hD(a, b, a.g.ka.Gc);
            const d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        iD(a)
    }

    function kD(a) {
        if (!a.l.P) {
            var b = pD(a.win, {
                googleIconName: "verified_user",
                ariaLabel: K(a.j.Pa, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.g.ka.Bg.g(!a.g.ka.isVisible.P);
                    for (const [, c] of a.g.ka.Kc) c.Eg = !0;
                    a.g.ka.We.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.Tc.classList.add("ft-reg-button");
            dD(a, b.Tc, a.g.lb);
            Ko(b.dj, a.g.ka.isVisible);
            a.l.g({
                ho: b,
                Gj: () => void hD(a, b.Tc, a.g.lb)
            })
        }
    }

    function qD(a) {
        var b = a.g.ka.We,
            c = b.g;
        a: {
            for ([, d] of a.g.ka.Kc)
                if (a = d, a.showUnlessUserInControl && !a.Eg) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function rD(a) {
        a.g.ka.ci.listen(() => {
            oD(a)
        })
    }
    var aD = class extends Q {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.j = b;
            this.g = c;
            this.l = new R(null);
            this.F = new R(!1)
        }
        addButton(a) {
            a = pD(this.win, a);
            return dD(this, a.Tc, this.g.Eb)
        }
        addRegulatoryMessage(a) {
            const b = this.g.ka.Gc,
                c = sD(this.win, a);
            fD(c.cf, b);
            this.g.ka.Kc.set(c.cf, c);
            iD(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    qD(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    qD(this)
                },
                isDismissed: Mo(c.isDismissed),
                removeCallback: () => {
                    var d = c.cf;
                    const e = this.g.ka.Gc;
                    d.parentNode === e && e.removeChild(d);
                    this.g.ka.Kc.delete(d);
                    iD(this)
                }
            }
        }
        H() {
            return Eo(this.l.map(a => a != null))
        }
        C() {
            return Eo(this.F)
        }
        A() {
            return [this.g.container]
        }
        i() {
            const a = this.g.bb.Za;
            a.parentNode ? .removeChild(a);
            super.i()
        }
        J() {
            up(this.win, ZC);
            Ko(this.g.Zj, this.j.Fc);
            this.win.document.body.appendChild(this.g.bb.Za);
            rD(this)
        }
    };

    function bD(a, b) {
        const c = DA(a),
            d = c.shadowRoot;
        d.appendChild(je(new Xd(a.document), pz(XC({
            Gi: K(b.Pa, 1),
            di: K(b.Pa, 3),
            Wh: 50,
            Sj: 11,
            Xh: 10,
            Vh: 5
        }))));
        const e = CA("ft-container", d),
            f = CA("ft-expand-toggle", d),
            g = CA("ft-expand-toggle-container", d),
            h = new R(null);
        h.i(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        const k = new R(!0);
        Ho(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        Ho(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.P)
            });
        const l = new R(!1);
        Ho(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        Ho(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        const m = new R(!1);
        Ho(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        Ho(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.i(p => {
            if (p) {
                p.Tf(e.style);
                p = p.rg();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                uo(a)
            }
        });
        const n = new R(!1);
        b = Do(tD(a, d), n, b.position.map(p => p !== null));
        Ho(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        Ho(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = uD(a, CA("ft-reg-bubble", d));
        return {
            container: e,
            Eb: CA("ft-button-holder", d),
            lb: CA("ft-bottom-button-holder", d),
            separator: CA("ft-separator", d),
            bb: c,
            Zj: h,
            lo: k,
            Ag: l,
            ug: m,
            isVisible: n,
            ka: b
        }
    }

    function uD(a, b) {
        const c = new R(!1),
            d = new R(!1),
            e = Fo(c, d);
        Ho(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        Ho(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        const f = new R(!1);
        Ho(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        Ho(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        const g = CA("ft-reg-bubble-close", b),
            h = new Qo;
        g.addEventListener("click", () => {
            Po(h)
        });
        const k = CA("ft-reg-message-holder", b);
        np(kp(a, k)).i(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            Gc: k,
            Bg: c,
            We: d,
            isVisible: e,
            Oe: f,
            Kc: new Map,
            ci: No(h)
        }
    }

    function pD(a, b) {
        const c = je(new Xd(a.document), pz(YC({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043",
            li: b.buttonExtension ? .styleSheet
        })));
        if (b.cornerNumber !== void 0) {
            const d = ld(Math.round(b.cornerNumber), 0, 99);
            CA("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick && BA("BUTTON", c).addEventListener("click", b.onClick);
        a = new R(!1);
        Ho(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        Ho(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            Tc: c,
            dj: a
        }
    }

    function sD(a, b) {
        a = new Xd(a.document);
        var c = uz('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = je(a, pz(c));
        c = CA("ft-reg-message-button", a);
        b.regulatoryMessage.actionButton ? (c.appendChild(b.regulatoryMessage.actionButton.buttonText), c.addEventListener("click", b.regulatoryMessage.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = CA("ft-reg-message-info", a);
        b.regulatoryMessage.informationText ? c.appendChild(b.regulatoryMessage.informationText) :
            c.classList.add("ft-display-none");
        a.orderingIndex = b.orderingIndex;
        return {
            cf: a,
            showUnlessUserInControl: !1,
            Eg: !1,
            isDismissed: new R(!1)
        }
    }

    function fD(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function jD(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function tD(a, b) {
        const c = new R(!1),
            d = CA("ft-symbol-font-load-test", b);
        b = CA("ft-symbol-reference", d);
        const e = CA("ft-text-reference", d),
            f = kp(a, b);
        Io(np(f).map(g => g.width > 0 && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.dispose()
        });
        return c
    };

    function vD(a) {
        const b = new Qo,
            c = ap(a, 2500, () => void Po(b));
        return new wD(a, () => void xD(a, () => void c()), No(b))
    }

    function yD(a) {
        const b = new MutationObserver(() => {
            a.g()
        });
        b.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        xo(a, () => void b.disconnect())
    }

    function zD(a) {
        a.win.addEventListener("resize", a.g);
        xo(a, () => void a.win.removeEventListener("resize", a.g))
    }
    var wD = class extends Q {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = !1
        }
    };

    function xD(a, b) {
        b();
        a.setTimeout(b, 1500)
    };

    function AD(a) {
        return a.g[a.g.length - 1]
    }
    var CD = class {
        constructor() {
            this.j = BD;
            this.g = [];
            this.i = new Set
        }
        add(a) {
            if (this.i.has(a)) return !1;
            const b = kb(this.g, a, this.j);
            this.g.splice(b >= 0 ? b : -b - 1, 0, a);
            this.i.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.i.has(a)
        }
        delete(a) {
            db(this.g, b => b === a);
            return this.i.delete(a)
        }
        clear() {
            this.i.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function DD(a) {
        var b = a.Ec.P;
        let c;
        for (; a.j.ji() > b && (c = a.i.first());) {
            var d = a,
                e = c;
            ED(d, e);
            d.g.add(e)
        }
        for (;
            (d = AD(a.g)) && a.j.Ri() <= b;) FD(a, d);
        for (;
            (d = AD(a.g)) && (c = a.i.first()) && d.priority > c.priority;) b = a, e = c, ED(b, e), b.g.add(e), FD(a, d)
    }

    function FD(a, b) {
        a.g.delete(b);
        a.i.add(b) && (b.Df = a.j.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function ED(a, b) {
        b.Df && b.Df();
        b.Df = void 0;
        a.i.delete(b);
        b.isInToolbar.g(!1)
    }
    var GD = class {
        constructor(a, b) {
            this.Ec = a;
            this.j = b;
            this.g = new CD;
            this.i = new CD;
            this.l = 0;
            this.Ec.listen(() => void DD(this))
        }
        addButton(a) {
            const b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                Jf: this.l++,
                isInToolbar: new R(!1)
            };
            this.g.add(b);
            DD(this);
            return {
                isInToolbar: Mo(Eo(b.isInToolbar)),
                removeCallback: () => {
                    ED(this, b);
                    this.g.delete(b);
                    DD(this)
                }
            }
        }
    };

    function BD(a, b) {
        return a.priority === b.priority ? b.Jf - a.Jf : a.priority - b.priority
    };

    function HD(a) {
        if (!a.g) {
            const b = CC(a.win);
            a.g = Eo(b.j);
            wo(a, b)
        }
        return a.g
    }

    function ID(a, b, c) {
        const d = a.j.addRegulatoryMessage(b.messageSpec);
        b.messageSpec.regulatoryMessage.disableFloatingToolbarAutoShow || JD(a, d, c);
        Io(c, !0, () => {
            d.removeCallback()
        })
    }

    function JD(a, b, c) {
        a = HD(a);
        const d = Ho(a, !0, () => void b.showUnlessUserInControl()),
            e = Ho(a, !1, () => void b.hideUnlessUserInControl());
        Ho(Bo(b.isDismissed), !0, () => {
            d();
            e()
        });
        Io(c, !0, () => {
            d();
            e()
        })
    }
    var KD = class extends Q {
        constructor(a, b) {
            super();
            this.win = a;
            this.j = b;
            this.g = null
        }
        addRegulatoryMessage(a) {
            const b = new R(!1),
                c = Io(HD(this), !0, () => {
                    ID(this, a, b)
                });
            return {
                removeCallback: () => {
                    b.g(!0);
                    c()
                }
            }
        }
    };

    function LD(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new MD(a, b));
        return a.googFloatingToolbarManager
    }

    function ND(a) {
        a.g || (a.g = OD(a.win, a.Hb, a.Fc), wo(a, a.g.Ib), wo(a, a.g.bh), PD(a), QD(a, a.g.Ib));
        return a.g
    }

    function RD(a) {
        var b = [];
        a.g ? .Ib ? .C().A() ? (b.push(() => SD(a)), b.push(() => TD(a))) : (b.push(() => TD(a)), b.push(() => SD(a)));
        a.g ? .Ib ? .H() ? .A() && b.push(() => {
            const c = P(a.win);
            return {
                position: TC({
                    ga: Math.floor(c / 3),
                    sa: 10
                }),
                Ec: 0
            }
        });
        for (const c of b)
            if (b = c()) return b;
        return null
    }

    function PD(a) {
        a.Fc.P === null && a.g ? .position.g(RD(a))
    }

    function QD(a, b) {
        const c = vD(a.win);
        c.j || (yD(c), zD(c), c.j = !0);
        c.l.listen(() => void PD(a));
        wo(a, c);
        b.H().listen(() => void PD(a));
        b.C().listen(() => void PD(a));
        a.Fc.listen(() => void PD(a))
    }

    function SD(a) {
        var b = a.win;
        const c = P(a.win);
        return PC(b, {
            Tb: VC({
                ga: 50,
                Ba: 10
            }),
            bf: Math.floor(c / 3),
            Ab: 60,
            ef: cD(),
            Dd: Math.floor(c / 2),
            mb: 20
        }, [...(a.g ? .Ib.A() ? ? []), a.win.document.body]).te
    }

    function TD(a) {
        var b = a.win;
        const c = P(a.win);
        return PC(b, {
            Tb: TC({
                ga: 50,
                sa: 10
            }),
            bf: Math.floor(c / 3),
            Ab: 60,
            ef: cD(),
            Dd: Math.floor(c / 2),
            mb: 40
        }, [...(a.g ? .Ib.A() ? ? []), a.win.document.body]).te
    }
    class MD extends Q {
        constructor(a, b) {
            super();
            this.win = a;
            this.Hb = b;
            this.g = null;
            this.Fc = UD(this.win, this)
        }
        addButton(a) {
            return ND(this).rj.addButton(a)
        }
        addRegulatoryMessage(a) {
            return ND(this).bh.addRegulatoryMessage(a)
        }
    }

    function OD(a, b, c) {
        const d = new R(null),
            e = $C(a, {
                hc: 2,
                position: d.map(f => f ? .position ? ? null),
                Pa: b,
                Fc: c
            });
        b = new GD(d.map(f => f ? .Ec || 0), {
            addButton: f => e.addButton(f),
            ji: () => lD(e, {}),
            Ri: () => lD(e, {
                Gh: 1
            })
        });
        a = new KD(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            Ib: e,
            position: d,
            rj: b,
            bh: a
        }
    }

    function UD(a, b) {
        const c = new kA(a),
            d = new R(null),
            e = f => void d.g(f);
        xo(b, () => {
            jA(c, e)
        });
        c.g.maxZIndexListeners.push(e);
        d.g(iA(c));
        return d
    };
    const VD = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function WD(a, b, c, d, e) {
        a = new XD(a, b, c, d, e);
        if (a.l) {
            up(a.win, VD);
            var f = a.win;
            b = a.message;
            c = DA(f);
            e = c.shadowRoot;
            d = e.appendChild;
            f = new Xd(f.document);
            var g = uz('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500" rel="stylesheet"><style>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(e,
                je(f, pz(g)));
            d = CA("ipr-container", e);
            e = CA("ipr-button", d);
            b.actionButton ? (e.appendChild(b.actionButton.buttonText), e.addEventListener("click", b.actionButton.onClick)) : e.classList.add("ipr-display-none");
            d = CA("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.g = c.Za;
            Ex(a.l, a.g);
            a.j && a.j(cm(1));
            YD(a)
        } else ZD(a);
        return a
    }

    function YD(a) {
        const b = new xp(a.win);
        b.J(2E3);
        wo(a, b);
        vp(b, () => {
            $D(a);
            ZD(a);
            b.dispose()
        })
    }

    function ZD(a) {
        const b = LD(a.win, a.Hb).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        xo(a, () => void b.removeCallback());
        a.j && a.j(cm(2))
    }

    function $D(a) {
        a.g && (a.g.parentNode ? .removeChild(a.g), a.g = null)
    }
    var XD = class extends Q {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.l = b;
            this.message = c;
            this.Hb = d;
            this.j = e;
            this.g = null
        }
        i() {
            $D(this);
            super.i()
        }
    };
    var cE = (a, b, c, d, e) => U(Fr) ? aE(a, b, d, e) : bE(a, b, c, d, e);

    function bE(a, b, c, d, e) {
        const f = new MC(a, mC(a, e), new lC(b, d, "#FFF", "#4A4A4A", "normal"), new dC(b, c, d), "google-dns-link-placeholder");
        f.J();
        return () => f.i()
    }

    function aE(a, b, c, d) {
        const e = WD(a, mC(a, d), {
            actionButton: {
                buttonText: a.document.createTextNode(b),
                onClick: c
            }
        }, dE(a));
        return () => e.dispose()
    }

    function dE(a) {
        if (a = hC(a)) return a;
        W.ba(1234, Error("No messages"), void 0, void 0);
        return (new Eq).i()
    };

    function eE(a, b) {
        b && (a.i = cE(a.g, b.localizedDnsText, b.localizedDnsCollapseText, () => fE(a, b), a.l))
    }

    function gE(a) {
        var b = fC(a.g);
        if (hE(b.getInitialCcpaStatus(), b.InitialCcpaStatusEnum)) {
            var c = b.getLocalizedDnsText();
            b = b.getLocalizedDnsCollapseText();
            c != null && b != null && (a.i = cE(a.g, c, b, () => iE(a), a.l))
        }
    }

    function jE(a) {
        const b = eC(a.g);
        b.callbackQueue = b.callbackQueue || [];
        U(Pr) ? (gC(a.g).overrideDnsLink = !0, b.callbackQueue.push({
            INITIAL_US_STATES_DATA_READY: c => eE(a, c)
        })) : (fC(a.g).overrideDnsLink = !0, b.callbackQueue.push({
            INITIAL_CCPA_DATA_READY: () => gE(a)
        }))
    }

    function iE(a) {
        lA(a.j);
        fC(a.g).openConfirmationDialog(b => kE(a, b))
    }

    function fE(a, b) {
        lA(a.j);
        b.openConfirmationDialog(c => kE(a, c))
    }

    function kE(a, b) {
        b && a.i && (a.i(), a.i = null);
        mA(a.j)
    }
    class lE {
        constructor(a, b, c) {
            this.g = a;
            this.j = fA(b, 2147483643);
            this.l = c;
            this.i = null
        }
    }

    function hE(a, b) {
        switch (a) {
            case b.CCPA_DOES_NOT_APPLY:
            case b.OPTED_OUT:
                return !1;
            case b.NOT_OPTED_OUT:
                return !0;
            default:
                return !0
        }
    };

    function mE(a) {
        const b = a.document.createElement("ins");
        nE(a, b);
        u(b, {
            display: "flex",
            padding: "8px 0px",
            width: "100%"
        });
        return b
    }

    function oE(a, b, c, d) {
        const e = ie(Wd(a), "IMG");
        e.src = b;
        d && e.setAttribute("aria-label", d);
        nE(a, e);
        u(e, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        e.addEventListener("click", f => {
            c();
            f.stopPropagation()
        });
        return e
    }

    function pE(a, b) {
        const c = b.document.createElement("span");
        nE(b, c);
        u(c, {
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.l));
        c.addEventListener("click", d => {
            a.i();
            d.stopPropagation()
        });
        return c
    }

    function qE(a, b) {
        const c = b.document.createElement("span");
        c.appendChild(b.document.createTextNode(a.j));
        u(c, pr(b));
        u(c, {
            "border-top": "11px solid #ECEDED",
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            "line-height": "1414px",
            padding: "8px 32px",
            "text-align": "center"
        });
        return c
    }

    function rE(a) {
        const b = a.document.createElement("div");
        u(b, pr(a));
        u(b, {
            "align-items": "flex-start",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 3px 1px rgba(60,64,67,0.5)",
            display: "inline-flex",
            "flex-direction": "column",
            "float": "left"
        });
        return b
    }
    class sE {
        constructor(a, b, c, d) {
            this.l = a;
            this.A = b;
            this.j = c;
            this.i = d;
            this.g = new R(!1)
        }
        Ja(a, b, c, d) {
            c = mE(a);
            const e = oE(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", d),
                f = oE(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", this.i),
                g = pE(this, a),
                h = oE(a, "https://www.gstatic.com/adsense/autoads/icons/close_24px_grey_700.svg", b, this.A);
            u(h, {
                "margin-left": "auto"
            });
            c.appendChild(e);
            c.appendChild(f);
            c.appendChild(g);
            c.appendChild(h);
            const k = qE(this, a);
            a = rE(a);
            a.appendChild(c);
            a.appendChild(k);
            this.g.listen(l => {
                u(e, {
                    display: l ? "none" : "inline"
                });
                u(f, {
                    display: l ? "inline" : "none"
                });
                l ? (u(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), u(h, {
                        "margin-right": "12px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 50ms, opacity 50ms 50ms, width 50ms"
                    }), u(k, {
                        "border-width": "1px",
                        "line-height": "14px",
                        "max-width": "100vw",
                        opacity: "1",
                        padding: "8px 32px",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms, padding 50ms"
                    })) :
                    (u(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), u(h, {
                        "margin-right": "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 50ms 50ms, opacity 50ms, width 50ms 50ms"
                    }), u(k, {
                        "border-width": "0px",
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        padding: "0",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms, padding 50ms 50ms"
                    }))
            }, !0);
            return a
        }
        qg() {
            return 71
        }
        Ng() {
            this.g.g(!1);
            return 0
        }
        Og() {
            this.g.g(!0)
        }
    }

    function nE(a, b) {
        u(b, pr(a));
        u(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#1A73E8",
            "user-select": "none"
        })
    };

    function tE(a) {
        uE(a.j, b => {
                var c = a.i,
                    d = b.Nj,
                    e = b.ei,
                    f = b.Mh;
                b = b.showRevocationMessage;
                var g = a.l;
                U(Hr) ? (e = mC(c, g), d = {
                    actionButton: {
                        buttonText: c.document.createTextNode(d),
                        onClick: b
                    },
                    informationText: c.document.createTextNode(f)
                }, f = hC(c), f || (W.ba(1233, Error("No messages"), void 0, void 0), f = (new Eq).i()), WD(c, e, d, f)) : (new MC(c, mC(c, g), new lC(d, b, "#1A73E8", "#FFF", "bold", "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_blue_600.svg", "2px solid #ECEDED", f), new sE(d, e, f, b), "google-revocation-link-placeholder")).J()
            },
            () => {
                mA(a.g);
                vE(a)
            })
    }

    function wE(a) {
        lA(a.g);
        tE(a)
    }

    function vE(a) {
        U(Gr) && (a.i.__tcfapi ? a.i.__tcfapi("addEventListener", 2, (b, c) => {
            c && b.eventStatus == "cmpuishown" ? lA(a.g) : mA(a.g)
        }) : W.ba(1250, Error("No TCF API function"), void 0, void 0))
    }
    class xE {
        constructor(a, b, c, d) {
            this.i = a;
            this.g = fA(b, 2147483643);
            this.l = c;
            this.j = d
        }
    };
    var yE = a => {
            if (!a || Ai(a, 1) == null) return !1;
            a = Ai(a, 1);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoConsentUiStatus: " + a);
            }
        },
        zE = a => {
            if (!a || Ai(a, 3) == null) return !1;
            a = Ai(a, 3);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + a);
            }
        },
        AE = a => a ? yi(a, 5) === !0 : !1,
        BE = a => a ? yi(a, 6) === !0 : !1;

    function CE() {
        return "m202408140101"
    };

    function DE(a) {
        let b = a.location.href;
        if (a === a.top) return {
            url: b,
            Ye: !0
        };
        let c = !1;
        const d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && b.indexOf(a) === -1 && (c = !1, b = a);
        return {
            url: b,
            Ye: c
        }
    };

    function EE(a, b) {
        xe(a, (c, d) => {
            b[d] = c
        })
    }

    function FE(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && pe(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function GE() {
        if (HE) return HE;
        const a = Vj() || window,
            b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? HE = b : a.google_persistent_state_async = HE = new IE
    }

    function JE(a, b, c) {
        b = KE[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function LE(a, b, c) {
        return JE(a, b, () => c)
    }

    function ME(a, b, c) {
        return a.S[KE[b] || `google_ps_${b}`] = c
    }

    function NE(a, b) {
        return ME(a, b, LE(a, b, 0) + 1)
    }

    function OE() {
        var a = GE();
        return LE(a, 20, {})
    }

    function PE() {
        var a = GE();
        const b = LE(a, 31, !1);
        b || ME(a, 31, !0);
        return !b
    }

    function QE() {
        var a = GE();
        const b = LE(a, 41, !1);
        b || ME(a, 41, !0);
        return !b
    }

    function RE() {
        var a = GE();
        return LE(a, 26)
    }

    function SE() {
        var a = GE();
        return LE(a, 28, [])
    }

    function TE() {
        var a = GE();
        return JE(a, 39, UE)
    }
    var IE = class {
            constructor() {
                this.S = {}
            }
        },
        HE = null;
    const KE = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function VE(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function WE(a, b) {
        a = VE(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        const c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function yn(a, b) {
        a.g.size > 0 || XE(a);
        const c = a.g.get(0);
        c ? c.push(b) : a.g.set(0, [b])
    }

    function YE(a, b, c, d) {
        Hb(b, c, d);
        xo(a, () => Ib(b, c, d))
    }

    function ZE(a, b) {
        a.j !== 1 && (a.j = 1, a.g.size > 0 && $E(a, b))
    }

    function XE(a) {
        a.win.document.visibilityState ? YE(a, a.win.document, "visibilitychange", b => {
            a.win.document.visibilityState === "hidden" && ZE(a, b);
            a.win.document.visibilityState === "visible" && (a.j = 0)
        }) : "onpagehide" in a.win ? (YE(a, a.win, "pagehide", b => {
            ZE(a, b)
        }), YE(a, a.win, "pageshow", () => {
            a.j = 0
        })) : YE(a, a.win, "beforeunload", b => {
            ZE(a, b)
        })
    }

    function $E(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var aF = class extends Q {
        constructor(a) {
            super();
            this.win = a;
            this.j = 0;
            this.g = new Map
        }
    };
    async function bF(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} ${200}`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function cF(a) {
        const b = a.g.pc;
        return b !== null && b !== 0 ? b : a.g.pc = Ye(a.win)
    }

    function dF(a) {
        var b = a.g.wpc;
        if (b === null || b === "") b = a.g, a = a.win, a = a.google_ad_client ? String(a.google_ad_client) : VE(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? "", b = b.wpc = a;
        return b
    }

    function eF(a, b) {
        var c = new an;
        var d = cF(a);
        c = Oi(c, 1, d);
        c = $m(c.Ub(dF(a)), a.g.sd);
        return Oi(c, 7, Math.round(b || a.win.performance.now()))
    }
    async function fF(a) {
        await bF(a.win, () => !(!cF(a) || !dF(a)))
    }

    function gF() {
        var a = O(hF);
        a.i && (a.g.tar += 1)
    }

    function iF(a) {
        var b = O(hF);
        if (b.i) {
            var c = b.l;
            a(c);
            b.g.cc = Ti(c)
        }
    }
    async function jF(a, b, c) {
        if (a.i && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.win.performance.now();
            await fF(a);
            var e = a.Z;
            a = eF(a, d);
            d = new Rl;
            b = M(d, 1, b);
            c = di(b, 2, c, Jg);
            c = B(a, 9, bn, c);
            sn(e, c)
        }
    }
    async function kF(a, b) {
        await fF(a);
        var c = eF(a);
        b = B(c, 5, bn, b);
        a.i && !a.g.le.includes(2) && (a.g.le.push(2), sn(a.Z, b))
    }
    async function lF(a, b, c) {
        await fF(a);
        var d = a.Z;
        a = $m(eF(a, c), 1);
        b = B(a, 6, bn, b);
        sn(d, b)
    }
    async function mF(a, b) {
        await fF(a);
        var c = a.Z;
        a = $m(eF(a), 1);
        b = B(a, 13, bn, b);
        sn(c, b)
    }
    async function nF(a, b) {
        if (a.i) {
            await fF(a);
            var c = a.Z;
            a = eF(a);
            b = B(a, 11, bn, b);
            sn(c, b)
        }
    }
    var hF = class {
        constructor(a, b) {
            this.win = Vj() || window;
            this.j = b ? ? new aF(this.win);
            this.Z = a ? ? new An(CE(), 100, 100, !0, this.j);
            this.g = JE(GE(), 33, () => {
                const c = V(Er),
                    d = c > 0 && we() < 1 / c,
                    e = V(ct);
                return {
                    sd: c,
                    ssp: d,
                    sds: e,
                    ssps: e > 0 && we() < 1 / e,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get i() {
            return this.g.ssp
        }
        get bd() {
            return this.g.cu
        }
        set bd(a) {
            this.g.cu = a
        }
        get l() {
            return fy(1227, () => Ui(Sl, Ch(this.g.cc || []))) || new Sl
        }
    };

    function oF(a) {
        var b = new pF;
        return Ki(b, 1, a)
    }
    var pF = class extends N {
        constructor() {
            super()
        }
    };

    function qF(a) {
        if (a.i.adsbygoogle_ama_fc_has_run !== !0) {
            var b = yE(a.g),
                c = zE(a.g),
                d = !1;
            b && (wE(new xE(a.i, a.A, a.l || ni(a.g, Mq, 4, w($f)), a.j)), d = !0);
            c && (jE(new lE(a.i, a.A, a.l || ni(a.g, Mq, 4, w($f)))), d = !0);
            iF(g => {
                g = L(g, 9, !0);
                g = L(g, 10, b);
                L(g, 11, c)
            });
            var e = AE(a.g),
                f = BE(a.g) || U(ss);
            e && (d = !0);
            d && (d = oF(e && f), a.j.start(U(Ar), d), a.i.adsbygoogle_ama_fc_has_run = !0)
        }
    }
    class rF {
        constructor(a, b, c, d, e) {
            this.i = a;
            this.j = b;
            this.g = c;
            this.A = d;
            this.l = e || null
        }
    };

    function sF(a, b, c, d, e, f) {
        try {
            const g = a.g,
                h = ue("SCRIPT", g);
            h.async = !0;
            ud(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                c > 0 ? sF(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function tF(a, b, c = () => {}, d = () => {}) {
        sF(Wd(a), b, 0, !1, c, d)
    };

    function uF(a = null) {
        a = a || q;
        return a.googlefc || (a.googlefc = {})
    };
    Mb(Ln).map(a => Number(a));
    Mb(Mn).map(a => Number(a));
    const vF = q.URL;

    function wF(a) {
        const b = c => encodeURIComponent(c).replace(/[!()~']|(%20)/g, d => ({
            "!": "%21",
            "(": "%28",
            ")": "%29",
            "%20": "+",
            "'": "%27",
            "~": "%7E"
        })[d]);
        return Array.from(a, c => b(c[0]) + "=" + b(c[1])).join("&")
    };

    function xF(a) {
        var b = (new vF(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return b === "alwaysshow" ? b : a === "alwaysshow" ? a : null
    }

    function yF(a) {
        const b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = (new vF(a.location.href)).searchParams.get("fctype")) && b.indexOf(a) !== -1 ? a : null
    }

    function zF(a) {
        var b = new vF(a),
            c = {
                search: "",
                hash: ""
            };
        a = {};
        b && (a.protocol = b.protocol, a.username = b.username, a.password = b.password, a.hostname = b.hostname, a.port = b.port, a.pathname = b.pathname, a.search = b.search, a.hash = b.hash);
        Object.assign(a, c);
        if (a.port && a.port[0] === ":") throw Error("port should not start with ':'");
        a.hash && a.hash[0] != "#" && (a.hash = "#" + a.hash);
        c.search ? c.search[0] != "?" && (a.search = "?" + c.search) : c.searchParams && (a.search = "?" + wF(c.searchParams), a.searchParams = void 0);
        b = "";
        a.protocol && (b += a.protocol +
            "//");
        c = a.username;
        var d = a.password;
        b = b + (c && d ? c + ":" + d + "@" : c ? c + "@" : d ? ":" + d + "@" : "") + (a.hostname || "");
        a.port && (b += ":" + a.port);
        b += a.pathname || "";
        b += a.search || "";
        b += a.hash || "";
        a = (new vF(b)).toString();
        a.charAt(a.length - 1) === "/" && (a = a.substring(0, a.length - 1));
        return a.toString().length <= 1E3 ? a : null
    };

    function AF(a, b) {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = ue("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var BF = Vi(class extends N {});

    function CF(a) {
        if (a.g) return a.g;
        a.I && a.I(a.j) ? a.g = a.j : a.g = Le(a.j, a.O);
        return a.g ? ? null
    }

    function DF(a) {
        a.l || (a.l = b => {
            try {
                var c = a.H ? a.H(b) : void 0;
                if (c) {
                    var d = c.kf,
                        e = a.F.get(d);
                    e && (e.zj || a.F.delete(d), e.Pb ? .(e.ri, c.payload))
                }
            } catch (f) {}
        }, Hb(a.j, "message", a.l))
    }

    function EF(a, b, c) {
        if (CF(a))
            if (a.g === a.j)(b = a.C.get(b)) && b(a.g, c);
            else {
                var d = a.A.get(b);
                if (d && d.Cc) {
                    DF(a);
                    var e = ++a.R;
                    a.F.set(e, {
                        Pb: d.Pb,
                        ri: d.zd(c),
                        zj: b === "addEventListener"
                    });
                    a.g.postMessage(d.Cc(c, e), "*")
                }
            }
    }
    var FF = class extends Q {
        constructor(a, b, c, d) {
            super();
            this.O = b;
            this.I = c;
            this.H = d;
            this.C = new Map;
            this.R = 0;
            this.A = new Map;
            this.F = new Map;
            this.l = void 0;
            this.j = a
        }
        i() {
            delete this.g;
            this.C.clear();
            this.A.clear();
            this.F.clear();
            this.l && (Ib(this.j, "message", this.l), delete this.l);
            delete this.j;
            delete this.H;
            super.i()
        }
    };
    const GF = (a, b) => {
            const c = {
                cb: d => {
                    d = BF(d);
                    b.Sa({
                        jc: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        HF = {
            zd: a => a.Sa,
            Cc: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            Pb: (a, b) => {
                a({
                    jc: b
                })
            }
        };

    function IF(a) {
        a = BF(a.data.__fciReturn);
        return {
            payload: a,
            kf: Ci(a, 1)
        }
    }

    function JF(a, b = !1) {
        if (b) return !1;
        a.j || (a.g = !!CF(a.caller), a.j = !0);
        return a.g
    }

    function KF(a) {
        return new Promise(b => {
            JF(a) && EF(a.caller, "getDataWithCallback", {
                command: "loaded",
                Sa: c => {
                    b(c.jc)
                }
            })
        })
    }

    function LF(a, b) {
        JF(a) && EF(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: Si(b),
            Sa: () => {}
        })
    }
    var MF = class extends Q {
        constructor(a) {
            super();
            this.g = this.j = !1;
            this.caller = new FF(a, "googlefcPresent", void 0, IF);
            this.caller.C.set("getDataWithCallback", GF);
            this.caller.A.set("getDataWithCallback", HF)
        }
        i() {
            this.caller.dispose();
            super.i()
        }
    };
    const NF = a => {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    };

    function OF(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = NF(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (pj({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function PF(a, b = {}) {
        return OF(a) ? a.gdprApplies === !1 ? !0 : a.tcString === "tcunavailable" ? !b.idpcApplies : (b.idpcApplies || a.gdprApplies !== void 0 || b.ko) && (b.idpcApplies || typeof a.tcString === "string" && a.tcString.length) ? QF(a, "1", 0) : !0 : !1
    }

    function QF(a, b, c) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var d = a.publisher.restrictions[b];
                if (d !== void 0) {
                    d = d["755"];
                    break a
                }
            }
            d = void 0
        }
        if (d === 0) return !1;
        let e = c;c === 2 ? (e = 0, d === 2 && (e = 1)) : c === 3 && (e = 1, d === 1 && (e = 0));
        if (e === 0) a = a.purpose && a.vendor ? (c = RF(a.vendor.consents, "755")) && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : c && RF(a.purpose.consents, b) : !0;
        else {
            var f;
            e === 1 ? f = a.purpose && a.vendor ? RF(a.purpose.legitimateInterests, b) && RF(a.vendor.legitimateInterests, "755") : !0 : f = !0;
            a = f
        }
        return a
    }

    function RF(a, b) {
        return !(!a || !a[b])
    }

    function SF(a, b, c) {
        return a.gdprApplies === !1 ? !0 : b.every(d => QF(a, d, c))
    }

    function TF(a) {
        if (a.g) return a.g;
        a.g = Le(a.j, "__tcfapiLocator");
        return a.g
    }

    function UF(a) {
        return typeof a.j.__tcfapi === "function" || TF(a) != null
    }

    function VF(a, b, c, d) {
        c || (c = () => {});
        if (typeof a.j.__tcfapi === "function") a = a.j.__tcfapi, a(b, 2, c, d);
        else if (TF(a)) {
            WF(a);
            const e = ++a.H;
            a.C[e] = c;
            a.g && a.g.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function XF(a, b) {
        let c = {
            internalErrorState: 0,
            internalBlockOnErrors: a.A
        };
        const d = Bb(() => b(c));
        let e = 0;
        a.F !== -1 && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.F));
        VF(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = NF(c), c.internalBlockOnErrors = a.A, OF(c) ? (c.internalErrorState != 0 && (c.tcString = "tcunavailable"), VF(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : (c.cmpStatus === "error" || c.internalErrorState !== 0) && (f = e) && clearTimeout(f))
        })
    }

    function WF(a) {
        a.l || (a.l = b => {
            try {
                var c = (typeof b.data === "string" ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.C[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, Hb(a.j, "message", a.l))
    }
    class YF extends Q {
        constructor(a, b = {}) {
            super();
            this.j = a;
            this.g = null;
            this.C = {};
            this.H = 0;
            this.F = b.timeoutMs ? ? 500;
            this.A = b.Sh ? ? !1;
            this.l = null
        }
        i() {
            this.C = {};
            this.l && (Ib(this.j, "message", this.l), delete this.l);
            delete this.C;
            delete this.j;
            delete this.g;
            super.i()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.A
            };
            const c = Bb(() => a(b));
            let d = 0;
            this.F !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.F));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = NF(b),
                    b.internalBlockOnErrors = this.A, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                VF(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && VF(this, "removeEventListener", null, a.listenerId)
        }
    };

    function uE(a, b, c) {
        const d = uF(a.win);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                const e = uF(a.win),
                    f = new YF(a.win);
                UF(f) && XF(f, g => {
                    g.cmpId === 300 && g.tcString && g.tcString !== "tcunavailable" && b({
                        Nj: (0, e.getDefaultConsentRevocationText)(),
                        ei: (0, e.getDefaultConsentRevocationCloseText)(),
                        Mh: (0, e.getDefaultConsentRevocationAttestationText)(),
                        showRevocationMessage: () => {
                            (0, e.showRevocationMessage)()
                        }
                    })
                });
                c()
            }
        })
    }

    function ZF(a, b = !1, c) {
        const d = {};
        try {
            const f = xF(a.win),
                g = yF(a.win);
            d.fc = f;
            d.fctype = g
        } catch (f) {}
        let e;
        try {
            e = zF(a.win.location.href)
        } catch (f) {}
        b && e && (d.href = e);
        b = jc({
            id: a.g
        }, { ...d,
            ers: 2
        });
        tF(a.win, b, () => {}, () => {});
        c && LF(new MF(a.win), c)
    }
    var $F = class {
        constructor(a, b) {
            this.win = a;
            this.g = b
        }
        start(a = !1, b) {
            if (this.win === this.win.top) try {
                AF(this.win, "googlefcPresent"), ZF(this, a, b)
            } catch (c) {}
        }
    };
    const aG = new Set(["ARTICLE", "SECTION"]);
    var bG = class {
        constructor(a) {
            this.g = a
        }
    };

    function cG(a, b) {
        return Array.from(b.classList).map(c => `${a}=${c}`)
    }

    function dG(a) {
        return a.classList.length > 0
    }

    function eG(a) {
        return aG.has(a.tagName)
    };
    var fG = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function gG(a) {
        return Da(a) && a.nodeType == 1 && a.tagName == "FIGURE" ? a : (a = a.parentNode) ? gG(a) : null
    };
    var hG = a => {
        var b = a.src;
        const c = a.getAttribute("data-src") || a.getAttribute("data-lazy-src");
        (b && b.startsWith("data:") && c ? c : b || c) ? (a.getAttribute("srcset"), b = (b = gG(a)) ? (b = b.getElementsByTagName("figcaption")[0]) ? b.textContent : null : null, a = new fG(a, b || a.getAttribute("alt") || null)) : a = null;
        return a
    };
    var iG = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            const c = this.map.get(a);
            return c ? (b = c.delete(b), c.size === 0 && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            let c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            let a = 0;
            for (const b of this.map.values()) a += b.size;
            return a
        }
        values() {
            const a = this.map;
            return function() {
                return function*() {
                    for (const b of a.values()) yield* b
                }()
            }()
        }[Symbol.iterator]() {
            const a =
                this.map;
            return function() {
                return function*() {
                    for (const [b, c] of a) {
                        const d = b,
                            e = c;
                        for (const f of e) yield [d, f]
                    }
                }()
            }()
        }
    };

    function jG(a) {
        return [a[0],
            [...a[1]]
        ]
    };

    function kG(a) {
        return Array.from(lG(a).map.values()).filter(b => b.size >= 3).map(b => [...b])
    }

    function mG(a, b) {
        return b.every(c => {
            var d = a.g.getBoundingClientRect(c.g);
            if (d = d.height >= 50 && d.width >= a.A) {
                var e = a.g.getBoundingClientRect(c.g);
                d = a.l;
                e = new OC(e.left, e.right);
                d = Math.max(d.start, e.start) <= Math.min(d.end, e.end)
            }
            return d && ro(a.j, {
                eb: c.g,
                Xa: nG,
                Db: !0
            }) === null
        })
    }

    function oG(a) {
        return kG(a).sort(pG).find(b => mG(a, b)) || []
    }

    function lG(a) {
        return qG(Array.from(a.win.document.getElementsByTagName("IMG")).map(hG).filter(Rp), b => {
            var c = [...cG("CLASS_NAME", b.g)],
                d = b.g.parentElement;
            d = [...(d ? cG("PARENT_CLASS_NAME", d) : [])];
            var e = b.g.parentElement ? .parentElement;
            e = [...(e ? cG("GRANDPARENT_CLASS_NAME", e) : [])];
            var f = (f = ro(a.i.g, {
                eb: b.g,
                Xa: dG
            })) ? cG("NEAREST_ANCESTOR_CLASS_NAME", f) : [];
            return [...c, ...d, ...e, ...f, ...(b.i ? ["HAS_CAPTION=true"] : []), ...(ro(a.i.g, {
                eb: b.g,
                Xa: eG
            }) ? ["ARTICLE_LIKE_ANCESTOR=true"] : [])]
        })
    }
    var rG = class {
        constructor(a, b, c, d, e) {
            var f = new hp;
            this.win = a;
            this.l = b;
            this.A = c;
            this.g = f;
            this.j = d;
            this.i = e
        }
    };

    function qG(a, b) {
        const c = new iG;
        for (const d of a)
            for (const e of b(d)) c.add(e, d);
        return c
    }

    function nG(a) {
        return a.tagName === "A" && a.hasAttribute("href")
    }

    function pG(a, b) {
        return b.length - a.length
    };

    function sG(a) {
        const b = a.l.parentNode;
        if (!b) throw Error("Image not in the DOM");
        const c = tG(a.j),
            d = uG(a.j);
        c.appendChild(d);
        b.insertBefore(c, a.l.nextSibling);
        a.A.g().i(e => {
            var f = a.j;
            const g = d.getBoundingClientRect(),
                h = g.top - e.top,
                k = g.left - e.left,
                l = g.width - e.width;
            e = g.height - e.height;
            Math.abs(h) < 1 && Math.abs(k) < 1 && Math.abs(l) < 1 && Math.abs(e) < 1 || (f = f.getComputedStyle(d), u(d, {
                top: parseInt(f.top, 10) - h + "px",
                left: parseInt(f.left, 10) - k + "px",
                width: parseInt(f.width, 10) - l + "px",
                height: parseInt(f.height, 10) - e + "px"
            }))
        });
        return d
    }

    function vG(a) {
        a.g || (a.g = sG(a));
        return a.g
    }
    var wG = class extends Q {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.l = b;
            this.A = c;
            this.g = null
        }
        i() {
            if (this.g) {
                var a = this.g;
                const b = a.parentNode;
                b && b.removeChild(a);
                this.g = null
            }
            super.i()
        }
    };

    function uG(a) {
        const b = a.document.createElement("div");
        u(b, pr(a));
        u(b, {
            position: "absolute",
            left: "0",
            top: "0",
            width: "0",
            height: "0",
            "pointer-events": "none"
        });
        return b
    }

    function tG(a) {
        const b = a.document.createElement("div");
        u(b, pr(a));
        u(b, {
            position: "relative",
            width: "0",
            height: "0"
        });
        return b
    };

    function xG(a) {
        const b = new R(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return Eo(b)
    };
    const yG = ["Google Material Icons", "Roboto"];

    function zG({
        win: a,
        za: b,
        Si: c,
        webPropertyCode: d,
        Pa: e,
        M: f
    }) {
        const g = new jp(a, c);
        c = new wG(a, c, g);
        wo(c, g);
        a = new AG(a, d, e, b, c, f);
        wo(a, c);
        a.J()
    }
    var AG = class extends Q {
        constructor(a, b, c, d, e, f) {
            super();
            this.win = a;
            this.webPropertyCode = b;
            this.Pa = c;
            this.za = d;
            this.j = e;
            this.M = f;
            this.g = new R(!1)
        }
        J() {
            const a = BG(this.win, this.webPropertyCode, this.Pa);
            vG(this.j).appendChild(a.Ci);
            yu(this.win, a.ua);
            xG(a.ua).i(b => {
                if (b !== null) {
                    switch (b) {
                        case "unfilled":
                            this.dispose();
                            break;
                        case "filled":
                            this.g.g(!0);
                            break;
                        default:
                            this.M ? .reportError("Unhandled AdStatus: " + String(b)), this.dispose()
                    }
                    this.M ? .Jj(this.za, b)
                }
            });
            Io(this.g, !0, () => void a.aj.g(!0));
            a.wi.listen(() =>
                void this.dispose());
            a.vi.listen(() => void this.M ? .Hj(this.za))
        }
    };

    function BG(a, b, c) {
        const d = new R(!1),
            e = a.document.createElement("div");
        u(e, pr(a));
        u(e, {
            position: "absolute",
            top: "50%",
            left: "0",
            transform: "translateY(-50%)",
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "background-color": "rgba(0, 0, 0, 0.75)",
            opacity: "0",
            transition: "opacity 0.25s ease-in-out",
            "box-sizing": "border-box",
            padding: "40px 5px 5px 5px"
        });
        Ho(d, !0, () => void u(e, {
            opacity: "1"
        }));
        Ho(d, !1, () => void u(e, {
            opacity: "0"
        }));
        const f = a.document.createElement("div");
        u(f, pr(a));
        u(f, {
            display: "block",
            width: "100%",
            height: "100%"
        });
        e.appendChild(f);
        const {
            Eh: g,
            Zi: h
        } = CG(a, b);
        f.appendChild(g);
        e.appendChild(DG(a, K(c, 1)));
        b = EG(a, K(c, 2));
        e.appendChild(b.Yh);
        b.ze.listen(() => void d.g(!1));
        return {
            aj: d,
            Ci: e,
            ua: h,
            vi: b.ze,
            wi: b.ze.delay(a, 450)
        }
    }

    function DG(a, b) {
        const c = a.document.createElement("div");
        u(c, pr(a));
        u(c, {
            position: "absolute",
            top: "10px",
            width: "100%",
            color: "white",
            "font-family": "Roboto",
            "font-size": "12px",
            "line-height": "16px",
            "text-align": "center"
        });
        c.appendChild(a.document.createTextNode(b));
        return c
    }

    function EG(a, b) {
        const c = a.document.createElement("button");
        c.setAttribute("aria-label", b);
        u(c, pr(a));
        u(c, {
            position: "absolute",
            top: "10px",
            right: "10px",
            display: "block",
            cursor: "pointer",
            width: "24px",
            height: "24px",
            "font-size": "24px",
            "user-select": "none",
            color: "white"
        });
        b = a.document.createElement("gm-icon");
        b.className = "google-material-icons";
        b.appendChild(a.document.createTextNode("close"));
        c.appendChild(b);
        const d = new Qo;
        c.addEventListener("click", () => void Po(d));
        return {
            Yh: c,
            ze: No(d)
        }
    }

    function CG(a, b) {
        a = uu(a.document, b, null, null, {});
        return {
            Eh: a.nb,
            Zi: a.ua
        }
    };

    function FG({
        target: a,
        threshold: b = 0
    }) {
        const c = new GG;
        c.J(a, b);
        return c
    }
    var GG = class extends Q {
        constructor() {
            super();
            this.g = new R(!1)
        }
        J(a, b) {
            const c = new IntersectionObserver(d => {
                for (const e of d)
                    if (e.target === a) {
                        this.g.g(e.isIntersecting);
                        break
                    }
            }, {
                threshold: b
            });
            c.observe(a);
            xo(this, () => void c.disconnect())
        }
    };

    function HG(a) {
        const b = IG(a.win, Hi(a.g, 2) ? ? 250, Hi(a.g, 3) ? ? 300);
        let c = 1;
        return oG(a.l).map(d => ({
            za: c++,
            image: d,
            gb: b(d)
        }))
    }

    function JG(a, b) {
        const c = FG({
            target: b.image.g,
            threshold: Ii(a.g) ? ? .8
        });
        a.j.push(c);
        Io(Lo(c.g, a.win, Hi(a.g, 5) ? ? 3E3, d => d), !0, () => {
            if (a.i < (Hi(a.g, 1) ? ? 1)) {
                zG({
                    win: a.win,
                    za: b.za,
                    Si: b.image.g,
                    webPropertyCode: a.webPropertyCode,
                    Pa: a.Pa,
                    M: a.M
                });
                a.i++;
                if (!(a.i < (Hi(a.g, 1) ? ? 1)))
                    for (; a.j.length;) a.j.pop() ? .dispose();
                a.M ? .Ij(b.za)
            }
        })
    }

    function KG(a) {
        const b = HG(a);
        b.filter(LG).forEach(c => void JG(a, c));
        a.M ? .Kj(b.map(c => ({
            za: c.za,
            gb: c.gb
        })))
    }
    var MG = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.webPropertyCode = b;
            this.g = c;
            this.Pa = d;
            this.l = e;
            this.M = f;
            this.j = [];
            this.i = 0
        }
    };

    function LG(a) {
        return a.gb.rejectionReasons.length === 0
    }

    function IG(a, b, c) {
        const d = P(a);
        return e => {
            e = e.g.getBoundingClientRect();
            const f = [];
            e.width < b && f.push(1);
            e.height < c && f.push(2);
            e.top <= d && f.push(3);
            return {
                Ab: e.width,
                Pe: e.height,
                xi: e.top - d,
                rejectionReasons: f
            }
        }
    };

    function NG(a, b) {
        a.za = b;
        return a
    }
    var OG = class {
        constructor(a, b, c, d, e) {
            this.A = a;
            this.webPropertyCode = b;
            this.hostname = c;
            this.j = d;
            this.l = e;
            this.errorMessage = this.i = this.za = this.g = null
        }
    };

    function PG(a, b) {
        return new OG(b, a.webPropertyCode, a.hostname, a.i, a.l)
    }

    function QG(a, b, c) {
        var d = a.j++;
        a.g === null ? (a.g = xk(), a = 0) : a = xk() - a.g;
        var e = b.A,
            f = b.webPropertyCode,
            g = b.hostname,
            h = b.j,
            k = b.l.map(encodeURIComponent).join(",");
        if (b.g) {
            var l = {
                imcnt: b.g.length
            };
            var m = Math.min(b.g.length, 10);
            for (let n = 0; n < m; n++) {
                const p = `im${n}`;
                l[`${p}_id`] = b.g[n].za;
                l[`${p}_s_w`] = b.g[n].gb.Ab;
                l[`${p}_s_h`] = b.g[n].gb.Pe;
                l[`${p}_s_dbf`] = b.g[n].gb.xi;
                b.g[n].gb.rejectionReasons.length > 0 && (l[`${p}_s_rej`] = b.g[n].gb.rejectionReasons.join(","))
            }
        } else l = null;
        hy("abg::imovad", {
            typ: e,
            wpc: f,
            hst: g,
            pvsid: h,
            peid: k,
            rate: c,
            num: d,
            tim: a,
            ...(b.za === null ? {} : {
                imid: b.za
            }),
            ...(b.i === null ? {} : {
                astat: b.i
            }),
            ...(b.errorMessage === null ? {} : {
                errm: b.errorMessage
            }),
            ...l
        }, c)
    }
    var RG = class {
        constructor(a, b, c, d) {
            this.webPropertyCode = a;
            this.hostname = b;
            this.i = c;
            this.l = d;
            this.j = 0;
            this.g = null
        }
        Kj(a) {
            var b = PG(this, "fndi");
            b.g = a;
            QG(this, b, a.length > 0 ? 1 : .1)
        }
        Ij(a) {
            a = NG(PG(this, "adpl"), a);
            QG(this, a, 1)
        }
        Jj(a, b) {
            a = NG(PG(this, "adst"), a);
            a.i = b;
            QG(this, a, 1)
        }
        Hj(a) {
            a = NG(PG(this, "adis"), a);
            QG(this, a, 1)
        }
        reportError(a) {
            var b = PG(this, "err");
            b.errorMessage = a;
            QG(this, b, .1)
        }
    };

    function SG(a, b, c) {
        return (a = a.g()) && yi(a, 11) ? c.map(d => d.j()) : c.map(d => d.A(b))
    };
    var TG = class extends N {
        getHeight() {
            return Bi(this, 2)
        }
    };

    function UG(a, b) {
        return Li(a, 1, b)
    }

    function VG(a, b) {
        return oi(a, 2, b)
    }
    var WG = class extends N {};
    var XG = class extends N {
        constructor() {
            super()
        }
    };
    var YG = class extends N {
            constructor() {
                super()
            }
        },
        ZG = [1, 2];
    const $G = new Set([7, 1]);
    var aH = class {
        constructor() {
            this.j = new iG;
            this.l = []
        }
        g(a, b) {
            $G.has(b) || Np(Kp(Nv(a), c => void this.j.add(c, b)), c => void this.l.push(c))
        }
        i(a, b) {
            for (const c of a) this.g(c, b)
        }
    };

    function bH(a) {
        return new cq(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_phwr: 2.189,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    class cH {
        g(a) {
            return bH(Math.floor(a.i))
        }
    };
    var dH = class extends N {
        constructor() {
            super()
        }
    };

    function eH(a, b) {
        var c = b.adClient;
        if (typeof c !== "string" || !c) return !1;
        a.he = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        Da(c) && (a.D = c);
        if (Array.isArray(b.fillMessage) && b.fillMessage.length > 0) {
            a.B = {};
            for (const d of b.fillMessage) a.B[d.key] = d.value
        }
        a.l = b.adWidth;
        a.i = b.adHeight;
        ik(a.l) && ik(a.i) || hy("rctnosize", b);
        return !0
    }
    var fH = class {
        constructor() {
            this.B = this.D = this.j = this.he = null;
            this.i = this.l = 0
        }
        C() {
            return !0
        }
    };

    function gH(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            const b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return b === "__storage_test__"
        } catch (b) {
            return !1
        }
    }

    function hH(a, b = []) {
        const c = Date.now();
        return Wa(b, d => c - d < a * 1E3)
    }

    function iH(a, b, c) {
        try {
            const d = a.getItem(c);
            if (!d) return [];
            let e;
            try {
                e = JSON.parse(d)
            } catch (f) {}
            if (!Array.isArray(e) || $a(e, f => !Number.isInteger(f))) return a.removeItem(c), [];
            e = hH(b, e);
            e.length || a ? .removeItem(c);
            return e
        } catch (d) {
            return null
        }
    }

    function jH(a, b, c) {
        return b <= 0 || a == null || !gH(a) ? null : iH(a, b, c)
    };
    var kH = (a, b, c) => {
        let d = 0;
        try {
            var e = d |= Tn(a);
            const h = Un(a),
                k = a.innerWidth;
            var f = h && k ? h / k : 0;
            d = e | (f ? f > 1.05 ? 262144 : f < .95 ? 524288 : 0 : 131072);
            d |= Vn(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var g;
            if (g = b) g = jH(c, 3600, "__lsv__") ? .length !== 0;
            g && (d |= 134217728)
        } catch (h) {
            d |= 32
        }
        return d
    };
    var lH = class extends fH {
        constructor() {
            super(...arguments);
            this.A = !1;
            this.g = null
        }
        C(a) {
            this.A = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = Zq(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    const mH = {};

    function nH(a, b, c) {
        let d = oH(a, c, b);
        if (!d) return !0;
        const e = c.C.i;
        for (; d.Rb && d.Rb.length;) {
            const f = d.Rb.shift(),
                g = ov(f.ha);
            if (g && !(g <= d.Sc)) c.B ? .g(f, 18);
            else if (pH(c, f, {
                    Bd: d.Sc
                })) {
                if (d.Qc.g.length + 1 >= e) return c.B ? .i(d.Rb, 19), !0;
                d = oH(a, c, b);
                if (!d) return !0
            }
        }
        return c.l
    }
    const oH = (a, b, c) => {
        var d = b.C.i,
            e = b.C.l,
            f = b.C;
        f = sy(b.da(), f.g ? f.g.ec : void 0, d);
        if (f.g.length >= d) return b.B ? .i(qH(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.i || (f.i = Yn(f.j).scrollHeight || null), e = !d || d < 0 ? -1 : f.i * e - yy(f)) : e = void 0;
        const g = (d = e == null || e >= 50) ? qH(b, f, {
            types: a
        }, c) : null;
        d || b.B ? .i(qH(b, f, {
            types: a
        }, c), 18);
        return {
            Qc: f,
            Sc: e,
            Rb: g
        }
    };
    mH[2] = Ka(function(a, b) {
        a = qH(b, sy(b.da()), {
            types: a,
            Cb: Wx(b.da())
        }, 2);
        if (a.length == 0) return !0;
        for (var c = 0; c < a.length; c++)
            if (pH(b, a[c])) return !0;
        return b.l ? (b.A.push(11), !0) : !1
    }, [0]);
    mH[5] = Ka(nH, [0], 5);
    mH[10] = Ka(function(a, b) {
        a = [];
        const c = b.La;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && !U(Ur) && a.push(1);
        return nH(a, 10, b)
    }, 10);
    mH[3] = function(a) {
        if (!a.l) return !1;
        var b = qH(a, sy(a.da()), {
            types: [0],
            Cb: Wx(a.da())
        }, 3);
        if (b.length == 0) return !0;
        for (var c = b.length - 1; c >= 0; c--)
            if (pH(a, b[c])) return !0;
        a.A.push(11);
        return !0
    };
    const rH = a => {
            var b;
            a.j.sh ? b = U(Wr) ? new Rx(0, null, [], 8, .3) : new Rx(0, null, [], 3, null) : b = Wx(a.da());
            return {
                types: [0],
                Cb: b
            }
        },
        tH = a => {
            const b = a.da().document.body.getBoundingClientRect().width;
            sH(a, bH(b))
        },
        vH = (a, b) => {
            var c = rH(a);
            c.Lj = [5];
            c = qH(a, sy(a.da()), c, 8);
            uH(a, c.reverse(), b)
        },
        uH = (a, b, c) => {
            for (const d of b)
                if (b = c.g(d.la), pH(a, d, {
                        ie: b
                    })) return !0;
            return !1
        };
    mH[8] = function(a) {
        var b = a.da().document;
        if (b.readyState != "complete") return b.addEventListener("readystatechange", () => mH[8](a), {
            once: !0
        }), !0;
        if (!a.l) return !1;
        if (!a.vd()) return !0;
        b = rH(a);
        b.mf = [2, 4, 5];
        b = qH(a, sy(a.da()), b, 8);
        const c = new cH;
        if (uH(a, b, c)) return !0;
        if (a.j.kg) switch (a.j.Ug || 0) {
            case 1:
                vH(a, c);
                break;
            default:
                tH(a)
        }
        return !0
    };
    mH[6] = Ka(nH, [2], 6);
    mH[7] = Ka(nH, [1], 7);
    mH[9] = function(a) {
        const b = oH([0, 2], a, 9);
        if (!b || !b.Rb) return a.A.push(17), a.l;
        for (const d of b.Rb) {
            var c = a.j.Me || null;
            c == null ? c = null : (c = pv(d.ha, new wH, new xH(c, a.da())), c = new Fx(c, d.ja(), d.la));
            if (c && !(ov(c.ha) > b.Sc) && pH(a, c, {
                    Bd: b.Sc,
                    xe: !0
                })) return a = c.ha.ca, mv(d.ha, a.length > 0 ? a[0] : null), !0
        }
        a.A.push(17);
        return a.l
    };
    class wH {
        i(a, b, c, d) {
            return xu(d.document, a, b)
        }
        j(a) {
            return P(a) || 0
        }
    };
    var yH = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.Qc = c
        }
        Aa(a) {
            return this.g ? Vy(this.i, this.g, a, this.Qc) : Uy(this.i, a, this.Qc)
        }
        ya() {
            return this.g ? 16 : 9
        }
    };
    var zH = class {
        constructor(a) {
            this.je = a
        }
        Aa(a) {
            return bz(a.document, this.je)
        }
        ya() {
            return 11
        }
    };
    var AH = class {
        constructor(a) {
            this.tb = a
        }
        Aa(a) {
            return Zy(this.tb, a)
        }
        ya() {
            return 13
        }
    };
    var BH = class {
        Aa(a) {
            return Sy(a)
        }
        ya() {
            return 12
        }
    };
    var CH = class {
        constructor(a) {
            this.sc = a
        }
        Aa() {
            return Xy(this.sc)
        }
        ya() {
            return 2
        }
    };
    var DH = class {
        constructor(a) {
            this.g = a
        }
        Aa() {
            return $y(this.g)
        }
        ya() {
            return 3
        }
    };
    var EH = class {
        Aa() {
            return cz()
        }
        ya() {
            return 17
        }
    };
    var FH = class {
        constructor(a) {
            this.g = a
        }
        Aa() {
            return Wy(this.g)
        }
        ya() {
            return 1
        }
    };
    var GH = class {
        Aa() {
            return zb(gv)
        }
        ya() {
            return 7
        }
    };
    var HH = class {
        constructor(a) {
            this.mf = a
        }
        Aa() {
            return Yy(this.mf)
        }
        ya() {
            return 6
        }
    };
    var IH = class {
        constructor(a) {
            this.g = a
        }
        Aa() {
            return az(this.g)
        }
        ya() {
            return 5
        }
    };
    var JH = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        Aa() {
            return Ka(dz, this.minWidth, this.maxWidth)
        }
        ya() {
            return 10
        }
    };
    var KH = class {
        constructor(a) {
            this.l = a.i.slice(0);
            this.i = a.g.slice(0);
            this.j = a.j;
            this.A = a.l;
            this.g = a.A
        }
    };

    function LH(a) {
        var b = new MH;
        b.A = a;
        b.i.push(new FH(a));
        return b
    }

    function NH(a, b) {
        a.i.push(new HH(b));
        return a
    }

    function OH(a, b) {
        a.i.push(new CH(b));
        return a
    }

    function PH(a, b) {
        a.i.push(new IH(b));
        return a
    }

    function QH(a, b) {
        a.i.push(new DH(b));
        return a
    }

    function RH(a) {
        a.i.push(new GH);
        return a
    }

    function SH(a) {
        a.g.push(new BH);
        return a
    }

    function TH(a, b = 0, c, d) {
        a.g.push(new yH(b, c, d));
        return a
    }

    function UH(a, b = 0, c = Infinity) {
        a.g.push(new JH(b, c));
        return a
    }

    function VH(a) {
        a.g.push(new EH);
        return a
    }

    function WH(a, b = 0) {
        a.g.push(new AH(b));
        return a
    }

    function XH(a, b) {
        a.j = b;
        return a
    }
    var MH = class {
        constructor() {
            this.j = 0;
            this.l = !1;
            this.i = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new KH(this)
        }
    };
    class xH {
        constructor(a, b) {
            this.i = a;
            this.j = b
        }
        g() {
            var a = this.i,
                b = this.j;
            const c = a.D || {};
            c.google_ad_client = a.he;
            c.google_ad_height = P(b) || 0;
            c.google_ad_width = Un(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new dH;
            b = Ki(b, 1, a.A);
            a.g && A(b, 2, a.g);
            c.google_rasc = Si(b);
            a.j && (c.google_adtest = "on");
            return new cq(["fsi_container"], c)
        }
    };
    var YH = Wp(new Tp(0, {})),
        ZH = Wp(new Tp(1, {})),
        $H = a => a === YH || a === ZH;

    function aI(a, b, c) {
        jo(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    class bI {
        constructor() {
            this.g = new no
        }
    };

    function cI(a, b) {
        for (var c = 0; c < b.length; c++) a.va(b[c]);
        return a
    }

    function dI(a, b) {
        a.j = a.j ? a.j : b;
        return a
    }
    class eI {
        constructor(a) {
            this.C = {};
            this.C.c = a;
            this.A = [];
            this.j = null;
            this.B = [];
            this.F = 0
        }
        Ub(a) {
            this.C.wpc = a;
            return this
        }
        va(a) {
            for (var b = 0; b < this.A.length; b++)
                if (this.A[b] == a) return this;
            this.A.push(a);
            return this
        }
        l(a) {
            var b = Nb(this.C);
            this.F > 0 && (b.t = this.F);
            b.err = this.A.join();
            b.warn = this.B.join();
            this.j && (b.excp_n = this.j.name, b.excp_m = this.j.message && this.j.message.substring(0, 512), b.excp_s = this.j.stack && Ok(this.j.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };

    function fI(a, b) {
        if (b && (a.g.apv = C(b, 4), Sh(b, xq, 23))) {
            var c = a.g;
            b = x(b, xq, 23);
            b = Yg(Nh(b, 1));
            c.sat = "" + b
        }
        return a
    }

    function gI(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var hI = class extends eI {
        constructor(a) {
            super(a);
            this.g = {}
        }
        H(a) {
            this.g.a = a.join(",");
            return this
        }
        G(a) {
            a != null && (this.g.allp = a);
            return this
        }
        jh(a) {
            if (a) {
                const b = [];
                for (const c of lo(a))
                    if (a.get(c).length > 0) {
                        const d = a.get(c)[0];
                        b.push("(" + [c, d.kb, d.th].join() + ")")
                    }
                this.g.fd = b.join(",")
            }
            return this
        }
        l(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.l(a);
            Pb(a, this.g);
            return a
        }
    };

    function iI(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function jI(a, b, c, d = 30) {
        c.length <= d ? a[b] = kI(c) : (a[b] = kI(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function kI(a) {
        const b = a.length > 0 && typeof a[0] === "string";
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ma(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function lI(a) {
        return a == null ? "null" : typeof a === "string" ? a : typeof a === "boolean" ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function mI(a, b) {
        a.i.op = lI(b)
    }

    function nI(a, b, c) {
        jI(a.i, "fap", b);
        a.i.fad = lI(c)
    }

    function oI(a, b, c) {
        jI(a.i, "fmp", b);
        a.i.fmd = lI(c)
    }

    function pI(a, b, c) {
        jI(a.i, "vap", b);
        a.i.vad = lI(c)
    }

    function qI(a, b, c) {
        jI(a.i, "vmp", b);
        a.i.vmd = lI(c)
    }

    function rI(a, b, c) {
        jI(a.i, "pap", b);
        a.i.pad = lI(c)
    }

    function sI(a, b, c) {
        jI(a.i, "pmp", b);
        a.i.pmd = lI(c)
    }

    function tI(a, b) {
        jI(a.i, "psq", b)
    }
    var uI = class extends hI {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.i = {};
            this.errors = []
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            this.errors.length > 0 && (a.e = kI(this.errors));
            return a
        }
    };

    function vI(a, b, c) {
        const d = b.ha;
        jo(a.g, d) || a.g.set(d, new wI(Jp(Nv(b)) ? ? ""));
        c(a.g.get(d))
    }

    function xI(a, b) {
        vI(a, b, c => {
            c.g = !0
        })
    }

    function yI(a, b) {
        vI(a, b, c => {
            c.i = !0
        })
    }

    function zI(a, b) {
        vI(a, b, c => {
            c.j = !0
        });
        a.I.push(b.ha)
    }

    function AI(a, b, c) {
        vI(a, b, d => {
            d.Mb = c
        })
    }

    function BI(a, b, c) {
        const d = [];
        let e = 0;
        for (const f of c.filter(b)) $H(f.Mb ? ? "") ? ++e : (b = a.i.get(f.Mb ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            Nb: e
        }
    }

    function CI(a, b) {
        mI(b, a.i.wc());
        var c = mo(a.g).filter(f => (f.xb.startsWith(YH) ? 0 : 1) === 0),
            d = mo(a.g).filter(f => (f.xb.startsWith(YH) ? 0 : 1) === 1),
            e = BI(a, f => f.g, c);
        nI(b, e.list, e.Nb);
        e = BI(a, f => f.g, d);
        oI(b, e.list, e.Nb);
        e = BI(a, f => f.i, c);
        pI(b, e.list, e.Nb);
        e = BI(a, f => f.i, d);
        qI(b, e.list, e.Nb);
        c = BI(a, f => f.j, c);
        rI(b, c.list, c.Nb);
        d = BI(a, f => f.j, d);
        sI(b, d.list, d.Nb);
        tI(b, a.I.map(f => a.g.get(f) ? .Mb).map(f => a.i.get(f) ? ? null))
    }

    function El() {
        var a = O(DI);
        if (!a.A) return tl();
        const b = Cl(Bl(Al(zl(yl(xl(wl(vl(sl(rl(new ul, a.A ? ? []), a.H ? ? []), a.B), a.G), a.F), a.O), a.R), a.C ? ? 0), mo(a.g).map(c => {
            var d = new ql;
            d = Qi(d, 1, c.xb);
            var e = a.i.get(c.Mb ? ? "", -1);
            d = Oi(d, 2, e);
            d = L(d, 3, c.g);
            return L(d, 4, c.i)
        })), a.I.map(c => a.g.get(c) ? .Mb).map(c => a.i.get(c) ? ? -1));
        a.j != null && L(b, 6, a.j);
        a.l != null && ei(b, 13, $g(a.l), "0");
        return b
    }
    var DI = class {
        constructor() {
            this.l = this.H = this.A = null;
            this.F = this.G = !1;
            this.j = null;
            this.R = this.B = this.O = !1;
            this.C = null;
            this.i = new no;
            this.g = new no;
            this.I = []
        }
    };
    class wI {
        constructor(a) {
            this.j = this.i = this.g = !1;
            this.Mb = null;
            this.xb = a
        }
    };
    class EI {
        constructor(a) {
            this.i = a;
            this.g = -1
        }
    };

    function FI(a) {
        let b = 0;
        for (; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function GI(a, b) {
        const c = a.H.filter(d => lo(d.cd).every(e => d.cd.get(e) === b.get(e)));
        return c.length === 0 ? (a.i.push(19), null) : c.reduce((d, e) => d.cd.wc() > e.cd.wc() ? d : e, c[0])
    }

    function HI(a, b) {
        b = Nv(b);
        if (b.g == null) return a.i.push(18), null;
        b = b.getValue();
        if (jo(a.j, b)) return a.j.get(b);
        var c = Up(b);
        c = GI(a, c);
        a.j.set(b, c);
        return c
    }
    var II = class {
        constructor(a) {
            this.g = a;
            this.j = new no;
            this.H = (x(a, Xq, 2) ? .g() || []).map(b => {
                const c = Up(K(b, 1)),
                    d = Ci(b, 2);
                return {
                    cd: c,
                    Yg: d,
                    xb: K(b, 1)
                }
            });
            this.i = []
        }
        F() {
            const a = O(DI);
            var b = this.l();
            a.A = b;
            b = this.B();
            a.H = b;
            b = this.A();
            b != null && (a.l = b);
            b = !!this.g.j() ? .g() ? .g();
            a.F = b;
            b = new no;
            for (const c of x(this.g, Xq, 2) ? .g() ? ? []) b.set(K(c, 1), Ci(c, 2));
            a.i = b
        }
        C() {
            return [...this.i]
        }
        l() {
            return [...this.g.g()]
        }
        B() {
            return [...Wh(this.g, 4, Yg, w(), 0)]
        }
        A() {
            return x(this.g, Rq, 5) ? .g() ? ? null
        }
        G(a) {
            const b = HI(this, a);
            b ? .xb != null &&
                AI(O(DI), a, b.xb)
        }
        I(a) {
            const b = V(vs) || 0;
            if (a.length == 0 || b == 0) return !0;
            const c = (new Bp(a)).filter(d => {
                d = HI(this, d) ? .xb || "";
                return d != "" && !(d === YH || d === ZH)
            });
            return b <= c.g.length / a.length
        }
    };

    function JI(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => (HI(a.g, c) ? .Yg ? ? Number.MAX_VALUE) - (HI(a.g, d) ? .Yg ? ? Number.MAX_VALUE))
    }

    function KI(a, b) {
        var c = b.la.g,
            d = Math,
            e = d.min;
        const f = b.ja(),
            g = b.ha.g();
        c += 200 * e.call(d, 20, g == 0 || g == 3 ? FI(f.parentElement) : FI(f));
        a = a.i;
        a.g < 0 && (a.g = Yn(a.i).scrollHeight || 0);
        a = a.g - b.la.g;
        a = c + (a > 1E3 ? 0 : 2 * (1E3 - a));
        b.ja();
        return a
    }

    function LI(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => KI(a, c) - KI(a, d))
    }

    function MI(a, b) {
        return b.sort((c, d) => {
            const e = c.ha.G,
                f = d.ha.G;
            var g;
            e == null || f == null ? g = e == null && f == null ? KI(a, c) - KI(a, d) : e == null ? 1 : -1 : g = e - f;
            return g
        })
    }
    class NI {
        constructor(a, b = null) {
            this.i = new EI(a);
            this.g = b && new II(b)
        }
    };

    function OI(a, b, c = 0, d) {
        var e = a.i;
        for (var f of b.l) e = Ap(e, f.Aa(a.j), PI(f.ya(), c));
        f = e = e.apply(Ry(a.j));
        for (const g of b.i) f = Ap(f, g.Aa(a.j), Qp([QI(g.ya(), c), h => {
            d ? .g(h, g.ya())
        }]));
        switch (b.j) {
            case 1:
                f = LI(a.g, f);
                break;
            case 2:
                f = MI(a.g, f);
                break;
            case 3:
                const g = O(DI);
                f = JI(a.g, f);
                e.forEach(h => {
                    xI(g, h);
                    a.g.g ? .G(h)
                });
                f.forEach(h => yI(g, h))
        }
        b.A && (f = Dp(f, yd(a.j.location.href + a.j.localStorage.google_experiment_mod)));
        b.g ? .length === 1 && aI(a.l, b.g[0], {
            kb: e.g.length,
            th: f.g.length
        });
        return Cp(f)
    }
    class RI {
        constructor(a, b, c = null) {
            this.i = new Bp(a);
            this.g = new NI(b, c);
            this.j = b;
            this.l = new bI
        }
        A() {
            this.i.forEach(a => {
                a.i && gu(a.i);
                a.i = null
            })
        }
    }
    const PI = (a, b) => c => lv(c, b, a),
        QI = (a, b) => c => lv(c.ha, b, a);

    function SI(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = TI(UI(c), a);
                    break a;
                case 3:
                    a = TI(c, a);
                    break a;
                case 2:
                    var e = c.lastChild;
                    a = TI(e ? e.nodeType == 1 ? e : UI(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && b == 2 && !VI(c))) b = b == 1 || b == 2 ? c : c.parentNode,
        d = !(b && !tr(b) && b.offsetWidth <= 0);
        return d
    }

    function TI(a, b) {
        if (!a) return !1;
        a = ve(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function UI(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function VI(a) {
        return !!a.nextSibling || !!a.parentNode && VI(a.parentNode)
    };
    var WI = !Sd && !Ld();

    function XI(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (WI && a.dataset) {
            if (Pd() && !("adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var YI = (a, b, c) => {
            if (!b) return null;
            const d = ae(document, "INS");
            d.id = "google_pedestal_container";
            d.style.width = "100%";
            d.style.zIndex = "-1";
            if (c) {
                var e = a.getComputedStyle(c),
                    f = "";
                if (e && e.position != "static") {
                    var g = c.parentNode.lastElementChild;
                    for (f = e.position; g && g != c;) {
                        if (a.getComputedStyle(g).display != "none") {
                            f = a.getComputedStyle(g).position;
                            break
                        }
                        g = g.previousElementSibling
                    }
                }
                if (c = f) d.style.position = c
            }
            b.appendChild(d);
            if (d) {
                var h = a.document;
                f = h.createElement("div");
                f.style.width = "100%";
                f.style.height =
                    "2000px";
                c = P(a);
                e = h.body.scrollHeight;
                a = a.innerHeight;
                g = h.body.getBoundingClientRect().bottom;
                d.appendChild(f);
                var k = f.getBoundingClientRect().top;
                h = h.body.getBoundingClientRect().top;
                d.removeChild(f);
                f = e;
                e <= a && c > 0 && g > 0 && (f = g - h);
                a = k - h >= .8 * f
            } else a = !1;
            return a ? d : (b.removeChild(d), null)
        },
        ZI = a => {
            const b = a.document.body;
            var c = YI(a, b, null);
            if (c) return c;
            if (a.document.body) {
                c = Math.floor(a.document.body.getBoundingClientRect().width);
                for (var d = [{
                        element: a.document.body,
                        depth: 0,
                        height: 0
                    }], e = -1, f = null; d.length >
                    0;) {
                    const h = d.pop(),
                        k = h.element;
                    var g = h.height;
                    h.depth > 0 && g > e && (e = g, f = k);
                    if (h.depth < 5)
                        for (g = 0; g < k.children.length; g++) {
                            const l = k.children[g],
                                m = l.getBoundingClientRect().width;
                            (m == null || c == null ? 0 : m >= c * .9 && m <= c * 1.01) && d.push({
                                element: l,
                                depth: h.depth + 1,
                                height: l.getBoundingClientRect().height
                            })
                        }
                }
                c = f
            } else c = null;
            return c ? YI(a, c.parentNode || b, c) : null
        },
        aJ = a => {
            let b = 0;
            try {
                b |= Tn(a), ke() || (b |= 1048576), Math.floor(a.document.body.getBoundingClientRect().width) <= 1200 || (b |= 32768), $I(a) && (b |= 33554432)
            } catch (c) {
                b |=
                    32
            }
            return b
        },
        $I = a => {
            a = a.document.getElementsByClassName("adsbygoogle");
            for (let b = 0; b < a.length; b++)
                if (XI(a[b]) == "autorelaxed") return !0;
            return !1
        };

    function bJ(a) {
        const b = Xn(a, !0),
            c = Yn(a).scrollWidth,
            d = Yn(a).scrollHeight;
        let e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = bo(a);
        const g = [];
        var h = [];
        const k = [],
            l = [];
        var m = [],
            n = [],
            p = [];
        let r = 0,
            y = 0,
            D = Infinity,
            E = Infinity,
            G = null;
        var H = oy({
            Kb: !1
        }, a);
        for (var z of H) {
            H = z.getBoundingClientRect();
            const ba = b - (H.bottom + f);
            var I = void 0,
                F = void 0;
            if (z.className && z.className.indexOf("adsbygoogle-ablated-ad-slot") != -1) {
                I = z.getAttribute("google_element_uid");
                F = a.google_sv_map;
                if (!I ||
                    !F || !F[I]) continue;
                I = (F = qk(F[I])) ? F.height : 0;
                F = F ? F.width : 0
            } else if (I = H.bottom - H.top, F = H.right - H.left, I <= 1 || F <= 1) continue;
            g.push(I);
            k.push(F);
            l.push(I * F);
            z.className && z.className.indexOf("google-auto-placed") != -1 ? (y += 1, z.className && z.className.indexOf("pedestal_container") != -1 && (G = I)) : (D = Math.min(D, ba), n.push(H), r += 1, h.push(I), m.push(I * F));
            E = Math.min(E, ba);
            p.push(H)
        }
        D = D === Infinity ? null : D;
        E = E === Infinity ? null : E;
        f = cJ(n);
        p = cJ(p);
        h = dJ(b, h);
        n = dJ(b, g);
        m = dJ(b * c, m);
        z = dJ(b * c, l);
        return new eJ(a, {
            yi: e,
            Ic: b,
            vj: c,
            uj: d,
            jj: r,
            Nh: y,
            Ph: fJ(g),
            Qh: fJ(k),
            Oh: fJ(l),
            pj: f,
            oj: p,
            nj: D,
            mj: E,
            Ee: h,
            De: n,
            Ih: m,
            Hh: z,
            xj: G
        })
    }

    function gJ(a, b, c, d) {
        const e = ke() && !(Un(a.i) >= 900);
        d = Wa(d, f => ab(a.j, f)).join(",");
        return {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.yi,
            pg_h: hJ(a.g.Ic),
            pg_w: hJ(a.g.vj),
            pg_hs: hJ(a.g.uj),
            c: hJ(a.g.jj),
            aa_c: hJ(a.g.Nh),
            av_h: hJ(a.g.Ph),
            av_w: hJ(a.g.Qh),
            av_a: hJ(a.g.Oh),
            s: hJ(a.g.pj),
            all_s: hJ(a.g.oj),
            b: hJ(a.g.nj),
            all_b: hJ(a.g.mj),
            d: hJ(a.g.Ee),
            all_d: hJ(a.g.De),
            ard: hJ(a.g.Ih),
            all_ard: hJ(a.g.Hh),
            pd_h: hJ(a.g.xj),
            dt: e ? "m" : "d"
        }
    }
    class eJ {
        constructor(a, b) {
            this.i = a;
            this.g = b;
            this.j = "633794002 633794005 21066126 21066127 21065713 21065714 21065715 21065716 42530887 42530888 42530889 42530890 42530891 42530892 42530893".split(" ")
        }
    }

    function fJ(a) {
        return nd.apply(null, Wa(a, b => b > 0)) || null
    }

    function dJ(a, b) {
        return a <= 0 ? null : md.apply(null, b) / a
    }

    function cJ(a) {
        let b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                c > 0 && (b = Math.min(c, b))
            }
        return b !== Infinity ? b : null
    }

    function hJ(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function iJ(a) {
        var b = qy({
            Kb: !1,
            qd: !1
        }, a);
        a = (P(a) || 0) - bo(a);
        let c = 0;
        for (let d = 0; d < b.length; d++) {
            const e = b[d].getBoundingClientRect();
            wy(e) && e.top <= a && (c += 1)
        }
        return c > 0
    }

    function jJ(a) {
        const b = {};
        var c = qy({
            Kb: !1,
            qd: !1,
            Se: !1,
            Te: !1
        }, a).map(d => d.getBoundingClientRect()).filter(wy);
        b.Kf = c.length;
        c = ry({
            Se: !0
        }, a).map(d => d.getBoundingClientRect()).filter(wy);
        b.ig = c.length;
        c = ry({
            Te: !0
        }, a).map(d => d.getBoundingClientRect()).filter(wy);
        b.Lg = c.length;
        c = ry({
            qd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(wy);
        b.Pf = c.length;
        c = (P(a) || 0) - bo(a);
        c = qy({
            Kb: !1
        }, a).map(d => d.getBoundingClientRect()).filter(wy).filter(Ja(kJ, null, c));
        b.Lf = c.length;
        a = bJ(a);
        c = a.g.Ee != null ? a.g.Ee : null;
        c !=
            null && (b.Gg = c);
        a = a.g.De != null ? a.g.De : null;
        a != null && (b.Mf = a);
        return b
    }

    function pH(a, b, {
        Bd: c,
        ie: d,
        xe: e
    } = {}) {
        return Pu(997, () => lJ(a, b, {
            Bd: c,
            ie: d,
            xe: e
        }), a.g)
    }

    function qH(a, b, c, d) {
        var e = c.Cb ? c.Cb : a.C;
        const f = Xx(e, b.g.length);
        e = a.j.Nf ? e.g : void 0;
        const g = VH(WH(SH(UH(TH(RH(PH(QH(NH(OH(LH(c.types), a.ia), c.mf || []), a.ca), c.Lj || [])), f.Hc || void 0, e, b), c.minWidth, c.maxWidth)), f.tb || void 0));
        a.R && g.g.push(new zH(a.R));
        b = 1;
        a.j.rh ? b = 2 : a.sb() && (b = 3);
        XH(g, b);
        a.j.kh && (g.l = !0);
        return Pu(995, () => OI(a.i, g.build(), d, a.B || void 0), a.g)
    }

    function sH(a, b) {
        const c = ZI(a.g);
        if (c) {
            const d = bq(a.I, b),
                e = uu(a.g.document, a.G, null, null, {}, d);
            e && (ju(e.nb, c, 2, 256), Pu(996, () => mJ(a, e, d), a.g))
        }
    }

    function nJ(a) {
        return a.F ? a.F : a.F = a.g.google_ama_state
    }

    function lJ(a, b, {
        Bd: c,
        ie: d,
        xe: e
    } = {}) {
        const f = b.ha;
        if (f.A) return !1;
        var g = b.ja(),
            h = f.g();
        if (!SI(a.g, h, g, a.l)) return !1;
        h = null;
        f.Ac ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new cq(null, {
            google_max_responsive_height: c == null ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = c == null ? null : new cq(null, {
            google_max_responsive_height: c
        });
        c = dq(Ai(f.Xd, 2) || 0);
        g = eq(f.G);
        const k = oJ(a, f),
            l = pJ(a),
            m = bq(a.I, f.R ? f.R.g(b.la) : null, h, d || null, c, g, k, l),
            n = b.fill(a.G, m);
        if (e && !qJ(a, n, m) || !Pu(996,
                () => mJ(a, n, m), a.g)) return !1;
        Ij(9, [f.G, f.Lb]);
        a.sb() && zI(O(DI), b);
        return !0
    }

    function oJ(a, b) {
        return Jp(Np(Lv(b).map(fq), () => {
            a.A.push(18)
        }))
    }

    function pJ(a) {
        if (!a.sb()) return null;
        var b = a.i.g.g ? .B();
        if (b == null) return null;
        b = b.join("~");
        a = a.i.g.g ? .A() ? ? null;
        return gq({
            ni: b,
            Hi: a
        })
    }

    function qJ(a, b, c) {
        if (!b) return !1;
        var d = b.ua,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        d = a.g;
        e = b.ua;
        c = c && c.xc() || {};
        var g = V(Ir);
        if (d !== d.top) g = se(d) ? 3 : 16;
        else if (Un(d) < 488)
            if (d.innerHeight >= d.innerWidth) {
                var h = Un(d);
                if (!h || (h - f) / h > g) g = 6;
                else {
                    if (g = c.google_full_width_responsive !== "true") b: {
                        h = e.parentElement;
                        for (g = Un(d); h; h = h.parentElement) {
                            const k = ve(h, d);
                            if (!k) continue;
                            const l = Fe(k.width);
                            if (l && !(l >= g) && k.overflow !== "visible") {
                                g = !0;
                                break b
                            }
                        }
                        g = !1
                    }
                    g = g ? 7 : !0
                }
            } else g = 5;
        else g =
            4;
        if (g !== !0) f = g;
        else {
            if (!(c = c.google_full_width_responsive === "true")) a: {
                do
                    if ((c = ve(e, d)) && c.position == "fixed") {
                        c = !1;
                        break a
                    }
                while (e = e.parentElement);
                c = !0
            }
            c ? (d = Un(d), f = d - f, f = d && f >= 0 ? !0 : d ? f < -10 ? 11 : f < 0 ? 14 : 12 : 10) : f = 9
        }
        if (f) {
            a = a.g;
            b = b.ua;
            if (d = qu(a, b)) f = b.style, f.border = f.borderStyle = f.outline = f.outlineStyle = f.transition = "none", f.borderSpacing = f.padding = "0", ou(b, d, "0px"), f.width = `${Un(a)}px`, ru(a, b, d), f.zIndex = "30";
            return !0
        }
        gu(b.nb);
        return !1
    }

    function mJ(a, b, c) {
        if (!b) return !1;
        try {
            yu(a.g, b.ua, c)
        } catch (d) {
            return gu(b.nb), a.A.push(6), !1
        }
        return !0
    }
    class rJ {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.i = a;
            this.G = b;
            this.g = c;
            this.C = d.Cb;
            this.ia = d.sc || [];
            this.I = d.Ii || null;
            this.ca = d.ti || [];
            this.R = d.je || [];
            this.j = e;
            this.l = !1;
            this.O = [];
            this.A = [];
            this.H = this.F = void 0;
            this.La = f;
            this.B = g ? new aH : null
        }
        Ea() {
            return this.i
        }
        da() {
            return this.g
        }
        va(a) {
            this.O.push(a)
        }
        sb() {
            if ((this.i.g.g ? .l().length ? ? 0) == 0) return !1;
            if ((V(vs) || 0) == 0) return !0;
            if (this.H === void 0) {
                const a = XH(SH(RH(LH([0, 1, 2]))), 1).build(),
                    b = Pu(995, () => OI(this.i, a), this.g);
                this.H = this.i.g.g ? .I(b) || !1
            }
            return this.H
        }
        Xe() {
            return !!this.j.fh
        }
        vd() {
            return !$I(this.g)
        }
        ta() {
            return this.B
        }
    }
    const kJ = (a, b) => b.top <= a;

    function sJ(a, b, c, d, e, f = 0, g = 0) {
        this.Ma = a;
        this.Td = f;
        this.Sd = g;
        this.errors = b;
        this.zb = c;
        this.g = d;
        this.i = e
    };
    var tJ = (a, {
        vd: b = !1,
        Xe: c = !1,
        Pj: d = !1,
        sb: e = !1
    } = {}) => {
        const f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2) && !U(Ur);
            const g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && !U(Ur) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function uJ(a, b, c) {
        a = tJ(a, {
            vd: b.vd(),
            Xe: b.Xe(),
            Pj: !!b.j.Me,
            sb: b.sb()
        });
        return new vJ(a, b, c)
    }

    function wJ(a, b) {
        const c = mH[b];
        return c ? Pu(998, () => c(a.g), a.A) : (a.g.va(12), !0)
    }

    function xJ(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(wJ(a, b))
            })
        })
    }

    function yJ(a) {
        a.g.l = !0;
        return Promise.all(a.i.map(b => xJ(a, b))).then(b => {
            b.includes(!1) && a.g.va(5);
            a.i.splice(0, a.i.length)
        })
    }
    class vJ {
        constructor(a, b, c) {
            this.l = a.slice(0);
            this.i = a.slice(0);
            this.j = cb(this.i, 1);
            this.g = b;
            this.A = c
        }
    };
    const zJ = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function AJ(a) {
        return yJ(a).then(() => {
            var b = a.g.i.i.filter(gv).g.length;
            var c = a.g.O.slice(0);
            var d = a.g;
            d = [...d.A, ...(d.i.g.g ? .C() || [])];
            b = new sJ(b, c, d, a.g.i.i.g.length, a.g.i.l.g, a.g.i.i.filter(gv).filter(hv).g.length, a.g.i.i.filter(hv).g.length);
            return new zJ(b)
        })
    };
    var BJ = a => {
            let b = 0;
            a.forEach(c => b = Math.max(b, c.getBoundingClientRect().width));
            return c => c.getBoundingClientRect().width > b * .5
        },
        CJ = a => {
            const b = P(a) || 0;
            return c => c.getBoundingClientRect().height >= b * .75
        };
    var DJ = (a, b) => {
        b = Gv(b, a);
        const c = b.map(d => d.g);
        b = b.filter(d => {
            d = d.g.getBoundingClientRect();
            return d.width > 0 && d.height > 0
        }).filter(d => BJ(c)(d.g)).filter(d => CJ(a)(d.g));
        b.sort((d, e) => {
            e = e.g;
            return d.g.getBoundingClientRect().top - e.getBoundingClientRect().top
        });
        return b
    };

    function EJ(a) {
        return a.reduce((b, c) => b.g.getBoundingClientRect().bottom < c.g.getBoundingClientRect().bottom ? c : b)
    }

    function FJ(a, b, c, d) {
        let e = !1;
        const f = new IntersectionObserver(g => {
            for (const h of g)
                if (h.isIntersecting) e = !0;
                else {
                    if (g = e) g = a, g = b.getBoundingClientRect().bottom <= P(g.win) / 2;
                    g && (GJ(a.M, {
                        typ: "cee",
                        cet: c
                    }), e = !1)
                }
        }, {
            rootMargin: d
        });
        f.observe(b);
        xo(a, () => {
            f.disconnect()
        })
    }
    var HJ = class extends Q {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.M = c
        }
    };

    function IJ(a, b) {
        GJ(a, {
            typ: "cdr",
            af: b.se,
            ...(b.se > 0 ? {
                vh: b.W,
                ph: b.Ic,
                ah: b.Jh,
                at: b.Lh
            } : {})
        })
    }

    function GJ(a, b) {
        a = { ...b,
            wpc: a.webPropertyCode,
            cor: a.g,
            tim: Math.round(yk() ? ? -1),
            num: a.i++
        };
        hy("ama_vignette", a, 1)
    }
    var JJ = class {
        constructor(a) {
            var b = Xe();
            this.webPropertyCode = a;
            this.g = b;
            this.i = 0
        }
    };
    class KJ {
        g() {
            return new cq([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    class LJ {
        g() {
            return new cq(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function MJ(a) {
        return ur(a.g.document).map(b => {
            const c = new $u(b, 3);
            b = new bv(Au(a.g, b));
            return new fv(c, b, a.i, !1, 0, [], null, a.g, null)
        })
    }
    class NJ {
        constructor(a) {
            var b = new LJ;
            this.g = a;
            this.i = b || null
        }
    };
    const OJ = {
        Bf: "10px",
        ue: "10px"
    };

    function PJ(a) {
        return io(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new fv(new $u(b, 1), new Yu(OJ), a.i, !1, 0, [], null, a.g, null))
    }
    class QJ {
        constructor(a, b) {
            this.g = a;
            this.i = b || null
        }
    };

    function RJ(a, b) {
        const c = [];
        b.forEach((d, e) => {
            c.push(ma(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        jI(a.i, "cnstr", c, 80)
    }
    var SJ = class extends eI {
        constructor() {
            super(-1);
            this.i = {}
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            return a
        }
    };

    function TJ(a, b) {
        return a == null ? b + "ShouldNotBeNull" : a == 0 ? b + "ShouldNotBeZero" : a < -1 ? b + "ShouldNotBeLessMinusOne" : null
    }

    function UJ(a, b, c) {
        const d = TJ(c.nd, "gapsMeasurementWindow") || TJ(c.uc, "gapsPerMeasurementWindow") || TJ(c.Dc, "maxGapsToReport");
        return d != null ? Hp(d) : c.Of || c.uc != -1 || c.Dc != -1 ? Fp(new VJ(a, b, c)) : Hp("ShouldHaveLimits")
    }

    function WJ(a) {
        return nJ(a.j) && nJ(a.j).placed || []
    }

    function XJ(a) {
        return WJ(a).map(b => sp(qp(b.element, a.g)))
    }

    function YJ(a) {
        return WJ(a).map(b => b.index)
    }

    function ZJ(a, b) {
        const c = b.ha;
        return !a.B && c.l && Ai(c.l, 8) != null && Ai(c.l, 8) == 1 ? [] : c.A ? (c.ca || []).map(d => sp(qp(d, a.g))) : [sp(new rp(b.la.g, 0))]
    }

    function $J(a) {
        a.sort((e, f) => e.g - f.g);
        const b = [];
        let c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.i;
            f <= c ? c = Math.max(c, d) : (b.push(new rp(c, f - c)), c = d)
        }
        return b
    }

    function aK(a, b) {
        b = b.map(c => {
            var d = new TG;
            d = Li(d, 1, c.g);
            c = c.getHeight();
            return Li(d, 2, c)
        });
        return VG(UG(new WG, a), b)
    }

    function bK(a) {
        const b = ni(a, TG, 2, w()).map(c => `G${Bi(c,1)}~${c.getHeight()}`);
        return `W${Bi(a,1)}${b.join("")}`
    }

    function cK(a, b) {
        const c = [];
        let d = 0;
        for (const e of lo(b)) {
            const f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.F || f.splice(a.A, f.length);
            !a.C && d + f.length > a.i && f.splice(a.i - d, f.length);
            c.push(aK(e, f));
            d += f.length;
            if (!a.C && d >= a.i) break
        }
        return c
    }

    function dK(a) {
        const b = ni(a, WG, 5, w()).map(c => bK(c));
        return `M${Bi(a,1)}H${Bi(a,2)}C${Bi(a,3)}B${Number(!!J(a,4))}${b.join("")}`
    }

    function eK(a) {
        var b = Gx(Cp(a.j.i.i), a.g),
            c = XJ(a),
            d = new oo(YJ(a));
        for (var e = 0; e < b.length; ++e)
            if (!d.contains(e)) {
                var f = ZJ(a, b[e]);
                c.push(...f)
            }
        c.push(new rp(0, 0));
        c.push(sp(new rp(Yn(a.g).scrollHeight, 0)));
        b = $J(c);
        c = new no;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.G ? 0 : Math.floor(e.g / a.l), jo(c, f) || c.set(f, []), c.get(f).push(e);
        b = cK(a, c);
        c = new XG;
        c = Li(c, 1, a.i);
        c = Li(c, 2, a.l);
        c = Li(c, 3, a.A);
        a = Ki(c, 4, a.B);
        return oi(a, 5, b)
    }

    function fK(a) {
        a = eK(a);
        return dK(a)
    }
    var VJ = class {
        constructor(a, b, c) {
            this.G = c.nd == -1;
            this.l = c.nd;
            this.F = c.uc == -1;
            this.A = c.uc;
            this.C = c.Dc == -1;
            this.i = c.Dc;
            this.B = c.yg;
            this.j = b;
            this.g = a
        }
    };

    function lr(a, b, c) {
        let d = b.Qa;
        b.rb && U(is) && (d = 1, "r" in c && (c.r += "F"));
        d <= 0 || (!b.Va || "pvc" in c || (c.pvc = Ye(a.g)), hy(b.qb, c, d))
    }

    function gK(a, b, c) {
        c = c.l(a.g);
        b.Va && (c.pvc = Ye(a.g));
        0 <= b.Qa && (c.r = b.Qa, lr(a, b, c))
    }
    var hK = class {
        constructor(a) {
            this.g = a
        }
    };
    const iK = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function jK(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        hy("ama", b, .01)
    }

    function kK(a) {
        const b = {};
        xe(iK, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function lK(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function mK(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function nK(a, b) {
        a = Wh(a, 2, Ig, w());
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function oK(a, b) {
        a = mK(lK(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = ze(a),
            d = pK(a);
        return b.find(e => {
            const f = Sh(e, oq, 7) ? Mg(Nh(x(e, oq, 7), 1)) : Mg(Nh(e, 1));
            e = Sh(e, oq, 7) ? Ai(x(e, oq, 7), 2) : 2;
            if (typeof f !== "number") return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function pK(a) {
        const b = {};
        for (;;) {
            b[ze(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function qK(a, b) {
        try {
            b.removeItem("google_ama_config")
        } catch (c) {
            jK(a, {
                lserr: 1
            })
        }
    };

    function rK() {
        var a = new Eq;
        a = Pi(a, 1, "Toggle toolbar expansion");
        a = Pi(a, 2, "Toggle privacy and legal settings display");
        return Pi(a, 3, "Dismiss privacy and legal settings display").i()
    };
    var tK = (a, b, c, d, e, f = null, g = null) => {
            sK(a, new hK(a), b, c, d, e, f, g)
        },
        sK = (a, b, c, d, e, f, g = null, h = null) => {
            if (c)
                if (d) {
                    var k = YB(d, e);
                    try {
                        const l = new uK(a, b, c, d, e, k, f, g, h);
                        Pu(990, () => vK(l), a)
                    } catch (l) {
                        Hj() && Ij(15, [l]), gK(b, er, dI(gI(fI((new hI(0)).Ub(c), d), k).va(1), l)), kF(O(hF), Il(new Ql, bl(1)))
                    }
                } else gK(b, er, (new hI(0)).Ub(c).va(8)), kF(O(hF), Il(new Ql, bl(8)));
            else gK(b, er, (new hI(0)).va(9)), kF(O(hF), Il(new Ql, bl(9)))
        };

    function vK(a) {
        a.G.forEach(b => {
            switch (b) {
                case 0:
                    Pu(991, () => wK(a), a.g);
                    break;
                case 1:
                    Pu(1073, () => {
                        const c = U(os);
                        RB(new XB(a.g, a.B, a.j, a.A, a.i.aa, c))
                    }, a.g);
                    break;
                case 2:
                    xK(a);
                    break;
                case 6:
                    a.runAutoGames();
                    break;
                case 7:
                    Pu(1203, () => {
                        var c = x(a.j, Qq, 34);
                        if (c) {
                            var d = a.g,
                                e = a.A,
                                f = c.i();
                            c = d.location.hostname;
                            var g = x(f, Pq, 1) ? .g() ? ? [];
                            c = new RG(e, c, Ye(q), g);
                            if (g = x(f, Pq, 1))
                                if (f = x(f, Oq, 2)) {
                                    up(d, yG);
                                    const l = new to;
                                    var h = d.innerWidth;
                                    var k = .375 * h;
                                    h = new OC(k, h - k);
                                    k = d.innerWidth;
                                    k = Un(d) >= 900 ? .2 * k : .5 * k;
                                    KG(new MG(d, e,
                                        g, f, new rG(d, h, k, l, new bG(l)), c))
                                } else c.reportError("No messages");
                            else c.reportError("No settings")
                        }
                    }, a.g)
            }
        })
    }

    function wK(a) {
        var b = U(Wr) ? void 0 : a.i.Bj;
        let c = null;
        c = U(Wr) ? Wx(a.g) : Ux(a.g, b);
        if (a.i.aa && Sh(a.i.aa, nq, 10)) {
            var d = Vh(a.i.aa.g(), 1);
            d !== null && d !== void 0 && (c = Lx(a.g, d, b));
            U(ms) && a.i.aa.g() ? .g() === 2 && (c = Tx(a.i.aa.g(), c))
        }
        Sh(a.j, kq, 26) && (c = Yx(c, x(a.j, kq, 26), a.g));
        c = $x(c, a.g);
        b = a.i.aa ? Wh(a.i.aa, 6, Ig, w($f)) : [];
        d = a.i.aa ? ni(a.i.aa, tq, 5, w($f)) : [];
        const e = a.i.aa ? Wh(a.i.aa, 2, Ig, w($f)) : [],
            f = Pu(993, () => {
                var g = a.j,
                    h = ni(g, Mq, 1, w($f)),
                    k = a.i.aa && nK(a.i.aa, 1);
                k = U(rs) ? "" : k ? "text_image" : "text";
                var l = new KJ,
                    m = ev(h, a.g, {
                        Rh: l,
                        Yi: new cv(k)
                    });
                h.length != m.length && a.H.push(13);
                m = m.concat(PJ(new QJ(a.g, l)));
                h = U(js);
                l = x(g, Yq, 24) ? .j() ? .g() ? .g() || !1;
                if (h || l) h = MJ(new NJ(a.g)), l = O(DI), m = m.concat(h), l.O = !0, l.C = h.length, a.F === "n" && (a.F = x(g, Yq, 24) ? .g() ? .length ? "o" : "p");
                h = U(ms) && a.i.aa.g() ? .g() === 2 && a.i.aa.g() ? .j();
                h = U(Rr) || h;
                a: {
                    if (l = x(g, Iq, 6))
                        for (n of l.g())
                            if (Sh(n, Sp, 4)) {
                                var n = !0;
                                break a
                            }
                    n = !1
                }
                h && n ? (n = m.concat, h = a.g, (l = x(g, Iq, 6)) ? (h = Iv(l.g($f), h), k = SG(g, k, h)) : k = [], k = n.call(m, k)) : (n = m.concat, h = a.g, (l = x(g, Iq, 6)) ? (h = Hv(l.g($f),
                    h), k = SG(g, k, h)) : k = [], k = n.call(m, k));
                m = k;
                g = x(g, Yq, 24);
                return new RI(m, a.g, g)
            }, a.g);
        a.l = new rJ(f, a.A, a.g, {
            Cb: c,
            Ii: a.O,
            sc: a.i.sc,
            ti: b,
            je: d
        }, yK(a), e, U(is));
        nJ(a.l) ? .optimization ? .ablatingThisPageview && !a.l.sb() && (zu(a.g), O(DI).B = !0, a.F = "f");
        a.C = uJ(e, a.l, a.g);
        Pu(992, () => AJ(a.C), a.g).then(Pu(994, () => a.ia.bind(a), a.g), a.ca.bind(a));
        zK(a)
    }

    function xK(a) {
        const b = x(a.j, Nq, 18);
        b && qF(new rF(a.g, new $F(a.g, a.A), b, new kA(a.g), ni(a.j, Mq, 1, w($f))))
    }

    function yK(a) {
        const b = U(ls);
        if (!a.j.g()) return {
            kh: b,
            rh: !1,
            ui: !1,
            sh: !1,
            kg: !1,
            fh: !1,
            yj: 0,
            Ug: 0,
            Nf: AK(a),
            Me: a.I
        };
        const c = a.j.g();
        return {
            kh: b || J(c, 14, !1),
            rh: J(c, 2, !1),
            ui: J(c, 3, !1),
            sh: J(c, 4, !1),
            kg: J(c, 5, !1),
            fh: J(c, 6, !1),
            yj: Di(c, 8, 0),
            Ug: Ai(c, 10),
            Nf: AK(a),
            Me: a.I
        }
    }

    function zK(a) {
        if (U(Pt)) {
            var b = new JJ(a.A);
            const e = x(a.j, Iq, 6) ? .g($f),
                f = e ? .length > 0;
            var c = b,
                d = !!cA(a.g).reactiveTypeEnabledInAsfe[8];
            GJ(c, {
                typ: "pv",
                asp: Number(f),
                ve: Number(d)
            });
            f && (a = new HJ(a.g, e, b), b = DJ(a.win, a.g), b.length === 0 ? IJ(a.M, {
                se: 0
            }) : (c = EJ(b), d = c.g.getBoundingClientRect(), IJ(a.M, {
                se: b.length,
                W: P(a.win),
                Ic: Yn(a.win).scrollHeight,
                Jh: d.height,
                Lh: a.win.scrollY + d.top
            }), c = c.g, FJ(a, c, 0, "-50% 0px 0px 0px"), FJ(a, c, 1, "0px 0px 0px 0px")))
        }
    }

    function AK(a) {
        return U(cs) || U(ms) && a.i.aa ? .g() ? .g() === 2 ? !1 : a.i.aa && Sh(a.i.aa, nq, 10) ? (Vh(a.i.aa.g(), 1) || 0) >= .5 : !0
    }

    function BK(a, b) {
        for (var c = cI(cI(new hI(b.Ma), b.errors), a.H), d = b.zb, e = 0; e < d.length; e++) a: {
            for (var f = c, g = d[e], h = 0; h < f.B.length; h++)
                if (f.B[h] == g) break a;f.B.push(g)
        }
        c.g.pp = b.Sd;
        c.g.ppp = b.Td;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.kc;
        c.g.eatfAbg = b.lc;
        c.g.reatf = b.Jb;
        c = gI(fI(c.H(a.C.l.slice(0)), a.j), a.G).Ub(a.A);
        if (d = b.Fa) c.g.as_count = d.Kf, c.g.d_count = d.ig, c.g.ng_count = d.Lg, c.g.am_count = d.Pf, c.g.atf_count = d.Lf, c.g.mdns = iI(d.Gg), c.g.alldns = iI(d.Mf);
        c = c.G(b.Qb).jh(b.ld);
        d = b.Ic;
        d != null && (c.g.pgh = d);
        c.g.abl = b.tg;
        c.g.rr = a.F;
        b.exception !== void 0 && dI(c, b.exception).va(1);
        return c
    }

    function CK(a, b) {
        var c = BK(a, b);
        gK(a.B, b.errors.length > 0 || a.H.length > 0 || b.exception !== void 0 ? er : dr, c);
        if (x(a.j, Yq, 24)) {
            a.l.i.g.g ? .F();
            b = nJ(a.l);
            const d = O(DI);
            d.j = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.G = !0);
            d.R = !!b ? .optimization ? .availableAbg;
            b = O(DI);
            c = new uI(c);
            b.A ? (c.i.sl = kI(b.A ? ? []), c.i.daaos = kI(b.H ? ? []), c.i.ab = lI(b.G), c.i.rr = lI(b.O), c.i.oab = lI(b.F), b.j != null && (c.i.sab = lI(b.j)), b.B && (c.i.fb = lI(b.B)), c.i.ls = lI(b.R), mI(c, b.i.wc()), b.C != null && (c.i.rp = lI(b.C)),
                b.l != null && (c.i.expl = lI(b.l)), CI(b, c)) : c.errors.push("irr");
            gK(a.B, gr, c)
        }
        c = a.l ? .ta();
        U(is) && c != null && (c = new Map([...c.j.map.entries()].map(jG)), b = new SJ, RJ(b, c), gK(a.B, jr, b))
    }

    function DK(a, b) {
        const c = O(hF);
        if (c.i) {
            var d = new Ql,
                e = b.zb.filter(g => g !== null),
                f = a.H.concat(b.errors, b.exception ? [1] : []).filter(g => g !== null);
            Ml(Kl(Pl(Ol(Nl(Ll(Fl(Hl(Jl(Gl(d, a.C.l.slice(0).map(g => {
                var h = new al;
                return Qh(h, 1, Hg(g))
            })), e.map(g => {
                var h = new dl;
                return Qh(h, 1, Hg(g))
            })), f.map(g => bl(g))), x(a.j, xq, 23) ? .g()), b.Ma).G(b.Qb), b.Jb), b.kc), b.lc), a.G.map(g => g.toString())), kl(jl(il(hl(gl(fl(el(new ll, b.Fa ? .Kf), b.Fa ? .ig), b.Fa ? .Lg), b.Fa ? .Pf), b.Fa ? .Lf), b.Fa ? .Gg), b.Fa ? .Mf));
            if (b.ld)
                for (let g of lo(b.ld)) {
                    e =
                        new ci;
                    for (let h of b.ld.get(g)) pl(e, nl(ml(new ol, h.kb), h.th));
                    bi(d).set(g.toString(), e)
                }
            x(a.j, Yq, 24) && Dl(d);
            kF(c, d)
        }
    }

    function EK(a, b) {
        try {
            U(Tr) && a.l ? .Ea() ? .A()
        } catch (c) {
            gK(a.B, ir, dI(gI(fI((new hI(b)).Ub(a.A), a.j), a.G).va(14), c))
        }
    }

    function FK(a, b, c) {
        {
            var d = nJ(a.l),
                e = b.g;
            const f = e.g,
                g = e.Sd;
            let h = e.Ma,
                k = e.Td,
                l = e.errors.slice(),
                m = e.zb.slice(),
                n = b.exception;
            const p = VE(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.C.j && m.push(13), d.exception !== void 0 && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                Ma: h,
                Sd: g,
                Td: k,
                Qb: f,
                errors: e.errors.slice(),
                zb: m,
                exception: n,
                Jb: c,
                kc: !!d.eatf,
                lc: !!d.eatfAbg,
                tg: p
            }) : (m.push(12), a.C.j && m.push(13), c = {
                Ma: h,
                Sd: g,
                Td: k,
                Qb: f,
                errors: l,
                zb: m,
                exception: n,
                Jb: c,
                kc: !1,
                lc: !1,
                tg: p
            })
        }
        c.Fa = jJ(a.l.g);
        if (b = b.g.i) c.ld = b;
        c.Ic = Yn(a.g).scrollHeight;
        if (Hj() || x(a.j, wq, 25) ? .j()) {
            d = Cp(a.l.i.i);
            b = [];
            for (const f of d) {
                d = {};
                e = f.I;
                for (const g of lo(e)) d[g] = e.get(g);
                d = {
                    anchorElement: iv(f),
                    position: f.g(),
                    clearBoth: f.H,
                    locationType: f.Lb,
                    placed: f.A,
                    placementProto: f.l ? Ti(f.l) : null,
                    articleStructure: f.B ? Ti(f.B) : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            Ij(14, [{
                placementIdentifiers: b
            }, a.l.G, c.Fa])
        }
        return c
    }

    function GK(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.Qb;
        c.numAutoAdsPlaced = b.Ma;
        c.hasAtfAd = b.Jb;
        b.exception !== void 0 && (c.exception = b.exception);
        a.l != null && (a = UJ(a.g, a.l, {
            nd: -1,
            uc: -1,
            Dc: -1,
            yg: !0,
            Of: !0
        }), a.g != null ? (c.placementPositionDiffs = fK(a.getValue()), b = eK(a.getValue()), a = new YG, a = B(a, 2, ZG, b), c.placementPositionDiffsReport = Si(a)) : (b = a.i.message, c.placementPositionDiffs = "E" + b, a = new YG, a = hi(a, 1, ZG, bh(b)), c.placementPositionDiffsReport = Si(a)))
    }

    function HK(a, b) {
        CK(a, {
            Ma: 0,
            Qb: void 0,
            errors: [],
            zb: [],
            exception: b,
            Jb: void 0,
            kc: void 0,
            lc: void 0,
            Fa: void 0
        });
        DK(a, {
            Ma: 0,
            Qb: void 0,
            errors: [],
            zb: [],
            exception: b,
            Jb: void 0,
            kc: void 0,
            lc: void 0,
            Fa: void 0
        })
    }
    class uK {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.g = a;
            this.B = b;
            this.A = c;
            this.j = d;
            this.i = e;
            this.G = f;
            this.O = h || null;
            this.H = [];
            this.I = k;
            this.R = g;
            this.F = "n"
        }
        runAutoGames() {
            const a = x(this.j, yq, 32);
            a && this.R.runAutoGames({
                win: this.g,
                webPropertyCode: this.A,
                Uf: a,
                Hb: (x(this.j, Fq, 33) ? .g() ? .i() ? ? null) || rK()
            })
        }
        ia(a) {
            try {
                EK(this, a.g.Ma);
                const b = iJ(this.l.g) || void 0;
                cr({
                    He: b
                }, this.g);
                const c = FK(this, a, iJ(this.l.g));
                Sh(this.j, wq, 25) && yi(x(this.j, wq, 25), 1) && GK(this, c);
                CK(this, c);
                DK(this, c);
                gy(753, () => {
                    if (U(Xr) && this.l !=
                        null) {
                        var d = UJ(this.g, this.l, {
                                nd: V(hs),
                                uc: V(gs),
                                Dc: V(Zr),
                                yg: !0,
                                Of: !1
                            }),
                            e = Nb(c);
                        d.g != null ? (d = fK(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" + d.i.message;
                        e = BK(this, e);
                        gK(this.B, fr, e)
                    }
                })()
            } catch (b) {
                HK(this, b)
            }
        }
        ca(a) {
            EK(this, 0);
            HK(this, a)
        }
    };
    var IK = class extends N {},
        JK = Vi(IK);

    function KK(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? Ip(() => JK(c)) : Fp(null)
    };

    function LK(a, b) {
        return Ki(a, 5, b)
    }
    var MK = class extends N {
        constructor() {
            super()
        }
        l() {
            return C(this, 1) != null
        }
        j() {
            return C(this, 2) != null
        }
        A() {
            return J(this, 3)
        }
        B() {
            return yi(this, 3) != null
        }
        g() {
            return J(this, 5)
        }
    };
    var PK = ({
        win: a,
        Ka: b,
        wg: c = !1,
        xg: d = !1
    }) => NK({
        win: a,
        Ka: b,
        wg: c,
        xg: d
    }) ? (b = LE(GE(), 24)) ? OK(a, LK(new MK, PF(b))) : new Gp(null, Error("tcunav")) : OK(a, LK(new MK, !0));

    function NK({
        win: a,
        Ka: b,
        wg: c,
        xg: d
    }) {
        if (!(d = !d && UF(new YF(a)))) {
            if (c = !c) {
                if (b) {
                    a = KK(a);
                    if (a.g != null)
                        if ((a = a.getValue()) && Ai(a, 1) != null) b: switch (a = Ai(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else W.ba(806, a.i, void 0, void 0), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function OK(a, b) {
        return (a = xj(b, a)) ? Fp(a) : new Gp(null, Error("unav"))
    };
    var QK = class extends N {};
    class RK {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.l = b;
            this.B = c;
            this.i = !1;
            this.j = d;
            this.A = e
        }
    };
    class SK {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function TK() {
        const {
            promise: a,
            resolve: b
        } = new SK;
        return {
            promise: a,
            resolve: b
        }
    };

    function UK(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = TK();
        b[a] = d;
        c();
        return d
    }

    function VK(a, b, c) {
        return UK(a, b, () => {
            te(b.document, c)
        }).promise
    };
    var WK = class {
        constructor(a) {
            this.jb = a
        }
        runAutoGames({
            win: a,
            webPropertyCode: b,
            Uf: c,
            Hb: d
        }) {
            iy(1116, VK(12, a, this.jb).then(e => {
                e.runAutoGames({
                    win: a,
                    webPropertyCode: b,
                    serializedAutoGamesConfig: Si(c),
                    serializedFloatingToolbarMessages: Si(d)
                })
            }))
        }
    };
    var XK = {
            al: "google_ads_preview",
            Hl: "google_mc_lab",
            Xl: "google_anchor_debug",
            Wl: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            tm: "google_scr_debug",
            vm: "google_ia_debug_allow_onclick",
            Sm: "googleads",
            Dh: "google_pedestal_debug",
            nn: "google_responsive_slot_preview",
            mn: "google_responsive_dummy_ad",
            Sk: "google_audio_sense",
            Vk: "google_auto_gallery",
            Xk: "google_auto_storify_swipeable",
            Wk: "google_auto_storify_scrollable",
            Uk: "google_games_single_game",
            Tk: "google_games_catalog"
        },
        YK = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var ZK = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function $K(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        b = aL(b);
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function aL(a) {
        let b = "";
        xe(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    }

    function bL() {
        var a = q.location;
        let b = !1;
        xe(XK, c => {
            $K(a, c) && (b = !0)
        });
        return b
    }

    function cL(a, b) {
        switch (a) {
            case 1:
                return $K(b, "google_ia_debug");
            case 2:
                return $K(b, "google_bottom_anchor_debug");
            case 3:
                return $K(b, "google_anchor_debug") || $K(b, "googleads")
        }
    };

    function dL({
        win: a,
        webPropertyCode: b,
        jb: c
    }) {
        $K(a.location, "google_games_single_game") ? eL(a, b, 1, c) : $K(a.location, "google_games_catalog") && eL(a, b, 2, c)
    }

    function eL(a, b, c, d) {
        var e = new yq;
        c = Qh(e, 1, Hg(c));
        (new WK(d)).runAutoGames({
            win: a,
            webPropertyCode: b,
            Uf: c,
            Hb: rK()
        })
    };
    var fL = class extends N {
        constructor() {
            super()
        }
        Oi() {
            return Ei(this, 3)
        }
    };
    const gL = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var hL = class extends N {
        constructor() {
            super()
        }
        getVersion() {
            return Bi(this, 2)
        }
    };

    function iL(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function jL(a) {
        return kf(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function kL(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function lL(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function mL(a, b) {
        a = jL(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function nL(a) {
        var b = jL(a),
            c = kL(b.slice(0, 6));
        a = kL(b.slice(6, 12));
        var d = new hL;
        c = Mi(d, 1, c);
        a = Mi(c, 2, a);
        b = b.slice(12);
        c = kL(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = kL(e[0]) === 0;
            e = e.slice(1);
            var g = oL(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = lL(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = oL(e, b);
                g = lL(f);
                for (let l = 0; l <= g; l++) d.push(h + l);
                e = e.slice(f.length)
            }
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return di(a, 3, d, Jg)
    }

    function oL(a, b) {
        const c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var pL = class extends N {
        constructor() {
            super()
        }
    };
    var qL = class extends N {
        constructor() {
            super()
        }
    };
    var rL = class extends N {
        getVersion() {
            return Bi(this, 1)
        }
    };
    var sL = class extends N {
        constructor() {
            super()
        }
    };

    function tL(a) {
        var b = new uL;
        return A(b, 1, a)
    }
    var uL = class extends N {
        constructor() {
            super()
        }
    };
    const vL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        wL = 6 + vL.reduce((a, b) => a + b);
    var xL = class extends N {
        constructor() {
            super()
        }
    };
    var yL = class extends N {
        getVersion() {
            return Bi(this, 1)
        }
    };
    var zL = class extends N {
        constructor() {
            super()
        }
    };

    function AL(a) {
        var b = new BL;
        return A(b, 1, a)
    }
    var BL = class extends N {
        constructor() {
            super()
        }
    };
    const CL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        DL = 6 + CL.reduce((a, b) => a + b);
    var EL = class extends N {
        constructor() {
            super()
        }
    };
    var FL = class extends N {
        constructor() {
            super()
        }
    };
    var GL = class extends N {
        getVersion() {
            return Bi(this, 1)
        }
    };
    var HL = class extends N {
        constructor() {
            super()
        }
    };

    function IL(a) {
        var b = new JL;
        return A(b, 1, a)
    }
    var JL = class extends N {
        constructor() {
            super()
        }
    };
    const KL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        LL = 6 + KL.reduce((a, b) => a + b);
    var ML = class extends N {
        constructor() {
            super()
        }
    };
    var NL = class extends N {
        constructor() {
            super()
        }
    };
    var OL = class extends N {
        getVersion() {
            return Bi(this, 1)
        }
    };
    var PL = class extends N {
        constructor() {
            super()
        }
    };

    function QL(a) {
        var b = new RL;
        return A(b, 1, a)
    }
    var RL = class extends N {
        constructor() {
            super()
        }
    };
    const SL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        TL = 6 + SL.reduce((a, b) => a + b);
    var UL = class extends N {
        constructor() {
            super()
        }
    };
    var VL = class extends N {
        constructor() {
            super()
        }
        getVersion() {
            return Bi(this, 1)
        }
    };
    const WL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        XL = 6 + WL.reduce((a, b) => a + b);

    function YL() {
        var a = new ZL;
        return Oi(a, 1, 0)
    }

    function $L(a) {
        var b = Number; {
            var c = Nh(a, 1);
            const d = typeof c;
            c = c == null ? c : d === "bigint" ? String(BigInt.asIntN(64, c)) : Fg(c) ? d === "string" ? Og(c) : Pg(c) : void 0
        }
        b = b(c ? ? "0");
        a = Bi(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var ZL = class extends N {};
    var aM = "a".charCodeAt(),
        bM = Mb(Ln),
        cM = Mb(Mn);

    function dM(a, b) {
        if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function eM(a) {
        let b = dM(a, 12);
        const c = [];
        for (; b--;) {
            var d = !!dM(a, 1) === !0,
                e = dM(a, 16);
            if (d)
                for (d = dM(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function fM(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (dM(a, 1)) {
                const f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function gM(a) {
        const b = dM(a, 16);
        return !!dM(a, 1) === !0 ? (a = eM(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : fM(a, b)
    }
    class hM {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var jM = a => {
        try {
            var b = kf(a.split(".")[0]).map(d => d.toString(2).padStart(8, "0")).join("");
            const c = new hM(b);
            b = {};
            b.tcString = a;
            b.gdprApplies = !0;
            c.skip(78);
            b.cmpId = dM(c, 12);
            b.cmpVersion = dM(c, 12);
            c.skip(30);
            b.tcfPolicyVersion = dM(c, 6);
            b.isServiceSpecific = !!dM(c, 1);
            b.useNonStandardStacks = !!dM(c, 1);
            b.specialFeatureOptins = iM(fM(c, 12, cM), cM);
            b.purpose = {
                consents: iM(fM(c, 24, bM), bM),
                legitimateInterests: iM(fM(c, 24, bM), bM)
            };
            b.purposeOneTreatment = !!dM(c, 1);
            b.publisherCC = String.fromCharCode(aM + dM(c, 6)) + String.fromCharCode(aM +
                dM(c, 6));
            b.vendor = {
                consents: iM(gM(c), null),
                legitimateInterests: iM(gM(c), null)
            };
            return b
        } catch (c) {
            return null
        }
    };
    const iM = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var kM = class extends N {
        g() {
            return C(this, 2) != null
        }
    };
    var lM = class extends N {
        l() {
            return C(this, 2) != null
        }
    };
    var mM = class extends N {
        j() {
            return C(this, 1) != null
        }
    };
    var nM = Vi(class extends N {});

    function oM(a) {
        a = pM(a);
        try {
            var b = a ? nM(a) : null
        } catch (c) {
            b = null
        }
        return b ? x(b, mM, 4) || null : null
    }

    function pM(a) {
        a = (new vj(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function qM(a) {
        a.__tcfapiPostMessageReady || rM(new sM(a))
    }

    function rM(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.win.__tcfapi)(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.win.addEventListener("message", a.g);
        a.win.__tcfapiPostMessageReady = !0
    }
    var sM = class {
        constructor(a) {
            this.win = a
        }
    };

    function tM(a) {
        a.__uspapiPostMessageReady || uM(new vM(a))
    }

    function uM(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.win.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.win.addEventListener("message", a.g);
        a.win.__uspapiPostMessageReady = !0
    }
    var vM = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
    };
    var wM = class extends N {};
    var xM = Vi(class extends N {
        g() {
            return C(this, 1) != null
        }
    });

    function yM(a, b, c) {
        function d(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 4));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function e(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function f(n) {
            if (n.length < 12) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(8, 12));
            n = l(n);
            return "1" + p + n + "N"
        }

        function g(n) {
            if (n.length < 18) return null;
            var p = h(n.slice(0, 8));
            p = k(p);
            n = h(n.slice(12, 18));
            n = l(n);
            return "1" + p + n + "N"
        }

        function h(n) {
            const p = [];
            let r = 0;
            for (let y = 0; y < n.length / 2; y++) p.push(kL(n.slice(r, r + 2))), r += 2;
            return p
        }

        function k(n) {
            return n.every(p => p === 1) ? "Y" : "N"
        }

        function l(n) {
            return n.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = jL(a[0]);
        const m = kL(a.slice(0, 6));
        a = a.slice(6);
        if (m !== 1) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return f(a);
            case 7:
                return c ? g(a) : null;
            default:
                return null
        }
    };

    function zM(a) {
        var b = U(Cr);
        a !== a.top || a.__uspapi || a.frames.__uspapiLocator || (a = new AM(a, b), BM(a), CM(a))
    }

    function BM(a) {
        !a.i || a.win.__uspapi || a.win.frames.__uspapiLocator || (a.win.__uspapiManager = "fc", AF(a.win, "__uspapiLocator"), La("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && d({
                version: 1,
                uspString: a.i
            }, !0)
        }, a.win), tM(a.win))
    }

    function CM(a) {
        !a.tcString || a.win.__tcfapi || a.win.frames.__tcfapiLocator || (a.win.__tcfapiManager = "fc", AF(a.win, "__tcfapiLocator"), a.win.__tcfapiEventListeners = a.win.__tcfapiEventListeners || [], La("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.2 || c <= 1)) d(null, !1);
                else switch (c = a.win.__tcfapiEventListeners, b) {
                    case "ping":
                        d({
                            gdprApplies: !0,
                            cmpLoaded: !0,
                            cmpStatus: "loaded",
                            displayStatus: "disabled",
                            apiVersion: "2.2",
                            cmpVersion: 2,
                            cmpId: 300
                        });
                        break;
                    case "addEventListener":
                        b = c.push(d) - 1;
                        a.tcString ?
                            (e = jM(a.tcString), e.addtlConsent = a.g != null ? a.g : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                        d(b, !0);
                        break;
                    case "removeEventListener":
                        e !== void 0 && c[e] ? (c[e] = null, d(!0)) : d(!1);
                        break;
                    case "getInAppTCData":
                    case "getVendorList":
                        d(null, !1);
                        break;
                    case "getTCData":
                        d(null, !1)
                }
        }, a.win), qM(a.win))
    }

    function DM(a, b) {
        if (!b ? .g() || K(b, 1).length === 0 || ni(b, wM, 2, w()).length === 0) return null;
        const c = K(b, 1);
        let d;
        try {
            var e = nL(c.split("~")[0]);
            d = iL(c)
        } catch (f) {
            return null
        }
        b = ni(b, wM, 2, w()).reduce((f, g) => Ci(EM(f), 1) > Ci(EM(g), 1) ? f : g);
        e = Wh(e, 3, Kg, w()).indexOf(Bi(b, 1));
        return e === -1 || e >= d.length ? null : {
            uspString: yM(d[e], Bi(b, 1), a.j),
            Ce: $L(EM(b))
        }
    }

    function FM(a) {
        a = a.find(b => b && Ei(b, 1) === 13);
        if (a ? .g()) try {
            return xM(K(a, 2))
        } catch (b) {}
        return null
    }

    function EM(a) {
        return Sh(a, ZL, 2) ? x(a, ZL, 2) : YL()
    }
    var AM = class {
        constructor(a, b) {
            this.win = a;
            this.j = b;
            b = pM(this.win.document);
            try {
                var c = b ? nM(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = x(b, lM, 5) || null, b = ni(b, kM, 7, w()), b = FM(b ? ? []), c = {
                Zf: c,
                sg: b
            }) : c = {
                Zf: null,
                sg: null
            };
            b = c;
            c = DM(this, b.sg);
            b = b.Zf;
            if (b ? .l() && K(b, 2).length !== 0) {
                var d = Sh(b, ZL, 1) ? x(b, ZL, 1) : YL();
                b = {
                    uspString: K(b, 2),
                    Ce: $L(d)
                }
            } else b = null;
            this.i = b && c ? c.Ce > b.Ce ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.tcString = (c = oM(a.document)) && c.j() ? K(c, 1) : null;
            this.g = (a = oM(a.document)) && C(a, 2) != null ?
                K(a, 2) : null
        }
    };

    function GM() {
        const a = Dd();
        return a ? $a("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), b => $b(a, b)) || $b(a, "OMI/") && !$b(a, "XiaoMi/") ? !0 : $b(a, "Presto") && $b(a, "Linux") && !$b(a, "X11") && !$b(a, "Android") && !$b(a, "Mobi") : !1
    };

    function HM(a) {
        const b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return (b <= .03928 ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) * .2126 + (c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) * .7152 + (a <= .03928 ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4)) * .0722
    }
    var IM = (a, b) => {
        a = HM(a);
        b = HM(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    var JM = (a, b, c, d = null) => {
            const e = g => {
                let h;
                try {
                    h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            Hb(a, "message", e);
            let f = !1;
            return () => {
                let g = !1;
                f || (f = !0, g = Ib(a, "message", e));
                return g
            }
        },
        KM = (a, b, c, d = null) => {
            const e = JM(a, b, yb(c, () => e()), d);
            return e
        },
        LM = (a, b, c, d, e) => {
            if (!(e <= 0) && (c.googMsgType = b, a.postMessage(JSON.stringify(c), d), a = a.frames))
                for (let f = 0; f < a.length; ++f) e > 1 && LM(a[f], b, c, d, --e)
        };

    function MM(a, b, c, d) {
        return JM(a, "fullscreen", d.Ca(952, (e, f) => {
            if (f.source === b) {
                if (!("eventType" in e)) throw Error(`bad message ${JSON.stringify(e)}`);
                delete e.googMsgType;
                c(e)
            }
        }))
    };
    async function NM(a) {
        return a.A.promise
    }
    async function OM(a) {
        return a.j.promise
    }
    async function PM(a) {
        return a.l.promise
    }

    function QM(a, b) {
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = .25;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.C.Uj;
        b.version = a.C.version;
        Pk(a.Z, "fullscreen_tag", b, !1, .25)
    }
    class RM extends Q {
        constructor(a, b, c) {
            var d = W,
                e = dy,
                f = {
                    Uj: 2,
                    version: CE()
                };
            super();
            this.slotType = a;
            this.pubWin = b;
            this.Be = c;
            this.Ia = d;
            this.Z = e;
            this.C = f;
            this.g = 1;
            this.qem = null;
            this.A = new SK;
            this.j = new SK;
            this.l = new SK
        }
        J() {
            const a = MM(this.pubWin, this.Be, b => {
                if (b.eventType === "adError") this.l.resolve(), this.g = 4;
                else if (b.eventType === "adReady" && this.g === 1) this.qem = b.qem, b.slotType !== this.slotType && (QM(this, {
                    cur_st: this.g,
                    evt: b.eventType,
                    adp_tp: b.slotType
                }), this.g = 4), this.A.resolve(), this.g = 2;
                else if (b.eventType ===
                    "adClosed" && this.g === 2) this.j.resolve(b.result), this.g = 3;
                else if (b.eventType !== "adClosed" || this.g !== 3) QM(this, {
                    cur_st: this.g,
                    evt: b.eventType
                }), this.g = 4
            }, this.Ia);
            xo(this, a)
        }
    };
    var SM = Promise;
    class TM {
        constructor(a) {
            this.j = a
        }
        i(a, b, c) {
            this.j.then(d => {
                d.i(a, b, c)
            })
        }
        g(a, b) {
            return this.j.then(c => c.g(a, b))
        }
    };
    class UM {
        constructor(a) {
            this.data = a
        }
    };

    function VM(a, b) {
        WM(a, b);
        return new XM(a)
    }
    class XM {
        constructor(a) {
            this.j = a
        }
        i(a, b, c = []) {
            const d = new MessageChannel;
            WM(d.port1, b);
            this.j.postMessage(a, [d.port2].concat(c))
        }
        g(a, b) {
            return new SM(c => {
                this.i(a, c, b)
            })
        }
    }

    function WM(a, b) {
        b && (a.onmessage = c => {
            b(new UM(c.data, VM(c.ports[0])))
        })
    };
    var YM = class {
        constructor(a) {
            this.g = a
        }
    };
    const ZM = a => {
        const b = Object.create(null);
        (typeof a === "string" ? [a] : a).forEach(c => {
            if (c === "null") throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
            b[c] = !0
        });
        return c => b[c] === !0
    };
    var aN = ({
        destination: a,
        Oa: b,
        origin: c,
        we: d = "ZNWN1d",
        onMessage: e,
        Mg: f
    }) => $M({
        destination: a,
        Pi: () => b.contentWindow,
        sj: c instanceof YM ? c : typeof c === "function" ? new YM(c) : new YM(ZM(c)),
        we: d,
        onMessage: e,
        Mg: f
    });
    const $M = ({
        destination: a,
        Pi: b,
        sj: c,
        uo: d,
        we: e,
        onMessage: f,
        Mg: g
    }) => new TM(new SM((h, k) => {
        const l = m => {
            m.source && m.source === b() && c.g(m.origin) && (m.data.n || m.data) === e && (a.removeEventListener("message", l, !1), d && m.data.t !== d ? k(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${m.data.t}.`)) : (h(VM(m.ports[0], f)), g && g(m)))
        };
        a.addEventListener("message", l, !1)
    }));

    function bN(a, b, c, d, e, f, g = null) {
        if (e) {
            if (U(Vr)) var h = null;
            else try {
                h = e.getItem("google_ama_config")
            } catch (m) {
                h = null
            }
            try {
                var k = h ? Zq(h) : null
            } catch (m) {
                k = null
            }
        } else k = null;
        a: {
            if (d) try {
                var l = Zq(d);
                break a
            } catch (m) {
                jK(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            l = null
        }
        if (d = l) {
            if (e) {
                l = new mq;
                A(d, 3, l);
                k = d ? .g() ? .j() || 1;
                k = Date.now() + 864E5 * k;
                Number.isFinite(k) && Ni(l, 1, Math.round(k));
                l = Fh(d);
                d.g() && (k = new lq, h = d ? .g() ? .g(), k = Ki(k, 23, h), h = d ? .g() ? .l(), k = Ki(k, 12, h), A(l, 15, k));
                k = ni(l, Mq, 1, w());
                for (h = 0; h < k.length; h++) Qh(k[h], 11);
                Qh(l, 22);
                if (U(Vr)) qK(a,
                    e);
                else try {
                    e.setItem("google_ama_config", Si(l))
                } catch (m) {
                    jK(a, {
                        lserr: 1
                    })
                }
            }
            e = oK(a, ni(d, vq, 7, w()));
            l = {};
            U(Wr) || (l.Bj = x(d, Gq, 8) || new Gq);
            e && (l.aa = e);
            e && nK(e, 3) && (l.sc = [1]);
            e = l;
            if (!U(yr) && c.google_pgb_reactive === 7 && !e.aa) return !1;
            WE(a, 2) && (Ij(5, [Ti(d)]), c = kK(c), f = new WK(f), l = (l = e.aa) && C(l, 4) || "", c.google_package = l, tK(a, b, d, e, f, new cq(["google-auto-placed"], c), g));
            return !0
        }
        k && (jK(a, {
            cfg: 1,
            cl: 1
        }), e != null && qK(a, e));
        return !1
    };

    function cN(a, b) {
        b = b && b[0];
        if (!b) return null;
        b = b.target;
        const c = b.getBoundingClientRect(),
            d = Zd(a.g.da() || window);
        if (c.bottom <= 0 || c.bottom > d.height || c.right <= 0 || c.left >= d.width) return null;
        var e = dN(a, b, c, a.g.g.elementsFromPoint(ld(c.left + c.width / 2, c.left, c.right - 1), ld(c.bottom - 1 - 2, c.top, c.bottom - 1)), 1, []),
            f = dN(a, b, c, a.g.g.elementsFromPoint(ld(c.left + c.width / 2, c.left, c.right - 1), ld(c.top + 2, c.top, c.bottom - 1)), 2, e.ob),
            g = dN(a, b, c, a.g.g.elementsFromPoint(ld(c.left + 2, c.left, c.right - 1), ld(c.top + c.height / 2,
                c.top, c.bottom - 1)), 3, [...e.ob, ...f.ob]);
        const h = dN(a, b, c, a.g.g.elementsFromPoint(ld(c.right - 1 - 2, c.left, c.right - 1), ld(c.top + c.height / 2, c.top, c.bottom - 1)), 4, [...e.ob, ...f.ob, ...g.ob]);
        var k = eN(a, b, c),
            l = n => ab(a.j, n.ub) && ab(a.l, n.Qg) && ab(a.i, n.Rg);
        e = Wa([...e.entries, ...f.entries, ...g.entries, ...h.entries], l);
        l = Wa(k, l);
        k = [...e, ...l];
        f = c.left < -2 || c.right > d.width + 2;
        f = k.length > 0 || f;
        g = $d(a.g.g);
        const m = new Mj(c.left, c.top, c.width, c.height);
        e = [...Xa(e, n => new Mj(n.nc.left, n.nc.top, n.nc.width, n.nc.height)), ...pb(Xa(l,
            n => Oj(m, n.nc))), ...Wa(Oj(m, new Mj(0, 0, d.width, d.height)), n => n.top >= 0 && n.top + n.height <= d.height)];
        return {
            entries: k,
            Dg: f,
            hh: {
                scrollX: g.x,
                scrollY: g.y
            },
            target: b,
            Xb: c,
            uh: {
                width: d.width,
                height: d.height
            },
            tj: e.length < 20 ? fN(m, e) : gN(c, e)
        }
    }

    function hN(a, b) {
        const c = a.g.da(),
            d = a.g.g;
        return new Promise((e, f) => {
            const g = c.IntersectionObserver;
            if (g)
                if (d.elementsFromPoint)
                    if (d.createNodeIterator)
                        if (d.createRange)
                            if (c.Range.prototype.getBoundingClientRect) {
                                var h = new g(k => {
                                    const l = new Gk,
                                        m = Fk(l, () => cN(a, k));
                                    m && (l.i.length && (m.Fi = Math.round(Number(l.i[0].duration))), h.disconnect(), e(m))
                                }, iN);
                                h.observe(b)
                            } else f(Error("5"));
            else f(Error("4"));
            else f(Error("3"));
            else f(Error("2"));
            else f(Error("1"))
        })
    }

    function dN(a, b, c, d, e, f) {
        if (c.width === 0 || c.height === 0) return {
            entries: [],
            ob: []
        };
        const g = [],
            h = [];
        for (let m = 0; m < d.length; m++) {
            const n = d[m];
            if (n === b) continue;
            if (ab(f, n)) continue;
            h.push(n);
            const p = n.getBoundingClientRect();
            if (a.g.contains(n, b)) {
                g.push(jN(a, c, n, p, 1, e));
                continue
            }
            if (a.g.contains(b, n)) {
                g.push(jN(a, c, n, p, 2, e));
                continue
            }
            a: {
                var k = a;
                var l = b;
                const D = k.g.Ki(l, n);
                if (!D) {
                    k = null;
                    break a
                }
                const {
                    Da: E,
                    Fb: G
                } = kN(k, l, D, n) || {},
                {
                    Da: H,
                    Fb: z
                } = kN(k, n, D, l) || {};k = E && G && H && z ? G <= z ? {
                    Da: E,
                    ub: lN[G]
                } : {
                    Da: H,
                    ub: mN[z]
                } : E && G ? {
                    Da: E,
                    ub: lN[G]
                } : H && z ? {
                    Da: H,
                    ub: mN[z]
                } : null
            }
            const {
                Da: r,
                ub: y
            } = k || {};
            r && y ? g.push(jN(a, c, n, p, y, e, r)) : g.push(jN(a, c, n, p, 9, e))
        }
        return {
            entries: g,
            ob: h
        }
    }

    function eN(a, b, c) {
        const d = [];
        for (b = b.parentElement; b; b = b.parentElement) {
            const f = b.getBoundingClientRect();
            if (f) {
                var e = ve(b, a.g.da());
                e && e.overflow !== "visible" && (e.overflowY !== "auto" && e.overflowY !== "scroll" && c.bottom > f.bottom + 2 ? d.push(jN(a, c, b, f, 5, 1)) : (e = e.overflowX === "auto" || e.overflowX === "scroll", !e && c.left < f.left - 2 ? d.push(jN(a, c, b, f, 5, 3)) : !e && c.right > f.right + 2 && d.push(jN(a, c, b, f, 5, 4))))
            }
        }
        return d
    }

    function fN(a, b) {
        if (a.width === 0 || a.height === 0 || b.length === 0) return 0;
        let c = 0;
        for (let d = 1; d < 1 << b.length; d++) {
            let e = a,
                f = 0;
            for (let g = 0; g < b.length && (!(d & 1 << g) || (f++, e = Nj(e, b[g]), e)); g++);
            e && (c = f % 2 === 1 ? c + (e.width + 1) * (e.height + 1) : c - (e.width + 1) * (e.height + 1))
        }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function gN(a, b) {
        if (a.width === 0 || a.height === 0 || b.length === 0) return 0;
        let c = 0;
        for (let d = a.left; d <= a.right; d++)
            for (let e = a.top; e <= a.bottom; e++)
                for (let f = 0; f < b.length; f++)
                    if (d >= b[f].left && d <= b[f].left + b[f].width && e >= b[f].top && e <= b[f].top + b[f].height) {
                        c++;
                        break
                    }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function jN(a, b, c, d, e, f, g) {
        const h = {
            element: c,
            nc: d,
            ub: e,
            Rg: f
        };
        if (ab(a.j, e) && ab(a.i, f)) {
            b = new Jj(b.top, b.right - 1, b.bottom - 1, b.left);
            if ((a = nN(a, c)) && Lj(b, a)) c = 4;
            else {
                a = oN(c, d);
                e = ck(c, "paddingLeft");
                f = ck(c, "paddingRight");
                var k = ck(c, "paddingTop"),
                    l = ck(c, "paddingBottom");
                e = new Jj(parseFloat(k), parseFloat(f), parseFloat(l), parseFloat(e));
                Lj(b, new Jj(a.top + e.top, a.right - e.right, a.bottom - e.bottom, a.left + e.left)) ? c = 3 : (c = oN(c, d), c = Lj(b, c) ? 2 : 1)
            }
            h.Qg = c
        }
        g && (h.Da = g);
        return h
    }

    function kN(a, b, c, d) {
        const e = [];
        for (var f = b; f && f !== c; f = f.parentElement) e.unshift(f);
        c = a.g.da();
        for (f = 0; f < e.length; f++) {
            const h = e[f];
            var g = ve(h, c);
            if (g) {
                if (g.position === "fixed") return {
                    Da: h,
                    Fb: 1
                };
                if (g.position === "sticky" && a.g.contains(h.parentElement, d)) return {
                    Da: h,
                    Fb: 2
                };
                if (g.position === "absolute") return {
                    Da: h,
                    Fb: 3
                };
                if (g.cssFloat !== "none") {
                    g = h === e[0];
                    const k = pN(a, e.slice(0, f), h);
                    if (g || k) return {
                        Da: h,
                        Fb: 4
                    }
                }
            }
        }
        return (a = pN(a, e, b)) ? {
            Da: a,
            Fb: 5
        } : null
    }

    function pN(a, b, c) {
        const d = c.getBoundingClientRect();
        if (!d) return null;
        for (let e = 0; e < b.length; e++) {
            const f = b[e];
            if (!a.g.contains(f, c)) continue;
            const g = f.getBoundingClientRect();
            if (!g) continue;
            const h = ve(f, a.g.da());
            if (h && d.bottom > g.bottom + 2 && h.overflowY === "visible") return f
        }
        return null
    }

    function nN(a, b) {
        var c = a.g.g;
        a = c.createRange();
        if (!a) return null;
        c = c.createNodeIterator(b, NodeFilter.SHOW_TEXT, {
            acceptNode: d => /^[\s\xa0]*$/.test(d.nodeValue) ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT
        });
        for (b = c.nextNode(); c.nextNode(););
        c = c.previousNode();
        if (!b || !c) return null;
        a.setStartBefore(b);
        a.setEndAfter(c);
        a = a.getBoundingClientRect();
        return a.width === 0 || a.height === 0 ? null : new Jj(a.top, a.right, a.bottom, a.left)
    }

    function oN(a, b) {
        var c = ck(a, "borderLeftWidth");
        var d = ck(a, "borderRightWidth"),
            e = ck(a, "borderTopWidth");
        a = ck(a, "borderBottomWidth");
        c = new Jj(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c));
        return new Jj(b.top + c.top, b.right - 1 - c.right, b.bottom - 1 - c.bottom, b.left + c.left)
    }
    class qN {
        constructor(a) {
            var b = rN;
            this.g = Wd(a);
            this.j = [5, 8, 9];
            this.l = [3, 4];
            this.i = b
        }
    }
    const lN = {
            [1]: 3,
            [4]: 10,
            [3]: 12,
            [2]: 4,
            [5]: 5
        },
        mN = {
            [1]: 6,
            [4]: 11,
            [3]: 13,
            [2]: 7,
            [5]: 8
        };
    Wa(ye({
        Nl: 1,
        Ol: 2,
        En: 3,
        Fn: 4,
        Hn: 5,
        Jl: 6,
        Kl: 7,
        Ml: 8,
        Om: 9,
        Gn: 10,
        Ll: 11,
        Dn: 12,
        Il: 13
    }), a => !ab([1, 2], a));
    ye({
        bl: 1,
        Rm: 2,
        ql: 3,
        In: 4
    });
    const rN = ye({
            dl: 1,
            Ln: 2,
            Cm: 3,
            rn: 4
        }),
        iN = {
            threshold: [0, .25, .5, .75, .95, .96, .97, .98, .99, 1]
        };

    function sN(a) {
        a.g != null || a.B || (a.g = new MutationObserver(b => {
            for (const c of b)
                for (const d of c.addedNodes) Da(d) && d.nodeType == 1 && (b = a, d.matches('A[href]:not([href=""])') && Po(b.j, d))
        }), a.g.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0
        }))
    }
    var tN = class extends Q {
        constructor(a) {
            super();
            this.win = a;
            this.j = new Qo;
            this.g = null;
            xo(this, () => {
                this.g ? .disconnect();
                this.g = null
            })
        }
    };

    function uN(a, b) {
        b.addEventListener("click", () => {
            var c = a.g;
            var d = b.getAttribute("href");
            c = d ? d === "#" ? Fp(Tl(4)) : d.startsWith("#") ? Fp(Tl(5)) : vN(d, c) : Hp("Empty href");
            if (c.g != null) {
                d = c.getValue();
                c = a.M;
                var e = new Vl;
                d = A(e, 1, d);
                c.call(a, d)
            } else a.i(c.i)
        })
    }
    var xN = class {
        constructor(a, b, c) {
            var d = wN();
            this.win = a;
            this.g = b;
            this.M = c;
            this.i = d
        }
        J() {
            const a = new tN(this.win);
            Array.from(a.win.document.querySelectorAll('A[href]:not([href=""])')).forEach(b => {
                uN(this, b)
            });
            sN(a);
            No(a.j).listen(b => {
                uN(this, b)
            })
        }
    };

    function vN(a, b) {
        return yN(a, b).map(c => yN(b).map(d => {
            if (c.protocol === "http:" || c.protocol === "https:") {
                var e = Tl(2);
                e = Qi(e, 2, `${c.host}${c.pathname}`);
                d = Qi(e, 3, `${d.host}${d.pathname}`)
            } else d = c.protocol === "javascript:" ? Tl(3) : Tl(1);
            return d
        }))
    }

    function yN(a, b) {
        return Lp(Ip(() => new URL(a, b)), () => Error("Invalid URL"))
    };

    function zN(a) {
        if (a < 0 || !Number.isInteger(a)) return Hp(`Not a non-negative integer: ${a}`);
        const b = [];
        do b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a % 64)), a = Math.floor(a / 64); while (a > 0);
        return Fp(b.reverse().join(""))
    };
    class AN {
        constructor() {
            this.Ch = 5E3
        }
        gi() {
            return 5E3
        }
    }

    function BN(a, b) {
        return a.g ? Math.floor(b / 5E3) * 5E3 / a.g.Ch : b
    }

    function CN(a, b) {
        b = b.map(c => BN(a, c));
        return DN(b, a.i === void 0 ? void 0 : BN(a, a.i)).map(c => {
            a: {
                var d = EN;
                const e = [];
                for (const f of c) {
                    c = d(f);
                    if (c.g == null) {
                        d = new Gp(null, c.i);
                        break a
                    }
                    e.push(c.getValue())
                }
                d = Fp(e)
            }
            return d
        }).map(c => c.join(".")).map(c => FN(c, a.g ? .gi()))
    }
    var GN = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function EN(a) {
        const b = zN(a.value);
        if (b.g == null) return b;
        const c = b.getValue();
        return a.Vd === 1 ? Fp(`${c}`) : a.Vd === 2 ? Fp(`${c}${"~"}`) : Np(zN(a.Vd - 2), d => {
            throw d;
        }).map(d => `${c}${"~"}${d}`)
    }

    function DN(a, b) {
        const c = [];
        for (let d = 0; d < a.length; d++) {
            const e = a[d] ? ? b;
            if (e === void 0) return Hp("Sparse but no default");
            c.length === 0 || e !== c[c.length - 1].value ? c.push({
                value: e,
                Vd: 1
            }) : c[c.length - 1].Vd++
        }
        return Fp(c)
    }

    function FN(a, b) {
        return a === "" ? Fp("") : HN(b).map(c => `${c}${a}`)
    }

    function HN(a) {
        return a === void 0 || a === 1 ? Fp("") : Mp(zN(a), "ComFactor: ").map(b => `${"~"}${b}${"."}`)
    };
    var IN = class extends Q {
        constructor(a) {
            super();
            this.win = a;
            this.j = new R(!1);
            this.g = () => {
                this.j.g(this.win.document.hasFocus())
            }
        }
        J() {
            this.win.addEventListener("focus", this.g);
            this.win.addEventListener("blur", this.g);
            xo(this, () => void this.win.removeEventListener("focus", this.g));
            xo(this, () => void this.win.removeEventListener("blur", this.g));
            this.j.g(this.win.document.hasFocus())
        }
    };

    function JN(a) {
        a.j.g(a.win.document.visibilityState === "visible")
    }
    var KN = class extends Q {
        constructor(a) {
            super();
            this.win = a;
            this.j = new R(!1);
            this.g = () => void JN(this)
        }
        J() {
            this.win.addEventListener("visibilitychange", this.g);
            xo(this, () => void this.win.removeEventListener("visibilitychange", this.g));
            JN(this)
        }
    };

    function LN(a) {
        return a.g !== null ? a.i + a.j() - a.g : a.i
    }
    var NN = class {
        constructor(a) {
            this.win = a;
            this.j = MN(this.win);
            this.i = 0;
            this.g = null
        }
        start() {
            this.g === null && (this.g = this.j())
        }
    };

    function MN(a) {
        return a.performance && a.performance.now ? () => a.performance.now() : () => Date.now()
    };

    function ON(a) {
        a = new PN(a);
        a.J();
        return a
    }

    function QN(a) {
        const b = ap(a.win, 1E3, () => void a.handleEvent());
        a.win.addEventListener("scroll", () => void b())
    }

    function RN(a) {
        const b = SN(a.win),
            c = () => {
                const d = SN(a.win),
                    e = Math.abs(d.height - b.height);
                if (Math.abs(d.width - b.width) > 20 || e > 20) a.F = !0, a.win.removeEventListener("resize", c)
            };
        a.win.addEventListener("resize", c)
    }

    function TN(a) {
        a.l = !a.g.P;
        Io(a.g, !1, () => {
            a.win.setTimeout(() => {
                a.l = !0
            }, 100)
        })
    }

    function UN(a) {
        Ho(a.g, !0, () => void a.j.start());
        Ho(a.g, !1, () => {
            var b = a.j;
            b.g !== null && (b.i += b.j() - b.g);
            b.g = null
        });
        a.G.start()
    }

    function VN(a) {
        var b = a.win.scrollY;
        var c = P(a.win);
        b = {
            ae: Math.floor(b / 100),
            dd: Math.floor((b + c) / 100),
            oh: a.win.performance.now()
        };
        if (b.ae < 0 || b.dd < 0 || b.ae > 1E3 || b.dd > 1E3) a.C = !0, a.i = null;
        else {
            if (a.i) {
                c = a.i;
                var d = new OC(c.ae, c.dd),
                    e = new OC(b.ae, b.dd);
                var f = Math.max(d.start, e.start);
                d = Math.min(d.end, e.end);
                if (f = f <= d ? new OC(f, d) : null)
                    for (c = b.oh - c.oh, d = f.start; d <= f.end; d++) a.B[d] = (a.B[d] ? ? 0) + c
            }
            a.i = a.A.P ? b : null
        }
    }
    var PN = class {
        constructor(a) {
            this.win = a;
            this.B = [];
            a = this.win;
            var b = new IN(a);
            b.J();
            b = Eo(b.j);
            a = new KN(a);
            a.J();
            this.A = this.g = Do(b, Eo(a.j));
            this.j = new NN(this.win);
            this.G = new NN(this.win);
            this.H = new GN((new GN(new AN)).g, 0);
            this.F = this.l = this.C = !1;
            this.i = null
        }
        J() {
            QN(this);
            RN(this);
            TN(this);
            UN(this);
            this.A.listen(() => void VN(this));
            q.setInterval(() => void this.handleEvent(), 5E3);
            this.handleEvent()
        }
        handleEvent() {
            this.A.P && VN(this)
        }
    };

    function SN(a) {
        return new pd(Un(a), P(a))
    };

    function WN(a, {
        Ka: b
    }) {
        a = new XN(a, b);
        if (!a.Ka && U(Es)) {
            b = a.win;
            var c = YN(ZN(a));
            (new xN(b, b.document.baseURI, c)).J()
        }
        $N(a)
    }

    function $N(a) {
        if (U(Fs)) {
            var b = ON(a.win);
            yn(new aF(a.win), aO(() => {
                var c = ZN(a),
                    d = new Yl,
                    e = CN(b.H, b.B);
                if (e.g == null) throw Mp(e, "PVDC: ").i;
                var f = new Xl;
                f = Mi(f, 2, 5E3);
                f = Mi(f, 1, 100);
                e = e.getValue();
                e = Qi(f, 3, e);
                f = SN(b.win);
                var g = new Wl;
                g = Mi(g, 1, f.width);
                f = Mi(g, 2, f.height);
                e = A(e, 4, f);
                f = new Wl;
                f = Mi(f, 1, Yn(b.win).scrollWidth);
                f = Mi(f, 2, Yn(b.win).scrollHeight);
                e = A(e, 5, f);
                e = L(e, 6, b.l);
                f = Math.round(LN(b.G) / 1E3);
                e = Mi(e, 8, f);
                f = Math.round(LN(b.j) / 1E3);
                e = Mi(e, 9, f);
                b.C && gi(e, 7, Gg, 1);
                b.F && gi(e, 7, Gg, 2);
                d = B(d, 2, Zl, e);
                c(d)
            }))
        }
    }

    function ZN(a) {
        if (!a.M) {
            const b = O(hF);
            a.M = c => {
                mF(b, c)
            }
        }
        return a.M
    }
    var XN = class {
        constructor(a, b) {
            this.win = a;
            this.Ka = b;
            this.M = null
        }
    };

    function YN(a) {
        return b => {
            var c = new Yl;
            b = B(c, 1, Zl, b);
            return void a(b)
        }
    }

    function wN() {
        return a => {
            W.ba(1243, a, void 0, bO("LCC"))
        }
    }

    function aO(a) {
        return () => void W.vb(1243, a, bO("PVC"))
    }

    function bO(a) {
        return b => {
            b.errSrc = a
        }
    };
    var dO = a => {
        const b = a.D;
        b.google_ad_output == null && (b.google_ad_output = "html");
        if (b.google_ad_client != null) {
            var c;
            (c = String(b.google_ad_client)) ? (c = c.toLowerCase(), c.substring(0, 3) != "ca-" && (c = "ca-" + c)) : c = "";
            b.google_ad_client = c
        }
        b.google_ad_slot != null && (b.google_ad_slot = String(b.google_ad_slot));
        b.google_webgl_support = !!rj.WebGLRenderingContext;
        b.google_ad_section = b.google_ad_section || b.google_ad_region || "";
        b.google_country = b.google_country || b.google_gl || "";
        c = (new Date).getTime();
        Array.isArray(b.google_color_bg) &&
            (b.google_color_bg = cO(a, b.google_color_bg, c));
        Array.isArray(b.google_color_text) && (b.google_color_text = cO(a, b.google_color_text, c));
        Array.isArray(b.google_color_link) && (b.google_color_link = cO(a, b.google_color_link, c));
        Array.isArray(b.google_color_url) && (b.google_color_url = cO(a, b.google_color_url, c));
        Array.isArray(b.google_color_border) && (b.google_color_border = cO(a, b.google_color_border, c));
        Array.isArray(b.google_color_line) && (b.google_color_line = cO(a, b.google_color_line, c))
    };

    function cO(a, b, c) {
        a.i |= 2;
        return b[c % b.length]
    };
    const eO = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };
    const fO = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        gO = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        hO = {
            zd: a => a.listener,
            Cc: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            Pb: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        iO = {
            zd: a => a.listener,
            Cc: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            Pb: (a, b) => {
                b = b.__gppReturn;
                const c = b.returnValue.data;
                a ? .(c, b.success)
            }
        };

    function jO(a) {
        let b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            kf: b.__gppReturn.callId
        }
    }

    function kO(a, b) {
        if (!a) return !1;
        const c = nL(a.split("~")[0]),
            d = iL(a),
            e = Wh(c, 3, Kg, w());
        for (let si = 0; si < e.length; ++si) {
            const Ov = e[si];
            if (!b.includes(Ov)) continue;
            const ob = d[si];
            switch (Ov) {
                case 7:
                    if (ob.length === 0) throw Error("Cannot decode empty USNat section string.");
                    const ag = ob.split(".");
                    if (ag.length > 2) throw Error(`Expected at most 2 segments but got ${ag.length} when decoding ${ob}.`);
                    var f = void 0,
                        g = void 0,
                        h = void 0,
                        k = void 0,
                        l = void 0,
                        m = void 0,
                        n = void 0,
                        p = void 0,
                        r = void 0,
                        y = void 0,
                        D = void 0,
                        E = void 0,
                        G = void 0,
                        H = void 0,
                        z = void 0,
                        I = void 0,
                        F = void 0,
                        ba = void 0,
                        bb = void 0,
                        xa = void 0,
                        fa = void 0,
                        la = void 0,
                        fb = void 0,
                        gb = void 0,
                        bg = void 0,
                        qa = void 0,
                        Md = void 0,
                        Pv = void 0,
                        Qv = void 0,
                        Rv = void 0,
                        Sv = ag[0];
                    if (Sv.length === 0) throw Error("Cannot decode empty core segment string.");
                    let ti = mL(Sv, TL);
                    const zm = kL(ti.slice(0, 6));
                    ti = ti.slice(6);
                    if (zm !== 1) throw Error(`Unable to decode unsupported USNat Section specification version ${zm} - only version 1 is supported.`);
                    let Am = 0;
                    const oa = [];
                    for (let ia = 0; ia < SL.length; ia++) {
                        const Z =
                            SL[ia];
                        oa.push(kL(ti.slice(Am, Am + Z)));
                        Am += Z
                    }
                    var RR = new OL;
                    Rv = Mi(RR, 1, zm);
                    var SR = oa.shift();
                    Qv = M(Rv, 2, SR);
                    var TR = oa.shift();
                    Pv = M(Qv, 3, TR);
                    var UR = oa.shift();
                    Md = M(Pv, 4, UR);
                    var VR = oa.shift();
                    qa = M(Md, 5, VR);
                    var WR = oa.shift();
                    bg = M(qa, 6, WR);
                    var YR = oa.shift();
                    gb = M(bg, 7, YR);
                    var ZR = oa.shift();
                    fb = M(gb, 8, ZR);
                    var $R = oa.shift();
                    la = M(fb, 9, $R);
                    var aS = oa.shift();
                    fa = M(la, 10, aS);
                    var bS = new NL,
                        cS = oa.shift();
                    xa = M(bS, 1, cS);
                    var dS = oa.shift();
                    bb = M(xa, 2, dS);
                    var eS = oa.shift();
                    ba = M(bb, 3, eS);
                    var fS = oa.shift();
                    F = M(ba, 4, fS);
                    var gS =
                        oa.shift();
                    I = M(F, 5, gS);
                    var hS = oa.shift();
                    z = M(I, 6, hS);
                    var iS = oa.shift();
                    H = M(z, 7, iS);
                    var jS = oa.shift();
                    G = M(H, 8, jS);
                    var kS = oa.shift();
                    E = M(G, 9, kS);
                    var lS = oa.shift();
                    D = M(E, 10, lS);
                    var mS = oa.shift();
                    y = M(D, 11, mS);
                    var nS = oa.shift();
                    r = M(y, 12, nS);
                    p = A(fa, 11, r);
                    var oS = new ML,
                        pS = oa.shift();
                    n = M(oS, 1, pS);
                    var qS = oa.shift();
                    m = M(n, 2, qS);
                    l = A(p, 12, m);
                    var rS = oa.shift();
                    k = M(l, 13, rS);
                    var sS = oa.shift();
                    h = M(k, 14, sS);
                    var tS = oa.shift();
                    g = M(h, 15, tS);
                    var uS = oa.shift();
                    const Tv = f = M(g, 16, uS);
                    if (ag.length === 1) var Uv = QL(Tv);
                    else {
                        var vS =
                            QL(Tv),
                            Vv = void 0,
                            Wv = void 0,
                            Xv = void 0,
                            Yv = ag[1];
                        if (Yv.length === 0) throw Error("Cannot decode empty GPC segment string.");
                        const ia = mL(Yv, 3),
                            Z = kL(ia.slice(0, 2));
                        if (Z < 0 || Z > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${Z}.`);
                        Xv = Z + 1;
                        const Nd = kL(ia.charAt(2));
                        var wS = new PL;
                        Wv = M(wS, 2, Xv);
                        Vv = L(Wv, 1, !!Nd);
                        Uv = A(vS, 2, Vv)
                    }
                    const Bm = x(Uv, OL, 1);
                    if (Ei(Bm, 8) === 1 || Ei(Bm, 9) === 1 || Ei(Bm, 10) === 1) return !0;
                    break;
                case 8:
                    if (ob.length === 0) throw Error("Cannot decode empty USCA section string.");
                    const cg =
                        ob.split(".");
                    if (cg.length > 2) throw Error(`Expected at most 1 sub-section but got ${cg.length-1} when decoding ${ob}.`);
                    var xS = void 0,
                        Zv = void 0,
                        $v = void 0,
                        aw = void 0,
                        bw = void 0,
                        cw = void 0,
                        dw = void 0,
                        ew = void 0,
                        fw = void 0,
                        gw = void 0,
                        hw = void 0,
                        iw = void 0,
                        jw = void 0,
                        kw = void 0,
                        lw = void 0,
                        mw = void 0,
                        nw = void 0,
                        ow = void 0,
                        pw = void 0,
                        qw = void 0,
                        rw = void 0,
                        sw = void 0,
                        tw = void 0,
                        uw = cg[0];
                    if (uw.length === 0) throw Error("Cannot decode empty core segment string.");
                    let ui = mL(uw, wL);
                    const Cm = kL(ui.slice(0, 6));
                    ui = ui.slice(6);
                    if (Cm !==
                        1) throw Error(`Unable to decode unsupported USCA Section specification version ${Cm} - only version 1 is supported.`);
                    let Dm = 0;
                    const za = [];
                    for (let ia = 0; ia < vL.length; ia++) {
                        const Z = vL[ia];
                        za.push(kL(ui.slice(Dm, Dm + Z)));
                        Dm += Z
                    }
                    var yS = new rL;
                    tw = Mi(yS, 1, Cm);
                    var zS = za.shift();
                    sw = M(tw, 2, zS);
                    var AS = za.shift();
                    rw = M(sw, 3, AS);
                    var BS = za.shift();
                    qw = M(rw, 4, BS);
                    var CS = za.shift();
                    pw = M(qw, 5, CS);
                    var DS = za.shift();
                    ow = M(pw, 6, DS);
                    var ES = new qL,
                        FS = za.shift();
                    nw = M(ES, 1, FS);
                    var GS = za.shift();
                    mw = M(nw, 2, GS);
                    var HS = za.shift();
                    lw = M(mw, 3, HS);
                    var IS = za.shift();
                    kw = M(lw, 4, IS);
                    var JS = za.shift();
                    jw = M(kw, 5, JS);
                    var KS = za.shift();
                    iw = M(jw, 6, KS);
                    var LS = za.shift();
                    hw = M(iw, 7, LS);
                    var MS = za.shift();
                    gw = M(hw, 8, MS);
                    var NS = za.shift();
                    fw = M(gw, 9, NS);
                    ew = A(ow, 7, fw);
                    var OS = new pL,
                        PS = za.shift();
                    dw = M(OS, 1, PS);
                    var QS = za.shift();
                    cw = M(dw, 2, QS);
                    bw = A(ew, 8, cw);
                    var RS = za.shift();
                    aw = M(bw, 9, RS);
                    var SS = za.shift();
                    $v = M(aw, 10, SS);
                    var TS = za.shift();
                    Zv = M($v, 11, TS);
                    var US = za.shift();
                    const vw = xS = M(Zv, 12, US);
                    if (cg.length === 1) var ww = tL(vw);
                    else {
                        var VS = tL(vw),
                            xw =
                            void 0,
                            yw = void 0,
                            zw = void 0,
                            Aw = cg[1];
                        if (Aw.length === 0) throw Error("Cannot decode empty GPC segment string.");
                        const ia = mL(Aw, 3),
                            Z = kL(ia.slice(0, 2));
                        if (Z < 0 || Z > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${Z}.`);
                        zw = Z + 1;
                        const Nd = kL(ia.charAt(2));
                        var WS = new sL;
                        yw = M(WS, 2, zw);
                        xw = L(yw, 1, !!Nd);
                        ww = A(VS, 2, xw)
                    }
                    const Bw = x(ww, rL, 1);
                    if (Ei(Bw, 5) === 1 || Ei(Bw, 6) === 1) return !0;
                    break;
                case 9:
                    if (ob.length === 0) throw Error("Cannot decode empty USVA section string.");
                    let vi = mL(ob, XL);
                    const Em = kL(vi.slice(0,
                        6));
                    vi = vi.slice(6);
                    if (Em !== 1) throw Error(`Unable to decode unsupported USVA Section specification version ${Em} - only version 1 is supported.`);
                    let Fm = 0;
                    const Na = [];
                    for (let ia = 0; ia < WL.length; ia++) {
                        const Z = WL[ia];
                        Na.push(kL(vi.slice(Fm, Fm + Z)));
                        Fm += Z
                    }
                    var XS = Em,
                        YS = new VL,
                        ZS = Mi(YS, 1, XS),
                        $S = Na.shift(),
                        aT = M(ZS, 2, $S),
                        bT = Na.shift(),
                        cT = M(aT, 3, bT),
                        dT = Na.shift(),
                        eT = M(cT, 4, dT),
                        fT = Na.shift(),
                        gT = M(eT, 5, fT),
                        hT = Na.shift();
                    var iT = M(gT, 6, hT);
                    var jT = new UL,
                        kT = Na.shift(),
                        lT = M(jT, 1, kT),
                        mT = Na.shift(),
                        nT = M(lT, 2, mT),
                        oT =
                        Na.shift(),
                        pT = M(nT, 3, oT),
                        qT = Na.shift(),
                        rT = M(pT, 4, qT),
                        sT = Na.shift(),
                        tT = M(rT, 5, sT),
                        uT = Na.shift(),
                        vT = M(tT, 6, uT),
                        wT = Na.shift(),
                        xT = M(vT, 7, wT),
                        yT = Na.shift();
                    var zT = M(xT, 8, yT);
                    var AT = A(iT, 7, zT),
                        BT = Na.shift(),
                        CT = M(AT, 8, BT),
                        DT = Na.shift(),
                        ET = M(CT, 9, DT),
                        FT = Na.shift(),
                        GT = M(ET, 10, FT),
                        HT = Na.shift(),
                        Cw = M(GT, 11, HT);
                    if (Ei(Cw, 5) === 1 || Ei(Cw, 6) === 1) return !0;
                    break;
                case 10:
                    if (ob.length === 0) throw Error("Cannot decode empty USCO section string.");
                    const dg = ob.split(".");
                    if (dg.length > 2) throw Error(`Expected at most 2 segments but got ${dg.length} when decoding ${ob}.`);
                    var IT = void 0,
                        Dw = void 0,
                        Ew = void 0,
                        Fw = void 0,
                        Gw = void 0,
                        Hw = void 0,
                        Iw = void 0,
                        Jw = void 0,
                        Kw = void 0,
                        Lw = void 0,
                        Mw = void 0,
                        Nw = void 0,
                        Ow = void 0,
                        Pw = void 0,
                        Qw = void 0,
                        Rw = void 0,
                        Sw = void 0,
                        Tw = void 0,
                        Uw = dg[0];
                    if (Uw.length === 0) throw Error("Cannot decode empty core segment string.");
                    let wi = mL(Uw, DL);
                    const Gm = kL(wi.slice(0, 6));
                    wi = wi.slice(6);
                    if (Gm !== 1) throw Error(`Unable to decode unsupported USCO Section specification version ${Gm} - only version 1 is supported.`);
                    let Hm = 0;
                    const Za = [];
                    for (let ia = 0; ia < CL.length; ia++) {
                        const Z =
                            CL[ia];
                        Za.push(kL(wi.slice(Hm, Hm + Z)));
                        Hm += Z
                    }
                    var JT = new yL;
                    Tw = Mi(JT, 1, Gm);
                    var KT = Za.shift();
                    Sw = M(Tw, 2, KT);
                    var LT = Za.shift();
                    Rw = M(Sw, 3, LT);
                    var MT = Za.shift();
                    Qw = M(Rw, 4, MT);
                    var NT = Za.shift();
                    Pw = M(Qw, 5, NT);
                    var OT = Za.shift();
                    Ow = M(Pw, 6, OT);
                    var PT = new xL,
                        QT = Za.shift();
                    Nw = M(PT, 1, QT);
                    var RT = Za.shift();
                    Mw = M(Nw, 2, RT);
                    var ST = Za.shift();
                    Lw = M(Mw, 3, ST);
                    var TT = Za.shift();
                    Kw = M(Lw, 4, TT);
                    var UT = Za.shift();
                    Jw = M(Kw, 5, UT);
                    var VT = Za.shift();
                    Iw = M(Jw, 6, VT);
                    var WT = Za.shift();
                    Hw = M(Iw, 7, WT);
                    Gw = A(Ow, 7, Hw);
                    var XT = Za.shift();
                    Fw =
                        M(Gw, 8, XT);
                    var YT = Za.shift();
                    Ew = M(Fw, 9, YT);
                    var ZT = Za.shift();
                    Dw = M(Ew, 10, ZT);
                    var $T = Za.shift();
                    const Vw = IT = M(Dw, 11, $T);
                    if (dg.length === 1) var Ww = AL(Vw);
                    else {
                        var aU = AL(Vw),
                            Xw = void 0,
                            Yw = void 0,
                            Zw = void 0,
                            $w = dg[1];
                        if ($w.length === 0) throw Error("Cannot decode empty GPC segment string.");
                        const ia = mL($w, 3),
                            Z = kL(ia.slice(0, 2));
                        if (Z < 0 || Z > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${Z}.`);
                        Zw = Z + 1;
                        const Nd = kL(ia.charAt(2));
                        var bU = new zL;
                        Yw = M(bU, 2, Zw);
                        Xw = L(Yw, 1, !!Nd);
                        Ww = A(aU, 2, Xw)
                    }
                    const ax =
                        x(Ww, yL, 1);
                    if (Ei(ax, 5) === 1 || Ei(ax, 6) === 1) return !0;
                    break;
                case 12:
                    if (ob.length === 0) throw Error("Cannot decode empty usct section string.");
                    const eg = ob.split(".");
                    if (eg.length > 2) throw Error(`Expected at most 2 segments but got ${eg.length} when decoding ${ob}.`);
                    var cU = void 0,
                        bx = void 0,
                        cx = void 0,
                        dx = void 0,
                        ex = void 0,
                        fx = void 0,
                        gx = void 0,
                        hx = void 0,
                        ix = void 0,
                        jx = void 0,
                        kx = void 0,
                        lx = void 0,
                        mx = void 0,
                        nx = void 0,
                        ox = void 0,
                        px = void 0,
                        qx = void 0,
                        rx = void 0,
                        sx = void 0,
                        tx = void 0,
                        ux = void 0,
                        vx = void 0,
                        wx = eg[0];
                    if (wx.length ===
                        0) throw Error("Cannot decode empty core segment string.");
                    let xi = mL(wx, LL);
                    const Im = kL(xi.slice(0, 6));
                    xi = xi.slice(6);
                    if (Im !== 1) throw Error(`Unable to decode unsupported USCT Section specification version ${Im} - only version 1 is supported.`);
                    let Jm = 0;
                    const Ca = [];
                    for (let ia = 0; ia < KL.length; ia++) {
                        const Z = KL[ia];
                        Ca.push(kL(xi.slice(Jm, Jm + Z)));
                        Jm += Z
                    }
                    var dU = new GL;
                    vx = Mi(dU, 1, Im);
                    var eU = Ca.shift();
                    ux = M(vx, 2, eU);
                    var fU = Ca.shift();
                    tx = M(ux, 3, fU);
                    var gU = Ca.shift();
                    sx = M(tx, 4, gU);
                    var hU = Ca.shift();
                    rx = M(sx, 5,
                        hU);
                    var iU = Ca.shift();
                    qx = M(rx, 6, iU);
                    var jU = new FL,
                        kU = Ca.shift();
                    px = M(jU, 1, kU);
                    var lU = Ca.shift();
                    ox = M(px, 2, lU);
                    var mU = Ca.shift();
                    nx = M(ox, 3, mU);
                    var nU = Ca.shift();
                    mx = M(nx, 4, nU);
                    var oU = Ca.shift();
                    lx = M(mx, 5, oU);
                    var pU = Ca.shift();
                    kx = M(lx, 6, pU);
                    var qU = Ca.shift();
                    jx = M(kx, 7, qU);
                    var rU = Ca.shift();
                    ix = M(jx, 8, rU);
                    hx = A(qx, 7, ix);
                    var sU = new EL,
                        tU = Ca.shift();
                    gx = M(sU, 1, tU);
                    var uU = Ca.shift();
                    fx = M(gx, 2, uU);
                    var vU = Ca.shift();
                    ex = M(fx, 3, vU);
                    dx = A(hx, 8, ex);
                    var wU = Ca.shift();
                    cx = M(dx, 9, wU);
                    var xU = Ca.shift();
                    bx = M(cx, 10, xU);
                    var yU = Ca.shift();
                    const xx = cU = M(bx, 11, yU);
                    if (eg.length === 1) var yx = IL(xx);
                    else {
                        var zU = IL(xx),
                            zx = void 0,
                            Ax = void 0,
                            Bx = void 0,
                            Cx = eg[1];
                        if (Cx.length === 0) throw Error("Cannot decode empty GPC segment string.");
                        const ia = mL(Cx, 3),
                            Z = kL(ia.slice(0, 2));
                        if (Z < 0 || Z > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${Z}.`);
                        Bx = Z + 1;
                        const Nd = kL(ia.charAt(2));
                        var AU = new HL;
                        Ax = M(AU, 2, Bx);
                        zx = L(Ax, 1, !!Nd);
                        yx = A(zU, 2, zx)
                    }
                    const Dx = x(yx, GL, 1);
                    if (Ei(Dx, 5) === 1 || Ei(Dx, 6) === 1) return !0
            }
        }
        return !1
    }
    var oO = class extends Q {
        constructor(a) {
            ({
                timeoutMs: c,
                cmpInteractionEventReporter: b
            } = {});
            var b, c;
            super();
            this.caller = new FF(a, "__gppLocator", d => typeof d.__gpp === "function", jO);
            this.caller.C.set("addEventListener", fO);
            this.caller.A.set("addEventListener", hO);
            this.caller.C.set("removeEventListener", gO);
            this.caller.A.set("removeEventListener", iO);
            this.timeoutMs = c ? ? 500;
            this.cmpInteractionEventReporter = b
        }
        i() {
            this.caller.dispose();
            super.i()
        }
        addEventListener(a) {
            const b = Bb(() => {
                    a(lO, !0)
                }),
                c = this.timeoutMs ===
                -1 ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            EF(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (d.pingData ? .gppVersion === void 0 || d.pingData.gppVersion === "1" || d.pingData.gppVersion === "1.0") {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) ? f = d : (this.removeEventListener(d.listenerId), f = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 2,
                                gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                applicableSections: [-1]
                            }
                        });
                        a(f, e);
                        this.cmpInteractionEventReporter ? .g()
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(mO, !0);
                            return
                        }
                        a(nO, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            EF(this.caller, "removeEventListener", {
                listener: () => {},
                listenerId: a
            })
        }
    };
    const nO = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        lO = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        mO = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function pO(a) {
        return !a || a.length === 1 && a[0] === -1
    };

    function qO(a, b) {
        if (b.internalErrorState) Pi(a, 11, b.gppString);
        else if (pO(b.applicableSections)) {
            var c = di(a, 10, b.applicableSections, Ng);
            Ki(c, 12, !1)
        } else {
            c = !1;
            try {
                c = kO(b.gppString, b.applicableSections)
            } catch (d) {
                W.ba(1182, d, void 0, void 0)
            }
            a = di(a, 10, b.applicableSections, Ng);
            b = Pi(a, 11, b.gppString);
            Ki(b, 12, c)
        }
    }

    function rO(a, b) {
        a = new oO(a);
        if (!CF(a.caller)) return Promise.resolve(null);
        const c = GE(),
            d = LE(c, 35);
        if (d) return Promise.resolve(d);
        const e = new Promise(f => {
            f = {
                resolve: f
            };
            const g = LE(c, 36, []);
            g.push(f);
            ME(c, 36, g)
        });
        d || d === null || (ME(c, 35, null), a.addEventListener(f => {
            if (f.pingData.signalStatus === "ready" || pO(f.pingData.applicableSections)) {
                f = f.pingData;
                ME(c, 35, f);
                qO(b, f);
                for (const g of LE(c, 36, [])) g.resolve(f);
                ME(c, 36, [])
            }
        }));
        return e
    };

    function sO(a, b, c) {
        c = LK(a, PF(b, {
            idpcApplies: c
        }));
        c = Pi(c, 2, b.tcString);
        c = Pi(c, 4, b.addtlConsent || "");
        Qh(c, 7, Hg(b.internalErrorState));
        c = !SF(b, ["2", "7", "9", "10"], 3);
        Ki(a, 8, c);
        c = !SF(b, ["3", "4"], 0);
        Ki(a, 9, c);
        b.gdprApplies != null && Ki(a, 3, b.gdprApplies)
    }

    function tO(a, b, c) {
        a = new YF(a, {
            timeoutMs: -1,
            Sh: !0
        });
        if (!UF(a)) return Promise.resolve(null);
        const d = GE(),
            e = LE(d, 24);
        if (e) return Promise.resolve(e);
        const f = new Promise(g => {
            g = {
                resolve: g
            };
            const h = LE(d, 25, []);
            h.push(g);
            ME(d, 25, h)
        });
        e || e === null || (ME(d, 24, null), a.addEventListener(g => {
            if (OF(g)) {
                ME(d, 24, g);
                sO(b, g, c);
                for (const h of LE(d, 25, [])) h.resolve(g);
                ME(d, 25, [])
            } else ME(d, 24, null)
        }));
        return f
    };
    const uO = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.Sa({
                    jc: c ? ? void 0,
                    lg: d ? void 0 : 2
                })
            })
        },
        vO = {
            zd: a => a.Sa,
            Cc: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            Pb: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    jc: b.returnValue ? ? void 0,
                    lg: b.success ? void 0 : 2
                })
            }
        };

    function wO(a) {
        let b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            kf: b.__uspapiReturn.callId
        }
    }

    function xO(a, b) {
        let c = {};
        if (CF(a.caller)) {
            var d = Bb(() => {
                b(c)
            });
            EF(a.caller, "getDataWithCallback", {
                Sa: e => {
                    e.lg || (c = e.jc);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var yO = class extends Q {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new FF(a, "__uspapiLocator", b => typeof b.__uspapi === "function", wO);
            this.caller.C.set("getDataWithCallback", uO);
            this.caller.A.set("getDataWithCallback", vO)
        }
        i() {
            this.caller.dispose();
            super.i()
        }
    };

    function zO(a) {
        const b = new yO(a);
        return new Promise(c => {
            xO(b, d => {
                d && typeof d.uspString === "string" ? c(d.uspString) : c(null)
            })
        })
    }
    async function AO(a, {
        Ka: b,
        cj: c
    }) {
        var d = !!b && !GM(),
            e = LK(new MK, !d);
        c = Ki(e, 14, c && navigator.globalPrivacyControl);
        a.g = c;
        d = [tO(a.pubWin, a.g, d), zO(a.pubWin), rO(a.pubWin, a.g)];
        d = await Promise.all(d);
        a = a.g;
        e = d[0];
        c = d[1];
        d = d[2];
        e && sO(a, e, b ? ? !1);
        c && (b = Pi(a, 1, c), c = c.toUpperCase(), c.length == 4 && (c.indexOf("-") == -1 || c.substring(1) === "---") && c[0] >= "1" && c[0] <= "9" && gL.hasOwnProperty(c[1]) && gL.hasOwnProperty(c[2]) && gL.hasOwnProperty(c[3]) ? (e = new fL, e = Mi(e, 1, parseInt(c[0], 10)), e = M(e, 2, gL[c[1]]), e = M(e, 3, gL[c[2]]), c =
            M(e, 4, gL[c[3]])) : c = null, c = c ? .Oi() === 2, Ki(b, 13, c));
        d && qO(a, d)
    };
    var BO = (a, b = !1) => {
        try {
            return b ? (new pd(a.innerWidth, a.innerHeight)).round() : Zd(a || window).round()
        } catch (c) {
            return new pd(-12245933, -12245933)
        }
    };

    function CO(a = q) {
        a = a.devicePixelRatio;
        return typeof a === "number" ? +a.toFixed(3) : null
    }

    function DO(a, b = q) {
        a = a.scrollingElement || (a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return new od(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function EO(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function FO(a, b) {
        var c = W,
            d;
        var e;
        d = (e = (e = Qj()) && (d = e.initialLayoutRect) && typeof d.top === "number" && typeof d.left === "number" && typeof d.width === "number" && typeof d.height === "number" ? new Mj(d.left, d.top, d.width, d.height) : null) ? new od(e.left, e.top) : (d = Tj()) && Da(d.rootBounds) ? new od(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            var f = new od(0, 0),
                g = Yd(b);
            var h = g ? g.defaultView : window;
            if (Rd(h, "parent")) {
                do {
                    if (h == a) var k = fk(b);
                    else {
                        var l = ek(b);
                        k = new od(l.left, l.top)
                    }
                    g = k;
                    f.x += g.x;
                    f.y += g.y
                } while (h && h != a && h != h.parent && (b = h.frameElement) && (h = h.parent))
            }
            return f
        } catch (m) {
            return c.ba(888, m), new od(-12245933, -12245933)
        }
    };

    function GO(a, b) {
        return Aj(a.win) ? !!b.g() : !1
    }

    function HO(a, b, c) {
        c ? (a = a.win, b = c.g() ? Cj(b, a) : null) : b = null;
        return b
    }

    function IO(a, b, c, d) {
        if (d) {
            var e = Ci(c, 2) - Date.now() / 1E3;
            e = {
                Cd: Math.max(e, 0),
                path: K(c, 3),
                domain: K(c, 4),
                Wd: !1
            };
            c = c.getValue();
            a = a.win;
            d.g() && Dj(b, c, e, a)
        }
    }

    function JO(a, b, c) {
        var d;
        (d = !c) || (d = a.win, d = !(c.g() && Cj(b, d)));
        if (!d)
            for (const f of KO(a.win.location.hostname)) {
                d = b;
                var e = a.win;
                c.g() && e.origin !== "null" && wj(new vj(e.document), d, "/", f)
            }
    }
    var LO = class {
        constructor(a) {
            this.win = a
        }
    };

    function KO(a) {
        if (a === "localhost") return ["localhost"];
        a = a.split(".");
        if (a.length < 2) return [];
        const b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };

    function MO(a, b, c) {
        var d = HO(a, "__gpi_opt_out", b);
        d && (d = Pi(Ni(ij(d), 2, 2147483647), 3, "/"), c = Pi(d, 4, c), IO(a, "__gpi_opt_out", c, b))
    }

    function NO(a, b, c, d) {
        const e = JM(a, "gpi-uoo", (f, g) => {
            if (g.source === c) {
                g = Pi(Ni(ij(f.userOptOut ? "1" : "0"), 2, 2147483647), 3, "/");
                g = Pi(g, 4, a.location.hostname);
                var h = new LO(a);
                IO(h, "__gpi_opt_out", g, b);
                if (f.userOptOut || f.clearAdsData) JO(h, "__gads", b), JO(h, "__gpi", b)
            }
        });
        d.push(e)
    };

    function OO(a) {
        return a.length ? a.join("~") : void 0
    };

    function PO(a, b) {
        return uC({
            K: a,
            lj: 3E3,
            qj: a.innerWidth > Sn ? 650 : 0,
            Z: dy,
            ai: b
        })
    };

    function QO(a) {
        let b = 0;
        try {
            b |= Tn(a)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function RO(a) {
        let b = 0;
        try {
            b |= Tn(a), b |= Vn(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function SO() {
        const a = {};
        cu(Kr) && (a.bust = cu(Kr));
        var b = GE();
        b = LE(b, 38, "");
        b !== "" && (a.sbust = b);
        return a
    };

    function TO(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function UO(a) {
        let b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function VO(a) {
        return a.hidden != null ? a.hidden : a.mozHidden != null ? a.mozHidden : a.webkitHidden != null ? a.webkitHidden : null
    }

    function WO(a, b) {
        if (TO(b) == 3) var c = !1;
        else a(), c = !0;
        if (!c) {
            const d = () => {
                Ib(b, "prerenderingchange", d);
                a()
            };
            Hb(b, "prerenderingchange", d)
        }
    };
    var XO = a => {
        let b = 0;
        try {
            b |= Tn(a);
            var c;
            if (!(c = !a.navigator)) {
                var d = a.navigator;
                c = "brave" in d && "isBrave" in d.brave || !1
            }
            b |= c || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            b |= Vn(a, 2500, !0)
        } catch (e) {
            b |= 32
        }
        return b
    };
    const YO = "body div footer header html main section".split(" ");

    function ZO(a, b, c = null, d = !1, e = !1, f = !1) {
        let g = Tn(a);
        vC(a.navigator ? .userAgent) && (g |= 1048576);
        const h = a.innerWidth;
        h < 1200 && (g |= 65536);
        const k = a.innerHeight;
        k < 650 && (g |= 2097152);
        c && g === 0 && (c = c === 3 ? "left" : "right", (b = $O({
            K: a,
            fj: b,
            Rj: 1,
            position: c,
            T: h,
            W: k,
            Gb: new Set,
            minWidth: 120,
            minHeight: 500,
            Re: d,
            jf: e,
            hf: f
        })) ? cA(a).sideRailPlasParam.set(c, `${b.width}x${b.height}_${String(c).charAt(0)}`) : g |= 16);
        return g
    }

    function aP(a) {
        a = cA(a).sideRailPlasParam;
        return [...Array.from(a.values())].join("|")
    }

    function bP(a, b) {
        return he(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c)) !== null
    }

    function cP(a, b) {
        return he(a, c => c.nodeType === Node.ELEMENT_NODE && b.getComputedStyle(c, null).position === "fixed")
    }

    function dP(a) {
        const b = [];
        for (const c of a.document.querySelectorAll("*")) {
            const d = a.getComputedStyle(c, null);
            d.position === "fixed" && d.display !== "none" && d.visibility !== "hidden" && b.push(c)
        }
        return b
    }

    function eP(a, b) {
        const {
            top: c,
            left: d,
            bottom: e,
            right: f
        } = b.getBoundingClientRect();
        return c >= 0 && d >= 0 && e <= a.innerHeight && f <= a.innerWidth
    }

    function fP(a) {
        return Math.round(Math.round(a / 10) * 10)
    }

    function gP(a) {
        return `${a.position}-${fP(a.T)}x${fP(a.W)}-${fP(a.scrollY+a.Sb)}Y`
    }

    function hP(a) {
        return `f-${gP({position:a.position,Sb:a.Sb,scrollY:0,T:a.T,W:a.W})}`
    }

    function iP(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return a !== Infinity ? a : 0
    }

    function jP(a, b, c) {
        const d = cA(c.K).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.W),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.T);
                for (var k = c.T * .3; f <= g; f += 10) {
                    if (e > 0 && h < k) {
                        var l = hP({
                            position: "left",
                            Sb: f,
                            T: c.T,
                            W: c.W
                        });
                        b.set(l, iP(b.get(l), h))
                    }
                    if (h < c.T && e > c.T - k) {
                        l = hP({
                            position: "right",
                            Sb: f,
                            T: c.T,
                            W: c.W
                        });
                        const m = c.T - e;
                        b.set(l, iP(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function kP(a, b) {
        const c = b.K,
            d = b.Re,
            e = b.hf;
        var f = `f-${fP(b.T)}x${fP(b.W)}`;
        a.has(f) || (a.set(f, 0), f = dP(c), d || e ? (lP(a, b, f.filter(g => eP(c, g))), mP(c, f.filter(g => !eP(c, g)).concat(e ? Array.from(c.document.querySelectorAll("[google-side-rail-overlap=false]")) : []))) : lP(a, b, f))
    }

    function lP(a, b, c) {
        var d = b.Gb;
        const e = b.K;
        cA(e).sideRailProcessedFixedElements.clear();
        d = new Set([...Array.from(e.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...d]);
        for (const f of c) bP(f, d) || jP(f, a, b)
    }

    function nP(a) {
        if (a.T < 1200 || a.W < 650) return null;
        var b = cA(a.K).sideRailAvailableSpace;
        a.fj || kP(b, {
            K: a.K,
            T: a.T,
            W: a.W,
            Gb: a.Gb,
            Re: a.Re,
            hf: a.hf
        });
        const c = [];
        var d = a.W * .9,
            e = bo(a.K),
            f = (a.W - d) / 2,
            g = f,
            h = d / 7;
        for (var k = 0; k < 8; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    r = b,
                    y = {
                        K: a.K,
                        T: a.T,
                        W: a.W,
                        Gb: a.Gb,
                        jf: a.jf
                    };
                const H = hP({
                        position: p,
                        Sb: n,
                        T: y.T,
                        W: y.W
                    }),
                    z = gP({
                        position: p,
                        Sb: n,
                        scrollY: e,
                        T: y.T,
                        W: y.W
                    });
                if (r.has(z)) {
                    n = iP(r.get(H), r.get(z));
                    break a
                }
                const I = p === "left" ? 20 : y.T - 20;
                let F = I;p = y.T * .3 / 5 * (p === "left" ? 1 : -1);
                for (let ba = 0; ba < 6; ba++) {
                    var D = oC(y.K.document, {
                            x: Math.round(F),
                            y: Math.round(n)
                        }),
                        E = bP(D, y.Gb),
                        G = cP(D, y.K);
                    if (!E && G !== null) {
                        jP(G, r, y);
                        r.delete(z);
                        break
                    }
                    E || (E = y, D.getAttribute("google-side-rail-overlap") === "true" ? E = !0 : D.getAttribute("google-side-rail-overlap") === "false" || E.jf && !YO.includes(D.tagName.toLowerCase()) ? E = !1 : (G = D.offsetHeight >= E.W * .25, E = D.offsetWidth >= E.T * .9 && G));
                    if (E) r.set(z, Math.round(Math.abs(F - I) + 20));
                    else if (F !== I) F -= p, p /= 2;
                    else {
                        r.set(z, 0);
                        break
                    }
                    F += p
                }
                n = iP(r.get(H), r.get(z))
            }
            m.call(l,
                n);
            g += h
        }
        b = a.Rj;
        e = a.position;
        d = Math.round(d / 8);
        f = Math.round(f);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l = 0; l < c.length; l++) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = m.length === 0 ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; n >= 0; n--) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = m.length === 0 ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: e,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) *
                        d),
                    offsetY: f + h[k] * d
                }, r = n.width >= g && n.height >= a, b === 0 && r) {
                m = n;
                break
            } else b === 1 && r && (!m || n.width * n.height > m.width * m.height) && (m = n);
        return m
    }

    function mP(a, b) {
        const c = cA(a);
        if (b.length && !c.g) {
            var d = new MutationObserver(() => {
                setTimeout(() => {
                    oP(a);
                    for (const e of c.sideRailMutationCallbacks) e()
                }, 500)
            });
            for (const e of b) d.observe(e, {
                attributes: !0
            });
            c.g = d
        }
    }

    function oP(a) {
        ({
            sideRailAvailableSpace: a
        } = cA(a));
        const b = Array.from(a.keys()).filter(c => c.startsWith("f-"));
        for (const c of b) a.delete(c)
    }

    function $O(a) {
        if (a.Ia) return a.Ia.vb(1228, () => nP(a)) || null;
        try {
            return nP(a)
        } catch {}
        return null
    };
    const pP = {
        [27]: 512,
        [26]: 128
    };
    var qP = (a, b, c, d) => {
            switch (c) {
                case 1:
                case 2:
                    return PO(a, c) === 0;
                case 3:
                case 4:
                    return ZO(a, !1, c, !0, U(zs), U(Mr)) === 0;
                case 8:
                    return XO(a) == 0;
                case 9:
                    return b = !(b.google_adtest === "on" || $K(a.location, "google_scr_debug")), !kH(a, b, d);
                case 30:
                    return aJ(a) == 0;
                case 26:
                    return RO(a) === 0;
                case 27:
                    return QO(a) === 0;
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        rP = (a, b, c, d) => {
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return PO(a, c);
                case 3:
                case 4:
                    return ZO(a, U(As), c, !1, U(zs));
                case 8:
                    return XO(a);
                case 9:
                    return kH(a, !(b.google_adtest === "on" || $K(a.location, "google_scr_debug")), d);
                case 16:
                    return nu(b, a) ? 0 : 8388608;
                case 30:
                    return aJ(a);
                case 26:
                    return RO(a);
                case 27:
                    return QO(a);
                default:
                    return 32
            }
        },
        sP = (a, b, c) => {
            const d = b.google_reactive_ad_format;
            if (!Kb(d)) return !1;
            a = se(a);
            if (!a || !qP(a, b, d, c)) return !1;
            b = cA(a);
            if (Zn(b, d)) return !1;
            b.adCount[d] || (b.adCount[d] = 0);
            b.adCount[d]++;
            return !0
        },
        uP = a => {
            const b = a.google_reactive_ad_format;
            return !a.google_reactive_ads_config && tP(a) && b !== 16 && b !== 10 && b !== 11 && b !== 40 && b !== 41
        },
        vP = a => {
            if (!a.hash) return null;
            let b = null;
            xe(XK, c => {
                !b && $K(a, c) && (b = YK[c])
            });
            return b
        },
        xP = (a, b) => {
            const c = cA(a).tagSpecificState[1] || null;
            c != null && c.debugCard == null && xe(ZK, d => {
                !c.debugCardRequested && typeof d === "number" && cL(d, a.location) && (c.debugCardRequested = !0, wP(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        zP = (a, b, c) => {
            if (!b) return null;
            const d = cA(b);
            let e = 0;
            xe(Lb, f => {
                const g = pP[f];
                g && yP(a, b, f, c) === 0 && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? "" + e : null
        },
        AP = (a, b, c) => {
            const d = [];
            xe(Lb, e => {
                const f = yP(b, a, e, c);
                f !== 0 && d.push(e + ":" + f)
            });
            return d.join(",") || null
        },
        BP = a => {
            const b = [],
                c = {};
            xe(a, (d, e) => {
                if ((e = Qn[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (d === !1) d = 2;
                    else return;
                    b.push(e + ":" + d)
                }
            });
            return b.join(",")
        },
        CP = a => {
            a = a.overlays;
            if (!a) return "";
            a = a.bottom;
            return typeof a === "boolean" ? a ? "1" : "0" : ""
        },
        yP = (a, b, c, d) => {
            if (!b) return 256;
            let e = 0;
            const f = cA(b),
                g = Zn(f, c);
            if (a.google_reactive_ad_format == c || g) e |= 64;
            let h = !1;
            xe(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) ===
                    String(l) && (h = !0)
            });
            return h && vP(b.location) !== c && (e |= 128, c == 2 || c == 1 || c == 3 || c == 4 || c == 8) ? e : e | rP(b, a, c, d)
        },
        DP = (a, b) => {
            if (a) {
                var c = cA(a),
                    d = {};
                xe(b, (e, f) => {
                    (f = Qn[f]) && (e === !1 || /^false$/i.test(e)) && (d[f] = !0)
                });
                xe(Lb, e => {
                    d[Rn[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        EP = (a, b, c) => {
            b = W.Ca(b, c);
            return VK(1, window, gd(a, new Map(Object.entries(SO())))).then(b)
        },
        wP = (a, b, c) => {
            c = W.Ca(212, c);
            VK(3, a, b).then(c)
        },
        FP = (a, b, c) => {
            a.dataset.adsbygoogleStatus = "reserved";
            a.className += " adsbygoogle-noablate";
            c.adsbygoogle ||
                (c.adsbygoogle = [], te(c.document, fd `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`));
            c.adsbygoogle.push({
                element: a,
                params: b
            })
        },
        GP = a => {
            a = a.google_reactive_ad_format;
            return Kb(a) ? "" + a : null
        },
        tP = a => !!GP(a) || a.google_pgb_reactive != null,
        HP = a => {
            a = GP(a);
            return a == 26 || a == 27 || a == 30 || a == 16 || a == 40 || a == 41
        };

    function IP(a) {
        return typeof a.google_reactive_sra_index === "number"
    }

    function JP(a, b, c) {
        const d = b.K || b.pubWin,
            e = b.D;
        var f = AP(d, e, c);
        e.google_reactive_plat = f;
        (f = BP(a)) && (e.google_reactive_plaf = f);
        (f = CP(a)) && (e.google_reactive_fba = f);
        (f = aP(d)) && (e.google_plas = f);
        KP(a, e);
        f = vP(b.pubWin.location);
        LP(a, f, e);
        f ? (e.fra = f, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        e.easpi = U(kt);
        e.asro = U(ft);
        e.aihb = U(Gs);
        e.ailel = OO(du(Ys));
        e.aiael = OO(du(Hs));
        e.aifxl = OO(du(Ts));
        e.aiixl = OO(du(Vs));
        U(Ws) && (e.slmct = V(Zs), e.samct = V(Ks));
        U(Ps) || (e.aiict = !0, e.aicel = OO(du(Ns)));
        U(dt) && (e.aipaq = !0);
        U(it) && (e.aigda = !0);
        V(Is) && (e.aiapm = V(Is));
        V(Js) && (e.aiapmi = V(Js));
        U(et) && (e.aiombap = !0);
        e.fsapi = !0;
        f !== 8 && (c && gH(c) ? (f = jH(c, 86400, "__lsv__"), f ? .length && (f = Math.floor((Date.now() - Math.max(...f)) / 6E4), f >= 0 && (e.vmsli = f))) : e.vmsli = -1);
        f = jH(c, 600, "__lsa__");
        f ? .length && Math.floor((Date.now() - Math.max(...f)) / 6E4) <= V(zr) && (e.dap = 3);
        Uj() || BO(b.pubWin.top);
        f = KM(b.pubWin, "rsrai", gy(429, (g, h) => MP(b, d, e.google_ad_client, a, g, h, c)), gy(430, (g, h) => fo(b.pubWin, "431", dy, h)));
        b.j.push(f);
        cA(d).wasReactiveTagRequestSent = !0;
        NP(b, a, c)
    }

    function NP(a, b, c) {
        const d = a.D,
            e = Da(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = KM(a.pubWin, "apcnf", gy(353, (f, g) => {
            const h = gd(a.wa.jb, new Map(Object.entries(SO())));
            var k = a.pubWin,
                l = d.google_ad_client;
            return Ue(g.origin) ? bN(k, l, e, f.config, c, h, null) : !1
        }), gy(353, (f, g) => fo(a.pubWin, "353", dy, g)));
        a.j.push(b)
    }

    function MP(a, b, c, d, e, f, g) {
        if (!Ue(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!WE(b, 1)) return !0;
        f && Ij(6, [f]);
        e = e.amaConfig;
        const h = [],
            k = [],
            l = cA(b);
        let m = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            const p = f[n],
                r = p.adFormat;
            l && p.enabledInAsfe && (l.reactiveTypeEnabledInAsfe[r] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (r === 9 && e) {
                    p.pubVars = Object.assign(p.pubVars || {}, OP(d, p));
                    const y = new lH;
                    if (eH(y, p) && y.C(p)) {
                        m = y;
                        continue
                    }
                }
                h.push(p);
                k.push(r)
            }
        }
        h.length && EP(a.wa.Zg,
            522, n => {
                PP(h, b, n, d, g)
            });
        e && bN(b, c, d, e, g, gd(a.wa.jb, new Map(Object.entries(SO()))), m);
        return !0
    }

    function OP(a, b) {
        const c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        const e = {};
        a = a.page_level_pubvars;
        Da(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        c === 30 && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function PP(a, b, c, d, e) {
        const f = [];
        for (let g = 0; g < a.length; g++) {
            const h = a[g],
                k = h.adFormat,
                l = h.adKey,
                m = c.configProcessorForAdFormat(k);
            k && m && l && (h.pubVars = OP(d, h), delete h.google_reactive_sra_index, f.push(k), fy(466, () => m.verifyAndProcessConfig(b, h, e)))
        }
    }

    function KP(a, b) {
        const c = [];
        let d = !1;
        xe(Qn, (e, f) => {
            let g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && c[e] !== "+" || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function LP(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if (a.google_adtest === "on" || d ? .google_adtest === "on" || b) c.google_adtest = "on"
        }
    };
    Qd("script");
    var QP = {
        "image-top": 0,
        "image-middle": 1,
        "image-side": 2,
        "text-only": 3,
        "in-article": 4
    };

    function RP(a, b) {
        if (!nu(b, a)) return () => {};
        a = SP(b, a);
        if (!a) return () => {};
        const c = SE();
        b = Nb(b);
        const d = {
            wb: a,
            D: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => cb(c, d)
    }

    function SP(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !su.test(a.className);) a = a.parentElement;
        return a
    }

    function TP(a, b) {
        for (let f = 0; f < a.childNodes.length; f++) {
            const g = {},
                h = a.childNodes[f];
            var c = h.style,
                d = ["width", "height"];
            for (let k = 0; k < d.length; k++) {
                const l = "google_ad_" + d[k];
                if (!g.hasOwnProperty(l)) {
                    var e = Fe(c[d[k]]);
                    e = e === null ? null : Math.round(e);
                    e != null && (g[l] = e)
                }
            }
            if (g.google_ad_width == b.google_ad_width && g.google_ad_height == b.google_ad_height) return h
        }
        return null
    }

    function UP(a, b) {
        a.style.display = b ? "inline-block" : "none";
        const c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function VP(a, b) {
        const c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.g != c) {
            a.g = c;
            a = SE();
            for (const d of a)
                if (d.wb.offsetWidth != d.offsetWidth || d.D.google_full_width_responsive_allowed) d.offsetWidth = d.wb.offsetWidth, fy(467, () => {
                    var e = d.wb,
                        f = d.D;
                    const g = TP(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? `${f.gfwroh}px` : "", e.style.width = f.gfwrow ? `${f.gfwrow}px` : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    b.google_spfd(e, f, b);
                    const h = TP(e, f);
                    !h && g && e.childNodes.length == 1 ? (UP(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", FP(e, f, b)) : h && g && h != g && (UP(g, !1), UP(h, !0))
                })
        }
    }
    var WP = class extends Q {
        constructor() {
            super(...arguments);
            this.g = null
        }
        J(a) {
            const b = GE();
            if (!LE(b, 27, !1)) {
                ME(b, 27, !0);
                this.g = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => {
                    VP(this, a)
                };
                Hb(a, "resize", c);
                xo(this, () => {
                    Ib(a, "resize", c)
                })
            }
        }
    };
    var XP = class {
        constructor(a, b) {
            this.K = a;
            this.wb = b;
            this.g = null;
            this.j = 0
        }
        i() {
            ++this.j >= 10 && q.clearInterval(this.g);
            var a = qu(this.K, this.wb);
            ru(this.K, this.wb, a);
            a = mu(this.wb, this.K);
            a != null && a.x === 0 || q.clearInterval(this.g)
        }
    };

    function YP(a) {
        var b = window;
        return a.google_adtest === "on" || a.google_adbreak_test === "on" || b.location.host.endsWith("h5games.usercontent.goog") || b.location.host === "gamesnacks.com" ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && c > 0) || [] : []
    };

    function ZP(a, b) {
        b && !a.g && (b = b.split(":"), a.g = b.find(c => c.indexOf("ID=") === 0) || null, a.j = b.find(c => c.indexOf("T=") === 0) ? .substring(2) || null)
    }
    var $P = class {
            constructor() {
                this.l = new Date(Date.now());
                this.j = this.g = null;
                this.i = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.i[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.l,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = b !== null ? ze(`${"w5uHecUBa2S"}:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.i[4] = {
                    [15]: () => {
                        var a = Number(this.j || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(a * 1E3), a = a.getFullYear() * 1E4 + (a.getMonth() + 1) * 100 + a.getDate());
                        return a
                    }
                }
            }
        },
        aQ;
    var bQ = class extends N {
        g() {
            return J(this, 10)
        }
    };
    var cQ = class extends N {
        g() {
            return Wh(this, 1, ch, w())
        }
    };
    var dQ = class extends N {},
        eQ = [13, 14];
    let fQ = void 0;

    function gQ() {
        ng(fQ, qg);
        return fQ
    }

    function hQ(a) {
        ng(fQ, tg);
        fQ = a
    };

    function iQ(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : Jb(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && typeof e === "string" && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function jQ(a = q) {
        return a.ggeac || (a.ggeac = {})
    };

    function kQ(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function lQ(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function mQ(a = navigator) {
        try {
            return !!a.protectedAudience ? .queryFeatureSupport ? .("deprecatedRenderURLReplacements")
        } catch (b) {
            return !1
        }
    };

    function nQ(a = we()) {
        return b => ze(`${b} + ${a}`) % 1E3
    };

    function oQ(a, b) {
        a.g = Bn(14, b, () => {})
    }
    class pQ {
        constructor() {
            this.g = () => {}
        }
    }

    function qQ(a) {
        O(pQ).g(a)
    };

    function rQ(a = jQ()) {
        Cn(O(Dn), a);
        sQ(a);
        oQ(O(pQ), a);
        O(bu).i()
    }

    function sQ(a) {
        const b = O(bu);
        b.j = (c, d) => Bn(5, a, () => !1)(c, d, 1);
        b.A = (c, d) => Bn(6, a, () => 0)(c, d, 1);
        b.B = (c, d) => Bn(7, a, () => "")(c, d, 1);
        b.g = (c, d) => Bn(8, a, () => [])(c, d, 1);
        b.l = (c, d) => Bn(17, a, () => [])(c, d, 1);
        b.i = () => {
            Bn(15, a, () => {})(1)
        }
    };

    function tQ(a, b, c) {
        var d = {
            [0]: nQ(Ye(b).toString())
        };
        if (c) {
            c = HO(new LO(b), "__gads", c) || "";
            aQ || (aQ = new $P);
            b = aQ;
            ZP(b, c);
            qQ(b.i);
            const e = (new RegExp(/(?:^|:)(ID=[^\s:]+)/)).exec(c) ? .[1];
            d[1] = f => e ? nQ(e)(f) : void 0
        }
        d = En(a, d);
        In.pa(1085, jF(O(hF), a, d))
    }

    function uQ(a, b) {
        tQ(20, a, b);
        tQ(17, a, b)
    }

    function vQ(a) {
        const b = O(Dn).g();
        a = YP(a);
        return b.concat(a).join(",")
    }

    function wQ(a) {
        const b = wk();
        b && (a.debug_experiment_id = b)
    };
    var xQ = class {
        constructor(a) {
            this.i = 0;
            this.g = this.I = null;
            this.H = 0;
            this.j = [];
            this.qc = this.C = "";
            this.A = this.G = null;
            this.F = !1;
            this.K = a.K;
            this.pubWin = a.pubWin;
            this.D = a.D;
            this.na = a.na;
            this.wa = a.wa;
            this.Wa = a.Wa;
            this.ea = a.ea
        }
    };

    function yQ(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : a >= 0 ? a : "-M"
    };
    var vg = {
        Tn: 0,
        Pn: 1,
        Qn: 9,
        Mn: 2,
        Nn: 3,
        Sn: 5,
        Rn: 7,
        On: 10
    };
    var zQ = class extends N {},
        AQ = Vi(zQ),
        BQ = [1, 3];
    const CQ = fd `https://securepubads.g.doubleclick.net/static/topics/topics_frame.html`;

    function DQ(a) {
        const b = a.google_tag_topics_state ? ? (a.google_tag_topics_state = {});
        return b.messageChannelSendRequestFn ? Promise.resolve(b.messageChannelSendRequestFn) : new Promise(c => {
            function d(h) {
                return g.g(h).then(({
                    data: k
                }) => k)
            }
            const e = ue("IFRAME");
            e.style.display = "none";
            e.name = "goog_topics_frame";
            e.src = dc(CQ).toString();
            const f = (new URL(CQ.toString())).origin,
                g = aN({
                    destination: a,
                    Oa: e,
                    origin: f,
                    we: "goog:gRpYw:doubleclick"
                });
            g.g("goog:topics:frame:handshake:ack").then(({
                data: h
            }) => {
                h === "goog:topics:frame:handshake:ack" &&
                    c(d)
            });
            b.messageChannelSendRequestFn = d;
            a.document.documentElement.appendChild(e)
        })
    }

    function EQ(a, b, c) {
        var d = W,
            e = U(Mt);
        const {
            Vc: f,
            Uc: g
        } = FQ(c);
        b = b.google_tag_topics_state ? ? (b.google_tag_topics_state = {});
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e
        }).then(h => {
            let k = g;
            if (h instanceof Uint8Array) k || (k = !(f instanceof Uint8Array && mb(h, f)));
            else if (ug()(h)) k || (k = h !== f);
            else return d.ba(989, Error(JSON.stringify(h))), 7;
            if (k && c) try {
                var l = new zQ;
                var m = Ni(l, 2, xk());
                h instanceof Uint8Array ? hi(m, 1, BQ, Uf(h, !1, !1)) : hi(m, 3, BQ, Hg(h));
                c.setItem("goog:cached:topics",
                    Si(m))
            } catch {}
            return h
        }), b.getTopicsPromise = a);
        return f && !g ? Promise.resolve(f) : b.getTopicsPromise
    }

    function FQ(a) {
        if (!a) return {
            Vc: null,
            Uc: !0
        };
        try {
            const l = a.getItem("goog:cached:topics");
            if (!l) return {
                Vc: null,
                Uc: !0
            };
            const m = AQ(l);
            let n;
            const p = ki(m, BQ);
            switch (p) {
                case 0:
                    n = null;
                    break;
                case 1:
                    a = m;
                    var b = ki(m, BQ) === 1 ? 1 : -1;
                    const y = a.U;
                    let D = y[v];
                    const E = Oh(y, D, b),
                        G = Uf(E, !0, !!(D & 34));
                    G != null && G !== E && Rh(y, D, b, G);
                    var c = G;
                    var d = c == null ? vf() : c;
                    b = Uint8Array;
                    uf(rf);
                    var e = d.g;
                    if (e == null || qf(e)) var f = e;
                    else {
                        if (typeof e === "string") {
                            nf.test(e) && (e = e.replace(nf, pf));
                            let H;
                            H = atob(e);
                            const z = new Uint8Array(H.length);
                            for (e = 0; e < H.length; e++) z[e] = H.charCodeAt(e);
                            var g = z
                        } else g = null;
                        f = g
                    }
                    var h = f;
                    var k = h == null ? h : d.g = h;
                    n = new b(k || 0);
                    break;
                case 3:
                    n = Ei(m, ki(m, BQ) === 3 ? 3 : -1);
                    break;
                default:
                    td(p, void 0)
            }
            const r = Ci(m, 2) + 6048E5 < xk();
            return {
                Vc: n,
                Uc: r
            }
        } catch {
            return {
                Vc: null,
                Uc: !0
            }
        }
    };

    function GQ(a) {
        return U(Ft) && a ? !!a.match(cu(Dt)) : !1
    }

    function HQ(a, b) {
        if (!U(Kt) && b.g()) {
            b = lQ("shared-storage", a.document);
            const c = lQ("browsing-topics", a.document);
            if (b || c) try {
                return DQ(a)
            } catch (d) {
                W.ba(984, d, void 0, void 0)
            }
        }
        return null
    }
    async function IQ(a, b, c, d, e, f) {
        if (lQ("browsing-topics", b.document) && e && !U(Jt) && !GQ(f ? .label))
            if (JQ(c, d)) {
                a.A = 1;
                const g = xj(c, b);
                c = e.then(async h => {
                    await EQ(h, b, g).then(k => {
                        a.A = k
                    })
                });
                U(Lt) && (d = V(Nt), d > 0 ? await Promise.race([c, $e(d)]) : await c)
            } else a.A = 5
    }

    function JQ(a, b) {
        return !b.google_restrict_data_processing && b.google_tag_for_under_age_of_consent !== 1 && b.google_tag_for_child_directed_treatment !== 1 && !!a.g() && !RE() && !J(a, 9) && !J(a, 13) && !J(a, 12) && (typeof b.google_privacy_treatments !== "string" || !b.google_privacy_treatments.split(",").includes("disablePersonalization")) && !J(a, 14)
    };
    var LQ = (a, b, c) => {
        const d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => KQ(d));
        return KM(a, "adpnt", (e, f) => {
            if (ao(f, c.contentWindow)) {
                e = eo(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), a.googletag.queryIds.length > 500 && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                e = !0
            } else e = !1;
            return e
        })
    };

    function KQ(a) {
        setTimeout(() => {
            a.dataset.adStatus !== "filled" && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };

    function MQ(a, b, {
        Wg: c,
        Xg: d
    }) {
        return !Aj(a.g) || J(b, 8) || (c || !b.g()) && d ? !1 : !0
    }

    function NQ(a, b, {
        Wg: c,
        Xg: d
    }) {
        if (!J(b, 8) && (!c && b.g() || !d)) return Cj("__eoi", a.g) ? ? void 0
    }
    var OQ = class {
        constructor(a) {
            this.g = a
        }
    };

    function PQ(a, b, c) {
        try {
            if (!Ue(c.origin) || !ao(c, a.g.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e;
        typeof d === "string" && (e = a.ta[d]) && a.Ia.vb(168, () => {
            e.call(a, b, c)
        })
    }
    class QQ extends Q {
        constructor(a, b) {
            var c = W,
                d = dy;
            super();
            this.j = a;
            this.g = b;
            this.Ia = c;
            this.Z = d;
            this.ta = {};
            this.Ea = this.Ia.Ca(168, (e, f) => void PQ(this, e, f));
            this.ib = this.Ia.Ca(169, (e, f) => fo(this.j, "ras::xsf", this.Z, f));
            this.ca = [];
            this.R(this.ta);
            this.ca.push(JM(this.j, "sth", this.Ea, this.ib))
        }
        i() {
            for (const a of this.ca) a();
            this.ca.length = 0;
            super.i()
        }
    };
    var RQ = class extends QQ {};

    function SQ(a, b, c = null) {
        return new TQ(a, b, c)
    }
    var TQ = class extends RQ {
        constructor(a, b, c) {
            super(a, b);
            this.A = c;
            this.C = O(hF);
            this.l = () => {};
            Hb(this.g, "load", this.l)
        }
        i() {
            Ib(this.g, "load", this.l);
            super.i()
        }
        R(a) {
            a["adsense-labs"] = b => {
                if (b = eo(b).settings)
                    if (b = Ui(kj, JSON.parse(b)), C(b, 1) != null) {
                        var c = b.U;
                        if (mi(c, c[v], jj, 4, 3, !1, !0).length > 0) {
                            var d = c = ni(b, jj, 4, w($f)),
                                e = this.C;
                            const h = new $l;
                            for (var f of d) switch (f.getVersion()) {
                                case 1:
                                    Ki(h, 1, !0);
                                    break;
                                case 2:
                                    Ki(h, 2, !0)
                            }
                            f = new am;
                            f = B(f, 1, bm, h);
                            nF(e, f);
                            f = this.j;
                            e = this.A;
                            if (!LE(GE(), 37, !1)) {
                                f = new LO(f);
                                for (var g of c) switch (g.getVersion()) {
                                    case 1:
                                        IO(f,
                                            "__gads", g, e);
                                        break;
                                    case 2:
                                        IO(f, "__gpi", g, e)
                                }
                                ME(GE(), 37, !0)
                            }
                            Qh(b, 4)
                        }
                        if (g = x(b, jj, 5)) c = this.j, LE(GE(), 40, !1) || (c = new OQ(c), f = Ci(g, 2) - Date.now() / 1E3, f = {
                            Cd: Math.max(f, 0),
                            path: K(g, 3),
                            domain: K(g, 4),
                            Wd: !1
                        }, Dj("__eoi", g.getValue(), f, c.g), ME(GE(), 40, !0));
                        Qh(b, 5);
                        g = this.j;
                        c = K(b, 1) || "";
                        if (PK({
                                win: g,
                                Ka: gQ()
                            }).g != null) {
                            f = PK({
                                win: g,
                                Ka: gQ()
                            });
                            f = f.g != null ? iQ(f.getValue()) : {};
                            b !== null && (f[c] = Ti(b));
                            try {
                                g.localStorage.setItem("google_adsense_settings", JSON.stringify(f))
                            } catch (h) {}
                        }
                    }
            }
        }
    };

    function UQ(a) {
        a.A = a.C;
        a.F.style.transition = "height 500ms";
        a.l.style.transition = "height 500ms";
        a.g.style.transition = "height 500ms";
        VQ(a)
    }

    function WQ(a, b) {
        a.g.contentWindow.postMessage(JSON.stringify({
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b,
            googMsgType: "sth"
        }), "*")
    }

    function VQ(a) {
        const b = `rect(0px, ${a.g.width}px, ${a.A}px, 0px)`;
        a.g.style.clip = b;
        a.l.style.clip = b;
        a.g.setAttribute("height", a.A);
        a.g.style.height = a.A + "px";
        a.l.setAttribute("height", a.A);
        a.l.style.height = a.A + "px";
        a.F.style.height = a.A + "px"
    }

    function XQ(a, b) {
        b = Ee(b.r_nh);
        a.C = b == null ? 0 : b;
        if (a.C <= 0) return "1";
        a.I = fk(a.F).y;
        a.H = bo(a.j);
        if (a.I + a.A < a.H) return "2";
        if (a.I > Xn(a.j) - a.j.innerHeight) return "3";
        b = a.H;
        a.g.setAttribute("height", a.C);
        a.g.style.height = a.C + "px";
        a.l.style.overflow = "hidden";
        a.F.style.position = "relative";
        a.F.style.transition = "height 100ms";
        a.l.style.transition = "height 100ms";
        a.g.style.transition = "height 100ms";
        b = Math.min(b + a.j.innerHeight - a.I, a.A);
        Yj(a.l, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.g.width}px, ${b}px, 0px)`;
        Yj(a.g, {
            clip: b
        });
        Yj(a.l, {
            clip: b
        });
        return "0"
    }
    class YQ extends RQ {
        constructor(a, b) {
            super(a.K, b);
            this.l = a.ea;
            this.F = this.l.parentElement && this.l.parentElement.classList.contains("adsbygoogle") ? this.l.parentElement : this.l;
            this.A = parseInt(this.l.style.height, 10);
            this.La = this.hb = !1;
            this.ia = this.H = this.C = 0;
            this.Oc = this.A / 5;
            this.I = fk(this.F).y;
            this.Bb = Db(gy(651, () => {
                this.I = fk(this.F).y;
                var c = this.H;
                this.H = bo(this.j);
                this.A < this.C ? (c = this.H - c, c > 0 && (this.ia += c, this.ia >= this.Oc ? (UQ(this), WQ(this, this.C)) : (this.A = Math.min(this.C, this.A + c), WQ(this, c), VQ(this)))) :
                    Ib(this.j, "scroll", this.O)
            }), this);
            this.O = () => {
                var c = this.Bb;
                rj.requestAnimationFrame ? rj.requestAnimationFrame(c) : c()
            }
        }
        R(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = eo(b);
                this.hb || (this.hb = !0, b = XQ(this, b), b === "0" && Hb(this.j, "scroll", this.O, Eb), c.source.postMessage(JSON.stringify({
                    msg_type: "expand-on-scroll-result",
                    eos_success: b === "0",
                    googMsgType: "sth"
                }), "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.La || (this.La = !0, UQ(this), Ib(this.j, "scroll", this.O))
            }
        }
        i() {
            this.O && Ib(this.j, "scroll", this.O, Eb);
            super.i()
        }
    };

    function ZQ(a) {
        const b = a.I.getBoundingClientRect(),
            c = b.top + b.height < 0;
        return !(b.top > a.j.innerHeight) && !c
    }
    class $Q extends Q {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.A = b;
            this.I = c;
            this.C = 0;
            this.l = ZQ(this);
            this.H = Cb(this.F, this);
            this.g = gy(433, () => {
                var d = this.H;
                rj.requestAnimationFrame ? rj.requestAnimationFrame(d) : d()
            });
            Hb(this.j, "scroll", this.g, Eb)
        }
        F() {
            const a = ZQ(this);
            if (a && !this.l) {
                var b = {
                    rr: "vis-bcr"
                };
                const c = this.A.contentWindow;
                c && (LM(c, "ig", b, "*", 2), ++this.C >= 10 && this.g && Ib(this.j, "scroll", this.g, Eb))
            }
            this.l = a
        }
    };

    function aR(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return typeof c === "string" ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        Yj(a, "transition", b.join(","))
    }
    var bR = Ab(function() {
        var a = ae(document, "DIV"),
            b = Vd ? "-webkit" : Ud ? "-moz" : Sd ? "-ms" : null,
            c = {
                transition: "opacity 1s linear"
            };
        b && (c[b + "-transition"] = "opacity 1s linear");
        c = {
            style: c
        };
        if (!Qc.test("div")) throw Error("");
        if ("DIV" in Sc) throw Error("");
        b = void 0;
        var d = "";
        if (c)
            for (h in c)
                if (Object.prototype.hasOwnProperty.call(c, h)) {
                    if (!Qc.test(h)) throw Error("");
                    var e = c[h];
                    if (e != null) {
                        var f = h;
                        if (e instanceof sb) e = vb(e);
                        else if (f.toLowerCase() == "style") {
                            if (!Da(e)) throw Error("");
                            if (!(e instanceof xc)) {
                                let k = "";
                                for (var g in e)
                                    if (Object.prototype.hasOwnProperty.call(e, g)) {
                                        if (!/^[-_a-zA-Z0-9]+$/.test(g)) throw Error(`Name allows only [-_a-zA-Z0-9], got: ${g}`);
                                        let l = e[g];
                                        l != null && (l = Array.isArray(l) ? l.map(Cc).join(" ") : Cc(l), k += `${g}:${l};`)
                                    }
                                e = k ? new xc(k) : Bc
                            }
                            e = yc(e)
                        } else {
                            if (/^on/i.test(f)) throw Error("");
                            if (f.toLowerCase() in Rc)
                                if (e instanceof cc) e = dc(e).toString();
                                else if (e instanceof mc) e = oc(e);
                            else if (typeof e === "string") e = tc(e).toString();
                            else throw Error("");
                        }
                        f = `${f}="` + Sb(String(e)) + '"';
                        d += " " + f
                    }
                }
        var h =
            "<div" + d;
        b == null ? b = [] : Array.isArray(b) || (b = [b]);
        Qb.div === !0 ? h += ">" : (g = Pc(b), h += ">" + Kc(g).toString() + "</div>");
        h = Mc(h);
        jd(a, h);
        return bk(a.firstChild, "transition") != ""
    });

    function cR(a, b, c) {
        a.i[b].indexOf(c) < 0 && (a.i[b] += c)
    }

    function dR(a, b) {
        a.g.indexOf(b) >= 0 || (a.g = b + a.g)
    }

    function eR(a, b, c, d) {
        return a.errors != "" || b ? null : a.g.replace(fR, "") == "" ? c != null && a.i[0] || d != null && a.i[1] ? !1 : !0 : !1
    }

    function gR(a) {
        var b = eR(a, "", null, 0);
        if (b === null) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return a.indexOf("a") >= 0 ? b + "A" : a.indexOf("f") >= 0 ? b + "F" : b + "S"
    }
    var hR = class {
        constructor(a, b) {
            this.i = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        va(a) {
            this.errors.indexOf(a) < 0 && (this.errors = a + this.errors);
            return this
        }
        toString() {
            return [this.i[0], this.i[1], this.g, this.errors].join("|")
        }
    };

    function iR(a) {
        let b = a.R;
        a.G = () => {};
        jR(a, a.B, b);
        let c = a.B.parentElement;
        if (!c) return a.g;
        let d = !0,
            e = null;
        for (; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : ve(c, b)
            } catch (g) {
                a.g.va("c")
            }
            const f = kR(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.O = !0);
            if (d && !f && lR(e)) {
                dR(a.g, "l");
                a.F = c;
                break
            }
            d = d && f;
            if (e && mR(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !pe(b)) {
                        dR(a.g, "c");
                        break
                    }
                } catch (g) {
                    dR(a.g,
                        "c");
                    break
                }
            }
        }
        a.C && a.A && nR(a);
        return a.g
    }

    function oR(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) Yj(k, m[n], "0px")
        }

        function c() {
            pR(d, g, h);
            !k || l || h || (b(qR), b(rR))
        }
        const d = a.B;
        d.style.overflow = a.Rc ? "visible" : "hidden";
        a.C && (a.F ? (aR(d, sR()), aR(a.F, sR())) : aR(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        a.I !== null && (d.style.opacity = String(a.I));
        const e = a.width != null && a.j != null && (a.Ud || a.j > a.width) ? a.j : null,
            f = a.height != null && a.i != null && (a.Ud || a.i > a.height) ? a.i : null;
        if (a.H) {
            const m =
                a.H.length;
            for (let n = 0; n < m; n++) pR(a.H[n], e, f)
        }
        const g = a.j,
            h = a.i,
            k = a.F,
            l = a.O;
        a.C ? q.setTimeout(c, 1E3) : c()
    }

    function tR(a) {
        if (a.A && !a.ca || a.j == null && a.i == null && a.I == null && a.A) return a.g;
        var b = a.A;
        a.A = !1;
        iR(a);
        a.A = b;
        if (!b || a.check != null && !eR(a.g, a.check, a.j, a.i)) return a.g;
        a.g.g.indexOf("n") >= 0 && (a.width = null, a.height = null);
        if (a.width == null && a.j !== null || a.height == null && a.i !== null) a.C = !1;
        (a.j == 0 || a.i == 0) && a.g.g.indexOf("l") >= 0 && (a.j = 0, a.i = 0);
        b = a.g;
        b.i[0] = "";
        b.i[1] = "";
        b.g = "";
        b.errors = "";
        oR(a);
        return iR(a)
    }

    function mR(a, b) {
        let c = !1;
        b.display == "none" && (dR(a.g, "n"), a.A && (c = !0));
        b.visibility != "hidden" && b.visibility != "collapse" || dR(a.g, "v");
        b.overflow == "hidden" && dR(a.g, "o");
        b.position == "absolute" ? (dR(a.g, "a"), c = !0) : b.position == "fixed" && (dR(a.g, "f"), c = !0);
        return c
    }

    function jR(a, b, c) {
        let d = 0;
        if (!b || !b.parentElement) return !0;
        let e = !1,
            f = 0;
        const g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = uR(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && cR(a.g, 0, "o"), d & 4 && cR(a.g, 1, "o"));
        return !(d & 1)
    }

    function kR(a, b, c, d) {
        let e = null;
        try {
            e = c.style
        } catch (D) {
            a.g.va("s")
        }
        var f = c.getAttribute("width"),
            g = Ee(f),
            h = c.getAttribute("height"),
            k = Ee(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = jR(a, c, b);
        var m = d && d.width;
        const n = d && d.height;
        var p = e && e.width,
            r = e && e.height,
            y = Fe(m) == a.width && Fe(n) == a.height;
        m = y ? m : p;
        r = y ? n : r;
        p = Fe(m);
        y = Fe(r);
        g = a.width !== null && (p !== null && a.width >= p || g !== null && a.width >= g);
        y = a.height !== null && (y !== null && a.height >= y || k !== null && a.height >= k);
        k = !b && lR(d);
        y = b || y || k || !(f ||
            m || d && (!vR(String(d.minWidth)) || !wR(String(d.maxWidth))));
        l = b || g || k || l || !(h || r || d && (!vR(String(d.minHeight)) || !wR(String(d.maxHeight))));
        xR(a, 0, y, c, "width", f, a.width, a.j);
        yR(a, 0, "d", y, e, d, "width", m, a.width, a.j);
        yR(a, 0, "m", y, e, d, "minWidth", e && e.minWidth, a.width, a.j);
        yR(a, 0, "M", y, e, d, "maxWidth", e && e.maxWidth, a.width, a.j);
        a.nf ? (c = /^html|body$/i.test(c.nodeName), f = Fe(n), h = d ? d.overflowY === "auto" || d.overflowY === "scroll" : !1, h = a.i != null && d && f && Math.round(f) !== a.i && !h && d.minHeight !== "100%", a.A && !c && h && (e.setProperty("height",
            "auto", "important"), d && !vR(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !wR(String(d.maxHeight)) && a.i && Math.round(f) < a.i && e.setProperty("max-height", "none", "important"))) : (xR(a, 1, l, c, "height", h, a.height, a.i), yR(a, 1, "d", l, e, d, "height", r, a.height, a.i), yR(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.i), yR(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.i));
        return b
    }

    function nR(a) {
        function b() {
            if (c > 0) {
                var l = ve(e, d) || {
                    width: 0,
                    height: 0
                };
                const m = Fe(l.width);
                l = Fe(l.height);
                m !== null && f !== null && h && h(0, f - m);
                l !== null && g !== null && h && h(1, g - l);
                --c
            } else q.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        let c = 31.25;
        const d = a.R,
            e = a.B,
            f = a.j,
            g = a.i,
            h = a.G;
        let k;
        q.setTimeout(() => {
            k = q.setInterval(b, 16)
        }, 990)
    }

    function uR(a, b, c) {
        if (b.nodeType == 3) return /\S/.test(b.data) ? 1 : 0;
        if (b.nodeType == 1) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = ve(b, c)
            } catch (e) {}
            if (d) {
                if (d.display == "none" || d.position == "fixed") return 0;
                if (d.position == "absolute") {
                    if (!a.l.boundingClientRect || d.visibility == "hidden" || d.visibility == "collapse") return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.l.boundingClientRect.left ? 2 : 0) | (c.bottom > a.l.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function xR(a, b, c, d, e, f, g, h) {
        if (h != null) {
            if (typeof f == "string") {
                if (f == "100%" || !f) return;
                f = Ee(f);
                f == null && (a.g.va("n"), cR(a.g, b, "d"))
            }
            if (f != null)
                if (c) {
                    if (a.A)
                        if (a.C) {
                            const k = Math.max(f + h - (g || 0), 0),
                                l = a.G;
                            a.G = (m, n) => {
                                m == b && sd(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else sd(d, e, String(h))
                } else cR(a.g, b, "d")
        }
    }

    function yR(a, b, c, d, e, f, g, h, k, l) {
        if (l != null) {
            f = f && f[g];
            typeof f != "string" || (c == "m" ? vR(f) : wR(f)) || (f = Fe(f), f == null ? dR(a.g, "p") : k != null && dR(a.g, f == k ? "E" : "e"));
            if (typeof h == "string") {
                if (c == "m" ? vR(h) : wR(h)) return;
                h = Fe(h);
                h == null && (a.g.va("p"), cR(a.g, b, c))
            }
            if (h != null)
                if (d && e) {
                    if (a.A)
                        if (a.C) {
                            const m = Math.max(h + l - (k || 0), 0),
                                n = a.G;
                            a.G = (p, r) => {
                                p == b && (e[g] = m - r + "px");
                                n && n(p, r)
                            }
                        } else e[g] = l + "px"
                } else cR(a.g, b, c)
        }
    }
    var DR = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.B = b;
            this.H = c;
            this.l = new zR(this.B);
            this.F = this.G = null;
            this.O = !1;
            this.R = (a = this.B.ownerDocument) && (a.defaultView || a.parentWindow);
            this.l = new zR(this.B);
            this.A = g;
            this.ca = AR(this.l, d.xf, d.height, d.Lc);
            this.width = this.A ? this.l.boundingClientRect ? this.l.boundingClientRect.right - this.l.boundingClientRect.left : null : e;
            this.height = this.A ? this.l.boundingClientRect ? this.l.boundingClientRect.bottom - this.l.boundingClientRect.top : null : f;
            this.j = BR(d.width);
            this.i = BR(d.height);
            this.I = this.A ? BR(d.opacity) : null;
            this.check = d.check;
            this.Lc = !!d.Lc;
            this.C = d.xf == "animate" && !CR(this.l, this.i, this.Lc) && bR();
            this.Rc = !!d.Rc;
            this.g = new hR;
            CR(this.l, this.i, this.Lc) && dR(this.g, "r");
            e = this.l;
            e.g && e.i >= e.W && dR(this.g, "b");
            this.Ud = !!d.Ud;
            this.nf = !!d.nf
        }
    };

    function CR(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.i + Math.min(b, BR(a.getHeight())), a = a.g && b >= a.W) : a = a.g && a.i >= a.W, d = a);
        return d
    }
    var zR = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && se(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            var d = a;
            let e = 0,
                f = this.boundingClientRect;
            for (; d;) try {
                f && (e += f.top);
                const g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.i = e;
            c = c || q;
            this.W = (c.document.compatMode == "CSS1Compat" ? c.document.documentElement : c.document.body).clientHeight;
            b = b && TO(b);
            this.visible = !!a && !(b == 2 || b == 3) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function AR(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return CR(a, c, d)
        }
    }

    function lR(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }

    function ER(a, b, c, d) {
        return tR(new DR(a, b, d, c, null, null, !0))
    }
    var FR = new hR("s", ""),
        fR = RegExp("[lonvafrbpEe]", "g");

    function wR(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function vR(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function pR(a, b, c) {
        b !== null && Ee(a.getAttribute("width")) !== null && a.setAttribute("width", String(b));
        c !== null && Ee(a.getAttribute("height")) !== null && a.setAttribute("height", String(c));
        b !== null && (a.style.width = b + "px");
        c !== null && (a.style.height = c + "px")
    }
    var qR = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        rR = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function sR() {
        let a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = qR;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = rR;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function BR(a) {
        return typeof a === "string" ? Ee(a) : typeof a === "number" && isFinite(a) ? a : null
    };
    var GR = class extends RQ {
        constructor(a, b, c) {
            super(a, b);
            this.l = c
        }
        R(a) {
            a["resize-me"] = (b, c) => {
                b = eo(b);
                var d = b.r_chk;
                if (d == null || d === "") {
                    var e = Ee(b.r_nw),
                        f = Ee(b.r_nh),
                        g = Ee(b.r_no);
                    g != null || e !== 0 && f !== 0 || (g = 0);
                    var h = b.r_str;
                    h = h ? h : null; {
                        var k = /^true$/.test(b.r_ao),
                            l = /^true$/.test(b.r_ifr),
                            m = /^true$/.test(b.r_cab);
                        const r = window;
                        if (r)
                            if (h === "no_rsz") b.err = "7", e = !0;
                            else {
                                var n = new zR(this.g);
                                if (n.g) {
                                    var p = n.getWidth();
                                    p != null && (b.w = p);
                                    p = n.getHeight();
                                    p != null && (b.h = p);
                                    AR(n, h, f, m) ? (n = this.l, d = ER(r, n, {
                                        width: e,
                                        height: f,
                                        opacity: g,
                                        check: d,
                                        xf: h,
                                        Rc: k,
                                        Ud: l,
                                        Lc: m
                                    }, [this.g]), b.r_cui && /^true$/.test(b.r_cui.toString()) && u(n, {
                                        height: (f === null ? 0 : f - 48) + "px",
                                        top: "24px"
                                    }), e != null && (b.nw = e), f != null && (b.nh = f), b.rsz = d.toString(), b.abl = gR(d), b.frsz = (h === "force").toString(), b.err = "0", e = !0) : (b.err = "1", e = !1)
                                } else b.err = "3", e = !1
                            }
                        else b.err = "2", e = !1
                    }
                    c.source.postMessage(JSON.stringify({
                        msg_type: "resize-result",
                        r_str: h,
                        r_status: e,
                        googMsgType: "sth"
                    }), "*");
                    this.g.dataset.googleQueryId || this.g.setAttribute("data-google-query-id",
                        b.qid)
                }
            }
        }
    };
    const HR = ["google_ad_client", "google_ad_format", "google_ad_height", "google_ad_width", "google_page_url"];

    function IR(a, b, c = null) {
        return c ? (c = xj(c, a)) ? new JR(a, b, c) : null : null
    }
    var JR = class extends RQ {
        constructor(a, b, c) {
            super(a, b);
            this.l = c
        }
        R(a) {
            a["survey-submitted"] = () => {
                const b = xk() + V(Cs) * 1E3;
                this.l.setItem("google_survey_fcap", String(b))
            }
        }
    };

    function KR(a, b) {
        return new IntersectionObserver(b, a)
    }

    function LR(a, b, c) {
        Hb(a, b, c);
        return () => Ib(a, b, c)
    }
    let MR = null;

    function NR() {
        MR = xk()
    }

    function OR(a, b) {
        return b ? MR === null ? (Hb(a, "mousemove", NR, {
            passive: !0
        }), Hb(a, "scroll", NR, {
            passive: !0
        }), NR(), !1) : xk() - MR >= b * 1E3 : !1
    }

    function PR({
        win: a,
        element: b,
        C: c,
        B: d,
        A: e = 0,
        Sa: f,
        i: g,
        g: h = {},
        l: k = !0,
        j: l = KR
    }) {
        let m, n = !1,
            p = !1;
        const r = [],
            y = l(h, (D, E) => {
                try {
                    const G = () => {
                        r.length || (d && (r.push(LR(b, "mouseenter", () => {
                            n = !0;
                            G()
                        })), r.push(LR(b, "mouseleave", () => {
                            n = !1;
                            G()
                        }))), r.push(LR(a.document, "visibilitychange", () => G())));
                        const H = OR(a, e),
                            z = VO(a.document);
                        if (p && !n && !H && !z) m = m || a.setTimeout(() => {
                            OR(a, e) ? G() : (f(), E.disconnect())
                        }, c * 1E3);
                        else if (k || n || H || z) a.clearTimeout(m), m = void 0
                    };
                    ({
                        isIntersecting: p
                    } = D[D.length - 1]);
                    G()
                } catch (G) {
                    g && g(G)
                }
            });
        y.observe(b);
        return () => {
            y.disconnect();
            for (const D of r) D();
            m != null && a.clearTimeout(m)
        }
    };

    function QR(a, b, c, d, e) {
        return new BU(a, b, c, d, e)
    }

    function CU(a, b, c) {
        const d = a.g,
            e = a.F;
        if (e != null && d != null && ao(c, d.contentWindow) && (b = b.config, typeof b === "string")) {
            try {
                var f = JSON.parse(b);
                if (!Array.isArray(f)) return;
                a.l = new lj(f)
            } catch (g) {
                return
            }
            a.dispose();
            f = Bi(a.l, 1);
            f <= 0 || (a.C = PR({
                win: a.j,
                element: e,
                C: f - .2,
                B: !ke(),
                A: Bi(a.l, 3),
                Sa: () => void DU(a, e),
                i: g => In.ba(1223, g, void 0, void 0),
                g: {
                    threshold: Di(a.l, 2, 1)
                },
                l: !0,
                j: void 0
            }))
        }
    }

    function DU(a, b) {
        a.H();
        setTimeout(In.Ca(1224, () => {
            a.A.rc = (parseInt(a.A.rc, 10) || 0) + 1;
            var c = b.parentElement || null;
            c && su.test(c.className) || (c = ae(document, "INS"), c.className = "adsbygoogle", b.parentNode && b.parentNode.insertBefore(c, b.nextSibling));
            U(ts) ? (EU(a, c, b), a.A.no_resize = !0, Io(xG(c), "filled", () => {
                be(b)
            })) : be(b);
            FP(c, a.A, a.j)
        }), 200)
    }

    function EU(a, b, c) {
        a.j.getComputedStyle(b).position == "static" && (b.style.position = "relative");
        c.style.position = "absolute";
        c.style.top = "0";
        c.style.left = "0";
        delete b.dataset.adsbygoogleStatus;
        delete b.dataset.adStatus;
        b.classList.remove("adsbygoogle-noablate")
    }
    var BU = class extends RQ {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.F = d;
            this.A = c;
            this.H = e;
            this.l = this.C = null;
            (b = (b = b.contentWindow) && b.parent) && a != b && this.ca.push(JM(b, "sth", this.Ea, this.ib))
        }
        R(a) {
            a.av_ref = (b, c) => CU(this, b, c)
        }
        i() {
            super.i();
            this.F = null;
            this.C && this.C()
        }
    };

    function FU(a) {
        if (U(us)) {
            var b = a.ea.parentElement || null;
            b && su.test(b.className) && Io(xG(b), "unfilled", () => {
                var c;
                if (c = U(us))
                    if (c = !LE(GE(), 42, !1)) {
                        a: switch (a.D.google_reactive_ad_format) {
                            case 0:
                            case 27:
                            case 40:
                                c = !0;
                                break a;
                            default:
                                c = !1
                        }
                        if (c = c && a.D.google_ad_width >= V(Ds) && (a.g ? GO(new LO(a.pubWin), a.g) : !1)) c = (c = a.g ? xj(a.g, a.pubWin) : null) ? (c.getItem("google_survey_fcap") ? Number(c.getItem("google_survey_fcap")) : 0) <= xk() : !1;
                        if (c) a: if (U(Qr) || Ld() || Kd()) c = !0;
                            else {
                                if (Od() && a.l && a.l.label) switch (a.l.label) {
                                    case "treatment_1.1":
                                    case "treatment_1.2":
                                    case "treatment_1.3":
                                    case "control_2":
                                        c = !0;
                                        break a
                                }
                                c = !1
                            }
                        c && (c = (c = P(a.pubWin)) ? b.getBoundingClientRect().top > c : !1)
                    }
                if (c) {
                    c = a.pubWin.document.createElement("ins");
                    var d = b.getAttribute("style");
                    d && c.setAttribute("style", d);
                    a.D.google_ad_height && (c.style.height = `${a.D.google_ad_height}px`);
                    (d = b.getAttribute("class")) && c.setAttribute("class", d);
                    (d = b.getAttribute("id")) && c.setAttribute("id", d);
                    b.replaceWith(c);
                    d = a.D;
                    const f = {};
                    for (var e of HR) d[e] && (f[e] = d[e]);
                    f.sso = !0;
                    FP(c, f, a.pubWin);
                    ME(GE(), 42, !0);
                    if (c = a.g ? xj(a.g, a.pubWin) : null) e = xk() + V(Bs) *
                        1E3, c.setItem("google_survey_fcap", String(e))
                }
            })
        }
    };
    const GU = /^blogger$/,
        HU = /^wordpress(.|\s|$)/i,
        IU = /^joomla!/i,
        JU = /^drupal/i,
        KU = /\/wp-content\//,
        LU = /\/wp-content\/plugins\/advanced-ads/,
        MU = /\/wp-content\/themes\/genesis/,
        NU = /\/wp-content\/plugins\/genesis/;

    function OU(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (LU.test(e)) return 5;
                if (NU.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", MU.test(e) || NU.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if (f.getAttribute("name") == "generator" && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (GU.test(f)) return 1;
                if (HU.test(f)) return 2;
                if (IU.test(f)) return 3;
                if (JU.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], d.getAttribute("rel") == "stylesheet" && d.hasAttribute("href") && (d = d.getAttribute("href") || "", KU.test(d))) return 2;
        return 0
    };
    var PU = {
        google_ad_block: "ad_block",
        google_ad_client: "client",
        google_ad_intent_query: "ait_q",
        google_ad_output: "output",
        google_ad_callback: "callback",
        google_ad_height: "h",
        google_ad_resize: "twa",
        google_ad_slot: "slotname",
        google_ad_unit_key: "adk",
        google_ad_dom_fingerprint: "adf",
        google_ad_intent_qetid: "aiqeid",
        google_placement_id: "pi",
        google_daaos_ts: "daaos",
        google_erank: "epr",
        google_ad_width: "w",
        abgtt: "abgtt",
        google_captcha_token: "captok",
        google_content_recommendation_columns_num: "cr_col",
        google_content_recommendation_rows_num: "cr_row",
        google_ctr_threshold: "ctr_t",
        google_cust_criteria: "cust_params",
        gfwrnwer: "fwrn",
        gfwrnher: "fwrnh",
        google_image_size: "image_size",
        google_last_modified_time: "lmt",
        google_loeid: "loeid",
        google_max_num_ads: "num_ads",
        google_max_radlink_len: "max_radlink_len",
        google_mtl: "mtl",
        google_native_settings_key: "nsk",
        google_enable_content_recommendations: "ecr",
        google_num_radlinks: "num_radlinks",
        google_num_radlinks_per_unit: "num_radlinks_per_unit",
        google_pucrd: "pucrd",
        google_reactive_plaf: "plaf",
        google_reactive_plat: "plat",
        google_reactive_fba: "fba",
        google_reactive_sra_channels: "plach",
        google_responsive_auto_format: "rafmt",
        armr: "armr",
        google_plas: "plas",
        google_rl_dest_url: "rl_dest_url",
        google_rl_filtering: "rl_filtering",
        google_rl_mode: "rl_mode",
        google_rt: "rt",
        google_video_play_muted: "vpmute",
        google_source_type: "src_type",
        google_restrict_data_processing: "rdp",
        google_tag_for_child_directed_treatment: "tfcd",
        google_tag_for_under_age_of_consent: "tfua",
        google_tag_origin: "to",
        google_ad_semantic_area: "sem",
        google_tfs: "tfs",
        google_package: "pwprc",
        google_tag_partner: "tp",
        fra: "fpla",
        google_ml_rank: "mlr",
        google_apsail: "psa",
        google_ad_channel: "channel",
        google_ad_type: "ad_type",
        google_ad_format: "format",
        google_color_bg: "color_bg",
        google_color_border: "color_border",
        google_color_link: "color_link",
        google_color_text: "color_text",
        google_color_url: "color_url",
        google_page_url: "url",
        google_ad_section: "region",
        google_cpm: "cpm",
        google_encoding: "oe",
        google_safe: "adsafe",
        google_font_face: "f",
        google_font_size: "fs",
        google_hints: "hints",
        google_ad_host: "host",
        google_ad_host_channel: "h_ch",
        google_ad_host_tier_id: "ht_id",
        google_kw_type: "kw_type",
        google_kw: "kw",
        google_contents: "contents",
        google_targeting: "targeting",
        google_adtest: "adtest",
        google_alternate_color: "alt_color",
        google_alternate_ad_url: "alternate_ad_url",
        google_cust_age: "cust_age",
        google_cust_gender: "cust_gender",
        google_cust_l: "cust_l",
        google_cust_lh: "cust_lh",
        google_language: "hl",
        google_city: "gcs",
        google_country: "gl",
        google_region: "gr",
        google_content_recommendation_ad_positions: "ad_pos",
        google_content_recommendation_ui_type: "crui",
        google_content_recommendation_use_square_imgs: "cr_sq_img",
        sso: "sso",
        google_color_line: "color_line",
        google_disable_video_autoplay: "disable_video_autoplay",
        google_full_width_responsive_allowed: "fwr",
        google_full_width_responsive: "fwrattr",
        efwr: "efwr",
        google_pgb_reactive: "pra",
        rc: "rc",
        google_resizing_allowed: "rs",
        google_resizing_height: "rh",
        google_resizing_width: "rw",
        rpe: "rpe",
        google_responsive_formats: "resp_fmts",
        google_safe_for_responsive_override: "sfro",
        google_video_doc_id: "video_doc_id",
        google_video_product_type: "video_product_type",
        google_webgl_support: "wgl",
        easpi: "easpi",
        aihb: "aihb",
        asro: "asro",
        ailel: "ailel",
        aiael: "aiael",
        aicel: "aicel",
        aifxl: "aifxl",
        aiixl: "aiixl",
        slmct: "aslmct",
        samct: "asamct",
        aiict: "aiict",
        aigda: "aifgd",
        aipaq: "aipaq",
        vmsli: "itsi",
        dap: "dap",
        aiapm: "aiapm",
        aiapmi: "aiapmi",
        aiombap: "aiombap"
    };

    function QU(a) {
        a.g === -1 && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var RU = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && a < 52 && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function SU() {
        const a = new RU;
        "SVGElement" in q && "createElementNS" in q.document && a.set(0);
        const b = Je();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        q.crypto && q.crypto.subtle && a.set(3);
        "TextDecoder" in q && "TextEncoder" in q && a.set(4);
        return QU(a)
    };
    const TU = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        UU = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function VU(a) {
        try {
            const b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return TU.get(b.type) ? ? null
        } catch {}
        return UU.get(a.performance ? .navigation ? .type) ? ? null
    };
    var WU = class extends N {
        constructor() {
            super()
        }
    };

    function XU(a, b) {
        if (Od()) {
            var c = a.document.documentElement.lang;
            YU(a) ? ZU(b, Ye(a), !0, "", c) : (new MutationObserver((d, e) => {
                YU(a) && (ZU(b, Ye(a), !1, c, a.document.documentElement.lang), e.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    }

    function YU(a) {
        a = a.document ? .documentElement ? .classList;
        return !(!a ? .contains("translated-rtl") && !a ? .contains("translated-ltr"))
    }

    function ZU(a, b, c, d, e) {
        pj({
            ptt: `${a}`,
            pvsid: `${b}`,
            ibatl: String(c),
            pl: d,
            nl: e
        }, "translate-event")
    };

    function $U(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const aV = /[+, ]/;

    function bV(a, b) {
        const c = a.D;
        var d = a.pubWin,
            e = {},
            f = d.document,
            g = af(d),
            h = !1,
            k = "",
            l = 1;
        a: {
            l = c.google_ad_width || d.google_ad_width;
            var m = c.google_ad_height || d.google_ad_height;
            if (d && d.top === d) h = !1;
            else {
                h = d.document;
                k = h.documentElement;
                if (l && m) {
                    var n = 1;
                    let r = 1;
                    d.innerHeight ? (n = d.innerWidth, r = d.innerHeight) : k && k.clientHeight ? (n = k.clientWidth, r = k.clientHeight) : h.body && (n = h.body.clientWidth, r = h.body.clientHeight);
                    if (r > 2 * m || n > 2 * l) {
                        h = !1;
                        break a
                    }
                }
                h = !0
            }
        }
        k = h;
        l = DE(g).Ye;
        m = d.top == d ? 0 : pe(d.top) ? 1 : 2;
        n = 4;
        k || m !== 1 ? k ||
            m !== 2 ? k && m === 1 ? n = 7 : k && m === 2 && (n = 8) : n = 6 : n = 5;
        l && (n |= 16);
        k = String(n);
        l = FE(d);
        m = !!c.google_page_url;
        e.google_iframing = k;
        l !== 0 && (e.google_iframing_environment = l);
        if (!m && f.domain === "ad.yieldmanager.com") {
            for (k = f.URL.substring(f.URL.lastIndexOf("http")); k.indexOf("%") > -1;) try {
                k = decodeURIComponent(k)
            } catch (r) {
                break
            }
            c.google_page_url = k;
            m = !!k
        }
        m ? (e.google_page_url = c.google_page_url, e.google_page_location = (h ? f.referrer : f.URL) || "EMPTY") : (h && pe(d.top) && f.referrer && d.top.document.referrer === f.referrer ? e.google_page_url =
            d.top.document.URL : e.google_page_url = h ? f.referrer : f.URL, e.google_page_location = null);
        if (f.URL === e.google_page_url) try {
            var p = Math.round(Date.parse(f.lastModified) / 1E3) || null
        } catch {
            p = null
        } else p = null;
        e.google_last_modified_time = p;
        d = g === g.top ? g.document.referrer : (d = Qj()) && d.referrer || "";
        e.google_referrer_url = d;
        EE(e, c);
        b.g() ? (e = c.google_page_location || c.google_page_url, "EMPTY" === e && (e = c.google_page_url), e ? (e = e.toString(), e.indexOf("http://") == 0 ? e = e.substring(7, e.length) : e.indexOf("https://") == 0 && (e = e.substring(8,
            e.length)), d = e.indexOf("/"), d === -1 && (d = e.length), e = e.substring(0, d).split("."), d = !1, e.length >= 3 && (d = e[e.length - 3] in eO), e.length >= 2 && (d = d || e[e.length - 2] in eO), e = d) : e = !1, e = e ? "pagead2.googlesyndication.com" : "googleads.g.doubleclick.net") : e = "pagead2.googlesyndication.com";
        b = cV(a, b);
        d = a.D;
        f = d.google_ad_channel;
        g = "/pagead/ads?";
        d.google_ad_client === "ca-pub-6219811747049371" && dV.test(f) && (g = "/pagead/lopri?");
        e = `https://${e}${g}`;
        a = J(a.na, 9) && c.google_debug_params ? c.google_debug_params : "";
        a = kk(b, e + a);
        return c.google_ad_url =
            a
    }

    function eV(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (a.nodeType === 9) a: {
            try {
                const c = a ? a.defaultView : window;
                if (c) {
                    const d = c.frameElement;
                    if (d && pe(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function fV(a, b) {
        var c = vQ(a.pubWin);
        a.D.saaei && (c += (c === "" ? "" : ",") + a.D.saaei);
        a.D.google_ad_intent_eids && (c += `${c===""?"":","}${a.D.google_ad_intent_eids}`);
        b.eid = c;
        c = a.D.google_loeid;
        typeof c === "string" && (a.i |= 4096, b.loeid = c)
    }

    function gV(a, b) {
        a = (a = se(a.pubWin)) && a.document ? DO(a.document, a) : new od(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function hV(a) {
        try {
            const b = q.top.location.hash;
            if (b) {
                const c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function iV(a, b, c) {
        const d = a.D;
        var e = a.pubWin,
            f = a.K,
            g = af(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = Qj(e)) && Da(h.data) && typeof h.data.type === "string" ? (h = h.data.type.toLowerCase(), h = h == "doubleclick" || h == "adsense" ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = DE(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.Ye || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.qc && (b.etu = a.qc);
        c = f ? xj(c, f) : null;
        (c = zP(d, f, c)) && (b.fc = c);
        if (!pk(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode &&
                (h = ie(new Xd(c), "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    const qa = h.contentWindow.document;
                    qa.open();
                    var k = Mc("<!DOCTYPE html>");
                    qa.write(Kc(k));
                    qa.close();
                    g += qa.documentMode
                } catch (qa) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        let l, m, n, p, r, y, D, E, G, H;
        try {
            l = e.screenX, m = e.screenY
        } catch (qa) {}
        try {
            n = e.outerWidth, p = e.outerHeight
        } catch (qa) {}
        try {
            r = e.innerWidth, y = e.innerHeight
        } catch (qa) {}
        try {
            D = e.screenLeft, E = e.screenTop
        } catch (qa) {}
        try {
            r =
                e.innerWidth, y = e.innerHeight
        } catch (qa) {}
        try {
            G = e.screen.availWidth, H = e.screen.availTop
        } catch (qa) {}
        b.brdim = [D, E, l, m, G, H, n, p, r, y].join();
        k = 0;
        q.postMessage === void 0 && (k |= 1);
        k > 0 && (b.osd = k);
        b.vis = TO(e.document);
        k = a.ea;
        e = tP(d) ? FR : tR(new DR(e, k, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = gR(e);
        if (!tP(d) && (e = qk(d), e != null)) {
            k = 0;
            a: {
                try {
                    {
                        var z = d.google_async_iframe_id;
                        const qa = window.document;
                        if (z) var I = qa.getElementById(z);
                        else {
                            var F = qa.getElementsByTagName("script"),
                                ba = F[F.length - 1];
                            I = ba && ba.parentNode || null
                        }
                    }
                    if (z = I) {
                        I = [];
                        F = 0;
                        for (var bb = Date.now(); ++F <= 100 && Date.now() - bb < 50 && (z = eV(z));) z.nodeType === 1 && I.push(z);
                        var xa = I;
                        b: {
                            for (bb = 0; bb < xa.length; bb++) {
                                c: {
                                    var fa = xa[bb];
                                    try {
                                        if (fa.parentNode && fa.offsetWidth > 0 && fa.offsetHeight > 0 && fa.style && fa.style.display !== "none" && fa.style.visibility !== "hidden" && (!fa.style.opacity || Number(fa.style.opacity) !== 0)) {
                                            const qa = fa.getBoundingClientRect();
                                            var la = qa.right > 0 && qa.bottom > 0;
                                            break c
                                        }
                                    } catch (qa) {}
                                    la = !1
                                }
                                if (!la) {
                                    var fb = !1;
                                    break b
                                }
                            }
                            fb = !0
                        }
                        if (fb) {
                            b: {
                                const qa = Date.now();fb = /^html|body$/i;la = /^fixed/i;
                                for (fa = 0; fa < xa.length && Date.now() - qa < 50; fa++) {
                                    const Md = xa[fa];
                                    if (!fb.test(Md.tagName) && la.test(Md.style.position || dk(Md, "position"))) {
                                        var gb = Md;
                                        break b
                                    }
                                }
                                gb = null
                            }
                            break a
                        }
                    }
                } catch {}
                gb = null
            }
            gb && gb.offsetWidth * gb.offsetHeight <= 4 * e.width * e.height && (k = 1);
            b.pfx = k
        }
        a: {
            if (Math.random() < .05 && f) try {
                const qa = f.document.getElementsByTagName("head")[0];
                var bg = qa ? OU(qa) : 0;
                break a
            } catch (qa) {}
            bg = 0
        }
        f = bg;
        f !== 0 && (b.cms = f);
        d.google_lrv !== a.Wa && (b.alvm = d.google_lrv ||
            "none")
    }

    function jV(a, b) {
        let c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : qe(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function kV(a, b) {
        const c = LE(b, 8, {});
        b = LE(b, 9, {});
        const d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function lV(a, b, c) {
        const d = a.D;
        var e = a.D;
        b.dt = Kn;
        e.google_async_iframe_id && e.google_bpp && (b.bpp = e.google_bpp);
        a: {
            try {
                var f = q.performance;
                if (f && f.timing && f.now) {
                    var g = f.timing.navigationStart + Math.round(f.now()) - f.timing.domLoading;
                    break a
                }
            } catch (m) {}
            g = null
        }(e = (e = g) ? yQ(e, q.Date.now() - Kn, 1E6) : null) && (b.bdt = e);
        b.idt = yQ(a.H, Kn);
        e = a.D;
        b.shv = K(a.na, 2);
        a.Wa && (b.mjsv = a.Wa);
        e.google_loader_used == "sd" ? b.ptt = 5 : e.google_loader_used == "aa" && (b.ptt = 9);
        /^\w{1,3}$/.test(e.google_loader_used) && (b.saldr = e.google_loader_used);
        if (e = Qj(a.pubWin)) b.is_amp = 1, b.amp_v = Rj(e), (e = Sj(e)) && (b.act = e);
        e = a.pubWin;
        e == e.top && (b.abxe = 1);
        e = new LO(a.pubWin);
        (g = HO(e, "__gads", c)) ? b.cookie = g: GO(e, c) && (b.cookie_enabled = "1");
        (g = HO(e, "__gpi", c)) && !g.includes("&") && (b.gpic = g);
        HO(e, "__gpi_opt_out", c) === "1" && (b.pdopt = "1");
        e = new OQ(a.pubWin);
        g = {
            Wg: !1,
            Xg: !a.F
        };
        (f = NQ(e, c, g)) ? b.eo_id_str = f: MQ(e, c, g) && (b.eoidce = "1");
        c = GE();
        g = LE(c, 8, {});
        e = d.google_ad_section;
        g[e] && (b.prev_fmts = g[e]);
        g = LE(c, 9, {});
        g[e] && (b.prev_slotnames = g[e].toLowerCase());
        kV(d, c);
        e = LE(c,
            15, 0);
        e > 0 && (b.nras = String(e));
        (g = Qj(window)) ? (g ? (e = g.pageViewId, g = g.clientId, typeof g === "string" && (e += g.replace(/\D/g, "").substr(0, 6))) : e = null, e = +e) : (e = af(window), g = e.google_global_correlator, g || (e.google_global_correlator = g = 1 + Math.floor(Math.random() * Math.pow(2, 43))), e = g);
        b.correlator = LE(c, 7, e);
        U(Vt) && (b.rume = 1);
        if (d.google_ad_channel) {
            e = LE(c, 10, {});
            g = "";
            f = d.google_ad_channel.split(aV);
            for (var h = 0; h < f.length; h++) {
                var k = f[h];
                e[k] ? g += k + "+" : e[k] = !0
            }
            b.pv_ch = g
        }
        if (d.google_ad_host_channel) {
            e = d.google_ad_host_channel;
            g = LE(c, 11, []);
            f = e.split("|");
            c = -1;
            e = [];
            for (h = 0; h < f.length; h++) {
                k = f[h].split(aV);
                g[h] || (g[h] = {});
                let m = "";
                for (let n = 0; n < k.length; n++) {
                    const p = k[n];
                    p !== "" && (g[h][p] ? m += "+" + p : g[h][p] = !0)
                }
                m = m.slice(1);
                e[h] = m;
                m !== "" && (c = h)
            }
            g = "";
            if (c > -1) {
                for (f = 0; f < c; f++) g += e[f] + "|";
                g += e[c]
            }
            b.pv_h_ch = g
        }
        b.frm = d.google_iframing;
        b.ife = d.google_iframing_environment;
        a: {
            c = d.google_ad_client;
            try {
                const m = af(window);
                let n = m.google_prev_clients;
                n || (n = m.google_prev_clients = {});
                if (c in n) {
                    var l = 1;
                    break a
                }
                n[c] = !0;
                l = 2;
                break a
            } catch {
                l =
                    0;
                break a
            }
            l = void 0
        }
        b.pv = l;
        a.K && U(xs) && (l = a.K, l = Od() && YU(l) ? l.document.documentElement.lang : void 0, l && (b.tl = l));
        U(ys) && a.pubWin.location.host.endsWith("h5games.usercontent.goog") && (b.cdm = a.pubWin.location.host);
        jV(a.pubWin, b);
        (a = d.google_ad_layout) && QP[a] >= 0 && (b.rplot = QP[a])
    }

    function mV(a, b) {
        var c = a.g;
        a = a.na;
        RE() && (b.npa = 1);
        J(a, 6) && !c ? .B() && (b.ltd_cs = 1);
        c && (c.B() && (b.gdpr = c.A() ? "1" : "0"), (a = C(c, 1)) && (b.us_privacy = a), (a = C(c, 2)) && (b.gdpr_consent = a), (a = C(c, 4)) && (b.addtl_consent = a), (a = Ai(c, 7)) && (b.tcfe = a), (a = K(c, 11)) && (b.gpp = a), (c = Wh(c, 10, Yg, w(), 0)) && c.length > 0 && (b.gpp_sid = c.join(",")))
    }

    function nV(a, b) {
        const c = a.D;
        mV(a, b);
        xe(PU, (d, e) => {
            b[d] = c[e]
        });
        tP(c) && (a = GP(c), b.fa = a);
        b.pi || c.google_ad_slot == null || (a = Jv(c), a.g != null && (a = Wp(a.getValue()), b.pi = a))
    }

    function oV(a, b) {
        var c = Uj() || BO(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = BO(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function pV(a, b) {
        var c = a.pubWin;
        c !== null && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = BO(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = ze(a.join(""))) : a = 0;
        a !== 0 && (b.ifk = a)
    }

    function qV(a, b) {
        (a = OE()[a.D.google_ad_client]) && (b.psts = a.join())
    }

    function rV(a, b) {
        (a = a.pubWin.tmod) && (b.tmod = a)
    }

    function sV(a, b) {
        (a = a.pubWin.google_user_agent_client_hint) && (b.uach = jf(a))
    }

    function tV(a, b) {
        try {
            const e = a.pubWin && a.pubWin.external && a.pubWin.external.getHostEnvironmentValue && a.pubWin.external.getHostEnvironmentValue.bind(a.pubWin.external);
            if (e) {
                var c = JSON.parse(e("os-mode")),
                    d = parseInt(c["os-mode"], 10);
                d >= 0 && (b.wsm = d + 1)
            }
        } catch {}
    }

    function uV(a, b) {
        a.D.google_ad_public_floor >= 0 && (b.pubf = a.D.google_ad_public_floor);
        a.D.google_ad_private_floor >= 0 && (b.pvtf = a.D.google_ad_private_floor)
    }

    function vV(a, b) {
        const c = Number(a.D.google_traffic_source);
        c && Object.values(Pa).includes(c) && (b.trt = a.D.google_traffic_source)
    }

    function wV(a, b) {
        var c;
        if (c = !U(au)) c = a.l ? .label, c = !(U(Ft) && c && c.match(cu(Dt)));
        c && ("runAdAuction" in a.pubWin.navigator && "joinAdInterestGroup" in a.pubWin.navigator && (b.td = 1), c = a.pubWin.navigator, a.pubWin.isSecureContext && "runAdAuction" in c && c.runAdAuction instanceof Function && lQ("run-ad-auction", a.pubWin.document) && (c = new RU, c.set(1, mQ(a.pubWin.navigator)), b.tdf = QU(c)))
    }

    function xV(a, b) {
        if (a.l != null && Od()) {
            var c = new WU,
                d = Qi(c, 3, a.l.label);
            M(d, 4, a.l.status);
            b.psd = jf(Si(c))
        }
    }

    function yV(a, b) {
        U(St) || lQ("attribution-reporting", a.pubWin.document) && (b.nt = 1)
    }

    function zV(a, b) {
        if (typeof a.D.google_privacy_treatments === "string") {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.D.google_privacy_treatments.split(",");
            var d = [];
            for (const [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function AV(a, b) {
        if (a.B) {
            a.B.bj && (b.xatf = 1);
            try {
                a.B.Qe ? .disconnect(), a.B.Qe = void 0
            } catch {}
        }
    }

    function cV(a, b) {
        const c = {};
        nV(a, c);
        sV(a, c);
        lV(a, c, b);
        c.u_tz = -(new Date).getTimezoneOffset();
        try {
            var d = rj.history.length
        } catch (e) {
            d = 0
        }
        c.u_his = d;
        c.u_h = rj.screen ? .height;
        c.u_w = rj.screen ? .width;
        c.u_ah = rj.screen ? .availHeight;
        c.u_aw = rj.screen ? .availWidth;
        c.u_cd = rj.screen ? .colorDepth;
        c.u_sd = CO(a.pubWin);
        c.dmc = a.pubWin.navigator ? .deviceMemory;
        fy(889, () => {
            if (a.K == null) c.adx = -12245933, c.ady = -12245933;
            else {
                var e = FO(a.K, a.ea);
                c.adx && c.adx != -12245933 && c.ady && c.ady != -12245933 || (c.adx = Math.round(e.x), c.ady = Math.round(e.y));
                EO(a.ea) || (c.adx = -12245933, c.ady = -12245933, a.i |= 32768)
            }
        });
        oV(a, c);
        pV(a, c);
        gV(a, c);
        fV(a, c);
        c.oid = 2;
        qV(a, c);
        c.pvsid = Ye(a.pubWin, W);
        rV(a, c);
        tV(a, c);
        c.uas = $U(a.pubWin);
        (d = VU(a.pubWin)) && (c.nvt = d);
        a.C && (c.scar = a.C);
        a.A instanceof Uint8Array ? c.topics = gf(a.A) : a.A && (c.topics = a.A, c.tps = a.A);
        AV(a, c);
        iV(a, c, b);
        c.fu = a.i;
        c.bc = SU();
        J(a.na, 9) && (wQ(c), c.creatives = hV(/\b(?:creatives)=([\d,]+)/), c.adgroups = hV(/\b(?:adgroups)=([\d,]+)/), c.adgroups || c.sso) && (c.adtest = "on", c.disable_budget_throttling = !0, c.use_budget_filtering = !1, c.retrieve_only = !0, c.disable_fcap = !0);
        Gj() && (c.atl = !0);
        c.bz = bf(a.pubWin);
        uV(a, c);
        vV(a, c);
        wV(a, c);
        xV(a, c);
        yV(a, c);
        zV(a, c);
        String(a.D.google_special_category_data) === "true" && (c.scd = 1);
        return c
    }
    const dV = /YtLoPri/;
    var BV = class extends N {};

    function CV(a) {
        return ni(a, BV, 15, w())
    }
    var DV = class extends N {},
        EV = Vi(DV);

    function FV() {
        var a = new GV;
        var b = new Mq;
        b = Qh(b, 2, Hg(4));
        b = Qh(b, 8, Hg(1));
        var c = new Sp;
        c = Pi(c, 7, "#dpId");
        b = A(b, 1, c);
        return qi(a, 3, Mq, b)
    }
    var GV = class extends N {},
        HV = Vi(GV);
    var IV = class extends N {};
    var JV = class extends N {},
        KV = Vi(JV);
    var LV = Symbol(),
        MV = Symbol();
    var NV = class {
        constructor(a) {
            this.Ob = a.Ob ? ? [];
            this.Sg = a.Sg ? ? .1;
            this.Ie = !!a.Ie;
            this.Ke = !!a.Ke;
            this.Jd = a.Jd ? ? 0;
            this.Id = a.Id ? ? 0;
            this.Zb = a.Zb ? ? 0;
            this.me = a.me ? ? "";
            this.Ra = a.Ra ? ? "";
            this.ne = a.ne ? ? 15E3;
            this.pe = a.pe ? ? 0;
            this.Je = a.Je ? ? !0;
            this.ye = a.ye || "#0B57D0";
            this.Xc = a.Xc || "#FFFFFF";
            this.Gd = a.Gd ? ? 0;
            this.Vb = !!a.Vb;
            this.Ne = a.Ne ? ? [];
            this.Ue = !!a.Ue;
            this.Fd = a.Fd ? ? 0;
            this.lf = a.lf ? ? !0;
            this.Ze = !!a.Ze;
            this.vf = a.vf ? ? !0
        }
    };

    function OV(a, b) {
        a = Gx(ev([...b], a), a);
        if (a.length !== 0) return a.reduce((c, d) => c.la.g > d.la.g ? c : d)
    };

    function PV(a, b, c, d, e, f, g, h) {
        var k = new Km,
            l = new km;
        c = Qi(l, 1, c);
        d = Qi(c, 2, d);
        b = L(d, 3, b);
        k = A(k, 1, b);
        b = new lm;
        b = Qi(b, 2, a.language);
        e = Qi(b, 3, e);
        e = A(k, 2, e);
        g = Oi(e, 3, Math.round(g));
        c = CV(f);
        e = k = b = d = 0;
        for (m of c) d += QV(K(m, 6) !== "") + QV(K(m, 7) !== ""), b += QV(K(m, 6) !== "") + QV(K(m, 7) !== ""), k += QV(K(m, 6) !== ""), e += QV(K(m, 7) !== "");
        var m = new ym;
        m = Li(m, 1, c.length);
        m = Li(m, 2, d);
        m = Qh(m, 3, b == null ? b : Lg(b));
        m = Qh(m, 4, k == null ? k : Lg(k));
        m = Qh(m, 5, e == null ? e : Lg(e));
        m = A(g, 6, m);
        if (h.length) f = new qm, f = oi(f, 1, h), B(m, 5, Lm, f);
        else {
            a.g = a.entries.length;
            h = new xm;
            a = a.entries;
            g = h.U;
            e = g[v];
            Yf(e);
            g = mi(g, e, wm, 2, 2, !1, !0);
            k = e = 0;
            if (Array.isArray(a))
                for (var n = 0; n < a.length; n++) b = a[n], g.push(b), (b = Lf(b.U)) && !e++ && (g[v] &= -9), b || k++ || (g[v] &= -17);
            else
                for (n of a) a = n, g.push(a), (a = Lf(a.U)) && !e++ && (g[v] &= -9), a || k++ || (g[v] &= -17);
            f = CV(f).length;
            f = Oi(h, 3, f);
            B(m, 4, Lm, f)
        }
        return m
    }

    function RV(a, b) {
        const c = a.g;
        a.g = a.entries.length;
        var d = new Rm,
            e = new xm;
        a = oi(e, 2, a.entries.slice(c));
        b = CV(b).length;
        b = Oi(a, 3, b);
        return A(d, 1, b)
    }
    var SV = class {
        constructor() {
            this.entries = [];
            this.language = null;
            this.g = 0
        }
    };

    function QV(a) {
        return a ? 1 : 0
    };
    async function TV(a, b) {
        await new Promise(c => void a.win.setTimeout(c, 0));
        a.i = a.g.ra(b) + a.j
    }
    var UV = class {
        constructor(a, b) {
            var c = V(qt);
            this.win = a;
            this.g = b;
            this.j = c;
            this.i = b.ra(2) + c
        }
    };
    var VV = class {
            constructor(a) {
                this.performance = a
            }
            ra() {
                return this.performance.now()
            }
        },
        WV = class {
            ra() {
                return Date.now()
            }
        };
    const XV = [255, 255, 255];

    function YV(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), d.length > 4 ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if (a === "transparent" || a === "") return [0, 0, 0, 0];
        throw Error(`Invalid color: ${a}`);
    }

    function ZV(a) {
        var b = getComputedStyle(a);
        if (b.backgroundImage !== "none") return null;
        b = YV(b.backgroundColor);
        var c = $V(b);
        if (c) return c;
        a = (a = a.parentElement) ? ZV(a) : XV;
        if (!a) return null;
        c = b[3];
        return [Math.round(c * b[0] + (1 - c) * a[0]), Math.round(c * b[1] + (1 - c) * a[1]), Math.round(c * b[2] + (1 - c) * a[2])]
    }

    function $V(a) {
        return a[3] === 1 ? [a[0], a[1], a[2]] : null
    };

    function aW(a) {
        return a.Ed > 0 && a.i.j >= a.Ed
    }
    var cW = class {
        constructor(a, b, c, d) {
            this.qf = b;
            this.re = c;
            this.Ed = d;
            this.g = 0;
            this.i = new bW(a)
        }
    };

    function dW(a, b) {
        b -= a.l;
        for (const c of a.g.keys()) {
            const d = a.g.get(c);
            let e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.i -= e;
            e > 0 && a.g.set(c, d.slice(e))
        }
    }

    function eW(a, b, c) {
        let d = [];
        a.g.has(b) && (d = a.g.get(b));
        d.push(c);
        a.i++;
        a.g.set(b, d)
    }
    class bW {
        constructor(a) {
            this.l = a;
            this.g = new Map;
            this.i = 0
        }
        get j() {
            return this.i
        }
    };

    function fW(a) {
        u(a, {
            border: "0",
            "box-shadow": "none",
            display: "inline",
            "float": "none",
            margin: "0",
            outline: "0",
            padding: "0"
        })
    };

    function gW(a, b) {
        a = hW(a, "100 -1000 840 840", `calc(${b} - 2px)`, b, "m784-120-252-252q-30 24-69 38t-83 14q-109 0-184.5-75.5t-75.5-184.5q0-109 75.5-184.5t184.5-75.5q109 0 184.5 75.5t75.5 184.5q0 44-14 83t-38 69l252 252-56 56zm-404-280q75 0 127.5-52.5t52.5-127.5q0-75-52.5-127.5t-127.5-52.5q-75 0-127.5 52.5t-52.5 127.5q0 75 52.5 127.5t127.5 52.5z");
        u(a, {
            color: "inherit",
            cursor: "inherit",
            fill: "currentcolor"
        });
        return a
    }

    function iW(a, b, c, d) {
        a = hW(a, "0 -960 960 960", b, b, jW[d]);
        u(a, {
            fill: c || "white",
            cursor: "inherit"
        });
        a.classList.add("google-anno-sa-intent-icon");
        return a
    }

    function kW(a, b, c) {
        a = hW(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        u(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: "15px",
            transform: "none",
            fill: c ? "#1A73E8" : "white"
        });
        a.role = "button";
        a.ariaLabel = b;
        a.tabIndex = 0;
        return a
    }
    const jW = {
        [0]: "M503-104q-24 24-57 24t-57-24L103-390q-23-23-23-56.5t23-56.5l352-353q11-11 26-17.5t32-6.5h286q33 0 56.5 23.5T879-800v286q0 17-6.5 32T855-456L503-104Zm196-536q25 0 42.5-17.5T759-700q0-25-17.5-42.5T699-760q-25 0-42.5 17.5T639-700q0 25 17.5 42.5T699-640ZM446-160l353-354v-286H513L160-446l286 286Zm353-640Z",
        [1]: "m274-274-128-70 42-42 100 14 156-156-312-170 56-56 382 98 157-155q17-17 42.5-17t42.5 17q17 17 17 42.5T812-726L656-570l98 382-56 56-170-312-156 156 14 100-42 42-70-128Z",
        [2]: "M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z",
        [3]: "M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm200-500 54-18 16-54q-32-48-77-82.5T574-786l-54 38v56l160 112Zm-400 0 160-112v-56l-54-38q-54 17-99 51.5T210-652l16 54 54 18Zm-42 308 46-4 30-54-58-174-56-20-40 30q0 65 18 118.5T238-272Zm242 112q26 0 51-4t49-12l28-60-26-44H378l-26 44 28 60q24 8 49 12t51 4Zm-90-200h180l56-160-146-102-144 102 54 160Zm332 88q42-50 60-103.5T800-494l-40-28-56 18-58 174 30 54 46 4Z",
        [4]: "M120-680v-160l160 80-160 80Zm600 0v-160l160 80-160 80Zm-280-40v-160l160 80-160 80Zm0 640q-76-2-141.5-12.5t-114-26.5Q136-135 108-156t-28-44v-360q0-25 31.5-46.5t85.5-38q54-16.5 127-26t156-9.5q83 0 156 9.5t127 26q54 16.5 85.5 38T880-560v360q0 23-28 44t-76.5 37q-48.5 16-114 26.5T520-80v-160h-80v160Zm40-440q97 0 167.5-11.5T760-558q0-5-76-23.5T480-600q-128 0-204 18.5T200-558q42 15 112.5 26.5T480-520ZM360-166v-154h240v154q80-8 131-23.5t69-27.5v-271q-55 22-138 35t-182 13q-99 0-182-13t-138-35v271q18 12 69 27.5T360-166Zm120-161Z",
        [5]: "M200-80q-33 0-56.5-23.5T120-160v-480q0-33 23.5-56.5T200-720h80q0-83 58.5-141.5T480-920q83 0 141.5 58.5T680-720h80q33 0 56.5 23.5T840-640v480q0 33-23.5 56.5T760-80H200Zm0-80h560v-480H200v480Zm280-240q83 0 141.5-58.5T680-600h-80q0 50-35 85t-85 35q-50 0-85-35t-35-85h-80q0 83 58.5 141.5T480-400ZM360-720h240q0-50-35-85t-85-35q-50 0-85 35t-35 85ZM200-160v-480 480Z",
        [6]: "M80-160v-120h80v-440q0-33 23.5-56.5T240-800h600v80H240v440h240v120H80Zm520 0q-17 0-28.5-11.5T560-200v-400q0-17 11.5-28.5T600-640h240q17 0 28.5 11.5T880-600v400q0 17-11.5 28.5T840-160H600Zm40-120h160v-280H640v280Zm0 0h160-160Z",
        [7]: "M400-40v-80H200q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h200v-80h80v880h-80ZM200-240h200v-240L200-240Zm360 120v-360l200 240v-520H560v-80h200q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H560Z",
        [8]: "M300-240q25 0 42.5-17.5T360-300q0-25-17.5-42.5T300-360q-25 0-42.5 17.5T240-300q0 25 17.5 42.5T300-240Zm0-360q25 0 42.5-17.5T360-660q0-25-17.5-42.5T300-720q-25 0-42.5 17.5T240-660q0 25 17.5 42.5T300-600Zm180 180q25 0 42.5-17.5T540-480q0-25-17.5-42.5T480-540q-25 0-42.5 17.5T420-480q0 25 17.5 42.5T480-420Zm180 180q25 0 42.5-17.5T720-300q0-25-17.5-42.5T660-360q-25 0-42.5 17.5T600-300q0 25 17.5 42.5T660-240Zm0-360q25 0 42.5-17.5T720-660q0-25-17.5-42.5T660-720q-25 0-42.5 17.5T600-660q0 25 17.5 42.5T660-600ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z",
        [9]: "M160-80v-440H80v-240h208q-5-9-6.5-19t-1.5-21q0-50 35-85t85-35q23 0 43 8.5t37 23.5q17-16 37-24t43-8q50 0 85 35t35 85q0 11-2 20.5t-6 19.5h208v240h-80v440H160Zm400-760q-17 0-28.5 11.5T520-800q0 17 11.5 28.5T560-760q17 0 28.5-11.5T600-800q0-17-11.5-28.5T560-840Zm-200 40q0 17 11.5 28.5T400-760q17 0 28.5-11.5T440-800q0-17-11.5-28.5T400-840q-17 0-28.5 11.5T360-800ZM160-680v80h280v-80H160Zm280 520v-360H240v360h200Zm80 0h200v-360H520v360Zm280-440v-80H520v80h280Z"
    };

    function hW(a, b, c, d, e) {
        const f = a.document.createElementNS("http://www.w3.org/2000/svg", "path");
        f.setAttribute("d", e);
        e = a.document.createElementNS("http://www.w3.org/2000/svg", "svg");
        u(e, pr(a));
        e.setAttribute("viewBox", b);
        e.setAttribute("width", c);
        e.setAttribute("height", d);
        fW(e);
        e.appendChild(f);
        return e
    };

    function lW(a, b, c, d) {
        const e = document.createElement("DIV");
        e.classList.add("google-anno-skip", "google-anno-sc");
        d = a.getComputedStyle(d).fontSize || "16px";
        var f = e.appendChild,
            g = iW(a, d, b.L.Xc, b.g.get(c) || 0);
        u(g, {
            position: "relative",
            top: "3px"
        });
        const h = document.createElement("SPAN");
        u(h, {
            display: "inline-block",
            "padding-left": b.X() ? "" : "3px",
            "padding-right": b.X() ? "3px" : ""
        });
        h.appendChild(g);
        f.call(e, h);
        f = e.appendChild;
        g = a.document.createElement("SPAN");
        g.appendChild(a.document.createTextNode(c));
        u(g, {
            position: "relative",
            left: b.X() ? "" : "3px",
            right: b.X() ? "3px" : "",
            "padding-left": b.X() ? "6px" : "",
            "padding-right": b.X() ? "" : "6px"
        });
        f.call(e, g);
        u(e, {
            display: "inline-block",
            "border-radius": "20px",
            "padding-left": b.X() ? "7px" : "6px",
            "padding-right": b.X() ? "6px" : "7px",
            "padding-top": "3px",
            "padding-bottom": "3px",
            "border-width": "1px",
            "border-style": "solid",
            color: b.L.Xc,
            "font-family": "Roboto",
            "font-weight": "500",
            "font-size": d,
            "border-color": "#D7D7D7",
            background: b.L.ye,
            cursor: "pointer"
        });
        e.tabIndex = 0;
        e.role = "link";
        e.ariaLabel = c;
        return e
    };

    function mW(a, b) {
        return K(a, 10).replace("TERM", b)
    };
    const nW = [{
        rf: "1907259590",
        Kd: 480,
        Pc: 220
    }, {
        rf: "2837189651",
        Kd: 400,
        Pc: 180
    }, {
        rf: "9211025045",
        Kd: 360,
        Pc: 160
    }, {
        rf: "6584860439",
        Kd: -Infinity,
        Pc: 150
    }];

    function oW(a) {
        return nW.find(b => b.Kd <= a)
    };

    function pW(a, b, c, d, e, f, g, h, k) {
        const l = k(999, a.top, m => {
            m.data.action === "init" && m.data.adChannel === "ShoppingVariant" && qW(a, b, d, c, e, f, g, h)
        });
        g(() => {
            a.top.removeEventListener("message", l)
        })
    }

    function qW(a, b, c, d, e, f, g, h) {
        J(f, 13) || aA(c, d, e);
        const k = b.contentDocument.documentElement,
            l = new ResizeObserver(() => {
                b.height = `${Math.ceil(k.offsetHeight+22)}px`
            });
        l.observe(k);
        const m = h(1066, a, () => {
            const n = k.offsetHeight;
            n && (b.height = `${n+22}px`)
        }, 1E3);
        g(() => {
            l.disconnect();
            a.clearInterval(m)
        })
    }
    var rW = class {
        Xf(a) {
            const b = a.win.document.createElement("iframe"),
                c = a.V,
                d = new bA(b, K(c, 16), "anno-cse", a.Jc.replace("ca", "partner"), "ShoppingVariant", a.win.location, K(c, 7), mW(c, a.Ha), a.L.Ob.filter(e => e !== 42), !1, void 0, !0, void 0, !0, a.Jc);
            d.J();
            pW(a.win, b, a.Ha, d, a.Oj, c, a.Fj, a.Yd, a.ke);
            return b
        }
    };
    var sW = class {
        Xf(a) {
            const b = a.ma ? .95 * a.win.innerHeight - 30 : a.win.innerHeight;
            var c = a.Ha;
            var d = a.Ei || "",
                e = a.Jc,
                f = a.Ai,
                g = a.X,
                h = !!J(a.V, 13),
                k = a.L.Ne.join(",");
            const l = a.L.lf;
            var m = uz;
            g = "<style>#gda-search-term {height: 24px; font-size: 18px; font-weight: 500; color: #202124; font-family: 'Google Sans Text'; padding-bottom: 6px;" + (g ? "padding-right: 16px;" : "padding-left: 16px;") + '}</style><div id="gda-search-term">' + sz(c) + "</div>";
            h ? d = "" : (d = "<script data-ad-intent-query=" + Fz(c) + " data-ad-intent-qetid=" +
                Fz(d) + " data-ad-intent-eids=" + Fz(k) + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=', k = encodeURIComponent(String(e)), Iz.lastIndex = 0, k = Iz.test(k) ? k.replace(Iz, Jz) : k, d = d + k + '" crossorigin="anonymous">\x3c/script>');
            c = m(g + d + '<ins class="adsbygoogle" style="display:inline-block;width:' + Dz(X(f)) + "px;height:" + Dz(X(b - 30)) + 'px" data-ad-client="' + Dz(e) + '"></ins>' + (l ? "<script>(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + (h ? "<script>const el = document.querySelector('ins.adsbygoogle'); el.dir = 'ltr'; el.style.backgroundColor = 'lightblue'; el.style.fontSize = '25px'; el.style.textDecoration = 'none'; el.textContent = \"Loading display ads inside this slot for query = " +
                String(c).replace(Qz, Nz) + ' and " + "property code = ' + String(e).replace(Qz, Nz) + '";\x3c/script>' : ""));
            c = cd({
                dir: a.X ? "rtl" : "ltr",
                lang: K(a.V, 7),
                style: "margin:0px;height:100%;padding-top: 0px;overflow: hidden;"
            }, pz(c));
            a = a.win.document.createElement("IFRAME");
            u(a, {
                border: "0",
                width: "100%",
                height: b + "px"
            });
            a.srcdoc = Kc(c);
            return a
        }
    };
    const tW = new class {
        constructor() {
            this.g = []
        }
    };
    let uW = !1;

    function vW(a) {
        wW(a.config, 1065, a.win, () => {
            if (!a.g) {
                var b = new Wm;
                b = Oi(b, 1, a.i);
                var c = new Vm;
                b = B(b, 2, Xm, c);
                xW(a.config.M, b)
            }
        }, 1E4)
    }
    class yW {
        constructor(a, b, c) {
            this.win = a;
            this.config = b;
            this.i = c;
            this.g = !1
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function zW(a) {
        tW.g.push(a)
    }

    function AW(a, b, c, d, e, f, g = null) {
        const h = oW(a.document.body.clientWidth);
        d = b.ma ? BW(a, b, d, e, f, g) : CW(a, b, d, h, e, f, g);
        Jo(d.isVisible(), !1, () => {
            uW = !1;
            for (const l of tW.g) l();
            tW.g.length = 0
        });
        d.show({
            hg: !0
        });
        uW = !0;
        const k = new yW(a, b, c);
        vW(k);
        tW.g.push(() => {
            var l = b.M;
            var m = new Wm;
            m = Oi(m, 1, c);
            var n = new Um;
            m = B(m, 3, Xm, n);
            xW(l, m);
            k.g = !0
        })
    }

    function BW(a, b, c, d, e, f) {
        d = DW(a, b, c, d, e, f, a.innerWidth);
        return FB(a, d, {
            Tg: .95,
            pg: .95,
            zIndex: 2147483647,
            oc: !0,
            Ge: "adpub-drawer-root",
            Fe: !1,
            Na: !0,
            Le: new R(mW(b.V, c))
        })
    }

    function CW(a, b, c, d, e, f, g) {
        a: {
            var h = b.L,
                k = a.document.body.clientWidth;
            if (h.Gd) d = Math.min(k, h.Gd);
            else {
                h = k * .9;
                for (k = k <= 768 ? 3 : 4; k >= 1; k--) {
                    const l = d.Pc * k + 42;
                    if (l <= h) {
                        d = l;
                        break a
                    }
                }
                d = h
            }
        }
        e = DW(a, b, c, e, f, g, d);
        return PA(a, e, {
            md: `${d}px`,
            jd: b.X(),
            Yc: K(b.V, 14),
            zIndex: 2147483647,
            oc: !0,
            jg: !0,
            Ge: "adpub-drawer-root",
            Fe: !1,
            Na: !0,
            Le: new R(mW(b.V, c))
        })
    }

    function DW(a, b, c, d, e, f, g) {
        let h;
        e === LV ? b.L.Vb ? h = new sW : h = new rW : h = e;
        return h.Xf({
            win: a,
            Ha: c,
            Oj: d,
            L: b.L,
            ma: b.ma,
            Jc: b.Jc,
            X: b.X(),
            V: b.V,
            Ei: f,
            Ai: g,
            ke: b.ke.bind(b),
            Yd: b.Yd.bind(b),
            Fj: zW
        })
    };

    function EW(a, b, c, d) {
        a = vm(um(new wm, a), 1);
        b = Qi(a, 4, b);
        c = Pi(b, 11, c);
        return Li(c, 12, d)
    }

    function FW(a, b, c) {
        b = b.getBoundingClientRect();
        a = vm(um(new wm, a), 3);
        c = Qi(a, 4, c);
        c = Mi(c, 6, Math.round(b.x));
        return Mi(c, 7, Math.round(b.y))
    }

    function GW(a) {
        a = YV(a);
        var b = new sm;
        b = Mi(b, 1, a[0]);
        b = Mi(b, 2, a[1]);
        b = Mi(b, 3, a[2]);
        return ei(b, 4, Cg(a[3]), 0)
    };
    const HW = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function IW(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return a === "" || HW.test(a)
        }
    };

    function JW(a, b) {
        const c = new KW(b);
        for (const d of a) K(d, 5) && Wh(d, 3, ch, w()).forEach(e => {
            LW(c, e, e)
        });
        MW(c);
        return new NW(c)
    }

    function OW(a, b) {
        b = a.match(b);
        a = new Map;
        for (const c of b)
            if (b = c.j, a.has(b)) {
                const d = a.get(b);
                c.length > d.length && a.set(b, c)
            } else a.set(b, c);
        return Array.from(a.values())
    }
    var NW = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };

    function LW(a, b, c) {
        const d = a.i.has(c) ? a.i.get(c) : a.l++;
        a.i.set(c, d);
        a.A.set(d, c);
        c = 0;
        for (let e = 0; e < b.length; e++) {
            const f = b.charCodeAt(e);
            a.g[c].contains(f) || (a.g.push(new PW), a.g[a.size].A = c, a.g[a.size].C = f, a.g[c].j.set(f, a.size), a.size++);
            c = a.g[c].j.get(f)
        }
        a.g[c].l = !0;
        a.g[c].B = d;
        a.g[c].G = a.j.length;
        a.j.push(b.length)
    }

    function MW(a) {
        const b = [];
        for (b.push(0); b.length > 0;) {
            const f = b.shift();
            var c = a,
                d = c.g[f];
            if (f === 0) d.g = 0, d.i = 0;
            else if (d.A === 0) d.g = 0, d.i = d.l ? f : c.g[c.g[f].g].i;
            else {
                d = c.g[c.g[f].A].g;
                for (var e = c.g[f].C;;) {
                    if (c.g[d].contains(e)) {
                        c.g[f].g = c.g[d].j.get(e);
                        break
                    }
                    if (d === 0) {
                        c.g[f].g = 0;
                        break
                    }
                    d = c.g[d].g
                }
                c.g[f].i = c.g[f].l ? f : c.g[c.g[f].g].i
            }
            for (const g of a.g[f].ta) b.push(g)
        }
    }
    class KW {
        constructor(a) {
            this.B = a;
            this.size = 1;
            this.g = [new PW];
            this.j = [];
            this.i = new Map;
            this.A = new Map;
            this.l = 0
        }
        isEmpty() {
            return this.l === 0
        }
        match(a) {
            let b = 0;
            const c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.j.get(d);
                        break
                    }
                    if (b === 0) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].i;
                    if (h === 0) break;
                    const k = g + 1 - this.j[this.g[h].G],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.B;
                    IW(d.charAt(k - 1), f) && IW(d.charAt(e + 1), f) && c.push(new QW(k, l, this.A.get(this.g[h].B)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class PW {
        constructor() {
            this.j = new Map;
            this.I = !1;
            this.ia = this.H = this.F = this.ca = this.O = this.R = -1
        }
        contains(a) {
            return this.j.has(a)
        }
        set A(a) {
            this.R = a
        }
        get A() {
            return this.R
        }
        set C(a) {
            this.O = a
        }
        get C() {
            return this.O
        }
        set l(a) {
            this.I = a
        }
        get l() {
            return this.I
        }
        set B(a) {
            this.H = a
        }
        get B() {
            return this.H
        }
        set g(a) {
            this.ca = a
        }
        get g() {
            return this.ca
        }
        set i(a) {
            this.F = a
        }
        get i() {
            return this.F
        }
        set G(a) {
            this.ia = a
        }
        get G() {
            return this.ia
        }
        get ta() {
            return this.j.values()
        }
    }
    var QW = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.A = c
        }
        get j() {
            return this.i
        }
        get l() {
            return this.g
        }
        get Ha() {
            return this.A
        }
        get length() {
            return this.g - this.i
        }
    };
    async function RW(a, b, c, d, e) {
        const f = JW(CV(b.V), b.i);
        if (!f.isEmpty()) {
            var g = new Map;
            for (const h of CV(b.V).filter(k => K(k, 5))) Wh(h, 3, ch, w()).forEach(k => {
                g.set(k, K(h, 1))
            });
            await SW(a, a.document.body, b, f, g, new Set, c, d, b.L.Fd ? new cW(0, 0, 0, b.L.Fd) : null, e)
        }
    }
    async function SW(a, b, c, d, e, f, g, h, k, l) {
        g.g.ra(9) >= g.i && await TV(g, 10);
        if (b.nodeType !== Node.ELEMENT_NODE || !b.classList ? .contains("google-anno-skip"))
            if (c.L.Ue && f.size && b.nodeType === Node.ELEMENT_NODE && TW(a, b) && b.parentElement && UW(a, f, c, h, b.parentElement, b, k), b.nodeType === Node.TEXT_NODE && b.textContent) OW(d, b.textContent).map(m => e.get(m.Ha)).filter(m => !!m).forEach(m => void f.add(m));
            else {
                for (const m of b.childNodes) await SW(a, m, c, d, e, f, g, h, k, l);
                f.size && b.nodeType === Node.ELEMENT_NODE && ["block", "table-cell"].includes(a.getComputedStyle(b).display) &&
                    UW(a, f, c, h, b, null, k)
            }
    }

    function UW(a, b, c, d, e, f, g) {
        for (const h of b) {
            if (g && aW(g)) return;
            const k = FW(c.M.Md++, f ? ? e, h);
            d.entries.push(Fh(k));
            g && eW(g.i, h, g.g);
            if (J(c.V, 17)) continue;
            const l = lW(a, c, h, e),
                m = VW(l, c, Fi(k));
            WW(c, 999, l, n => {
                try {
                    if (c.Ua === MV) return !1;
                    var p = c.M,
                        r = Om(Mm(h), Fi(k));
                    var y = Ni(r, 7, m.i);
                    const D = XW(p, y);
                    AW(a, c, D, h, c.A.get(h) || "", c.Ua);
                    return !1
                } finally {
                    n.preventDefault()
                }
            });
            e.insertBefore(l, f)
        }
        b.clear()
    }

    function TW(a, b) {
        return ["BR", "IMG", "TABLE"].includes(b.tagName) || a.getComputedStyle(b).display === "block"
    }
    class YW {
        constructor() {
            this.g = null
        }
        get i() {
            return this.g
        }
    }

    function VW(a, b, c) {
        const d = new YW;
        ZW(b, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = c;
                    e = b.M;
                    var g = new fm;
                    g = f = ei(g, 1, $g(f), "0");
                    f = e.handle;
                    var h = $W(e, 17);
                    g = B(h, 16, Zm, g);
                    e = f.call(e, g);
                    d.g = e
                } else d.g && (e = b.M, f = new em, g = f = Oi(f, 1, d.g), f = e.handle, h = $W(e, 18), g = B(h, 17, Zm, g), f.call(e, g), d.g = null)
        }).observe(a);
        return d
    };

    function aX(a, b, c, d, e, f) {
        if (!a.g) {
            var g = b.document.createElement("span");
            g.appendChild(gW(b, "12px"));
            g.appendChild(b.document.createTextNode(d));
            WD(b, c || null, {
                informationText: g
            }, e, f ? h => {
                var k = f.handle,
                    l = $W(f, 20);
                h = B(l, 11, Zm, h);
                k.call(f, h)
            } : f);
            a.g = !0
        }
    }
    var bX = class {
        constructor() {
            this.g = !1
        }
    };

    function cX(a, b) {
        const c = b.ma === b.X;
        var d = dX(a, b, c);
        if (!d) return null;
        d = d.position.od();
        a = eX(a, d, b, function(f) {
            f = f.getBoundingClientRect();
            return c ? b.T - f.right : f.left
        });
        if (!a || a - 16 < 200) return null;
        const e = b.T;
        return {
            sa: c ? e - a : 16,
            Ba: c ? 16 : e - a,
            ga: d
        }
    }

    function fX(a, b) {
        const c = Un(a),
            d = P(a);
        return pC(new tC(a), new Jj(d - b.ga - 50, c - b.Ba, d - b.ga, b.sa)).size > 0
    }

    function dX(a, b, c) {
        b = Math.floor(b.W * .3);
        return b < 66 ? null : PC(a, {
            Tb: c ? VC({
                ga: 16,
                Ba: 16
            }) : TC({
                ga: 16,
                sa: 16
            }),
            bf: b - 66,
            Ab: 50,
            ef: 50,
            Dd: b,
            mb: 16
        }, [a.document.body]).te
    }

    function eX(a, b, c, d) {
        a = c.ma ? gX(a, b, c) : hX(a, b, c);
        b = c.T;
        let e = c.ma ? b : b * .35;
        a.forEach(f => {
            e = Math.min(e, d(f))
        });
        return e < 16 ? null : e - 16
    }

    function gX(a, b, c) {
        const d = c.W;
        return pC(new tC(a), new Jj(d - b - 50, c.T - 16, d - b, 16))
    }

    function hX(a, b, c) {
        const d = c.W,
            e = c.T;
        c = c.X;
        return pC(new tC(a), new Jj(d - b - 50, (c ? e * .35 : e) - 16, d - b, (c ? 16 : e * .65) + 16))
    }

    function iX(a, b, c) {
        const d = a.X;
        return {
            sa: d ? jX(a, b, c) : c,
            Ba: d ? c : jX(a, b, c),
            ga: 16
        }
    }

    function jX(a, b, c) {
        const d = a.T;
        return a.ma ? d - b + 16 : Math.max(d - c - d * .35, d - b + 16)
    }

    function kX(a, b) {
        const c = b.X,
            d = b.T;
        a = b.ma ? gX(a, 16, b) : hX(a, 16, b);
        return Array.from(a).map(e => new OC(c ? d - e.getBoundingClientRect().right : e.getBoundingClientRect().left, c ? d - e.getBoundingClientRect().left : e.getBoundingClientRect().right)).sort((e, f) => e.start - f.start)
    };

    function lX(a, b, c, d, e, f, g, h, k) {
        u(c, {
            width: "50px",
            bottom: g ? g.ga + "px" : "16px",
            left: b.X() === b.ma ? "" : g ? g.sa + "px" : "16px",
            right: b.X() === b.ma ? g ? g.Ba + "px" : "16px" : ""
        });
        c.role = "button";
        c.ariaLabel = K(b.V, 20);
        u(e, {
            display: "none"
        });
        u(d, {
            display: "none"
        });
        const l = iW(a, "20px", b.L.Ra || "inherit", b.g.get(k.xa) || 0);
        a = a.document.createElement("SPAN");
        u(a, {
            display: "inline-block",
            position: "absolute",
            top: "14px",
            left: "15px",
            cursor: "pointer"
        });
        u(l, {
            cursor: "pointer"
        });
        c.appendChild(a);
        a.appendChild(l);
        WW(b, 1064, c, m => {
            h ? .();
            l.remove();
            u(c, {
                bottom: g ? g.ga + "px" : "16px",
                left: g ? g.sa + "px" : b.ma ? "16px" : b.X() ? "16px" : "65%",
                right: g ? g.Ba + "px" : mX(b),
                width: ""
            });
            c.role = "";
            c.ariaLabel = "";
            u(e, {
                display: ""
            });
            u(d, {
                display: "flex"
            });
            f.focus();
            m.preventDefault();
            return !1
        });
        c.focus()
    }

    function mX(a) {
        return a.X() ? a.ma ? "16px" : "65%" : "16px"
    }

    function nX(a) {
        return {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (a.X(), "50px"),
            right: a.X() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: a.L.Ra || "#FFFFFF",
            cursor: "pointer",
            transition: "width 5s"
        }
    }

    function oX(a) {
        return {
            "margin-left": a ? "6px" : "4px",
            "margin-right": a ? "4px" : "6px",
            "margin-top": "12px"
        }
    }

    function pX(a, b, c) {
        a.tabIndex = 0;
        a.role = "link";
        a.ariaLive = "polite";
        a.ariaLabel = c.replace("TERM", b)
    };

    function qX(a, b, c, d, e, f, g, h, k) {
        const l = document.createElement("SPAN");
        u(l, pr(a));
        l.id = "gda";
        l.appendChild(kW(a, K(b.V, 18), b.L.Ra));
        WW(b, 1064, l, m => {
            g ? .();
            lX(a, b, c, d, l, e, f, h, k);
            m.preventDefault();
            m.stopImmediatePropagation();
            return !1
        });
        return l
    }

    function rX(a, b, c, d) {
        const e = document.createElement("SPAN");
        u(e, pr(a));
        fW(e);
        u(e, nX(b));
        b.ma || u(e, {
            "justify-content": ""
        });
        const f = iW(a, "20px", b.L.Ra, b.g.get(d.xa) || 0),
            g = document.createElement("SPAN");
        u(g, {
            display: "inline-block",
            cursor: "inherit"
        });
        u(g, oX(b.X()));
        e.appendChild(g);
        g.appendChild(f);
        c.classList ? .add("google-anno-sa-qtx", "google-anno-skip");
        pX(c, d.xa, K(b.V, 19));
        u(c, {
            height: "40px",
            "align-items": "center",
            "line-height": "44px",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            "font-family": "Roboto",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: b.L.Ra || "inherit"
        });
        WW(b, 999, e, h => {
            h.preventDefault();
            if (b.Ua !== MV && (d.Qf ? ? 0) + 800 <= b.ra(25)) {
                h = d.xa;
                const m = b.l.get(h) || "";
                var k = b.M;
                var l = Om(Mm(h), d.Bc);
                l = Ni(l, 3, d.xd);
                k = XW(k, l);
                AW(a, b, k, h, m, b.Ua, b.L.Vb ? b.j.get(h) || "" : null)
            }
            return !1
        });
        e.appendChild(c);
        return e
    }

    function sX(a) {
        (new MutationObserver(b => {
            b.forEach(c => {
                c.type === "attributes" && a.document.body.style.paddingBottom === "0px" && u(a.document.body, {
                    "padding-bottom": "66px"
                })
            })
        })).observe(a.document.body, {
            attributes: !0
        })
    }

    function tX(a, b, c, d, e, f) {
        var g = a.getComputedStyle(a.document.body).paddingBottom.match(/\d+/);
        u(a.document.body, {
            "padding-bottom": (g && g.length ? Number(g[0]) : 0) + 66 + "px"
        });
        sX(a);
        g = document.createElement("div");
        u(g, pr(a));
        g.id = "google-anno-sa";
        g.dir = b.X() ? "rtl" : "ltr";
        g.tabIndex = 0;
        var h = {
            background: b.L.me || "#1A73E8",
            "border-style": "solid",
            bottom: d ? d.ga + "px" : "16px",
            "border-radius": "16px",
            height: "50px",
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: d ? d.sa + "px" : b.ma ? "16px" : b.X() ? "16px" : "65%",
            right: d ?
                d.Ba + "px" : mX(b),
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        };
        u(g, h);
        u(g, {
            fill: "white"
        });
        const k = document.createElement("SPAN");
        u(k, pr(a));
        u(k, {
            cursor: "inherit"
        });
        h = rX(a, b, k, c);
        a = qX(a, b, g, h, k, d, e, f, c);
        g.appendChild(h);
        g.appendChild(a);
        return g
    }

    function uX(a, b, c, d, e) {
        var f = c.getElementsByClassName("google-anno-sa-qtx")[0];
        f instanceof HTMLElement && (f.innerText = a.xa);
        if ((d.g.get(e) || 0) !== (d.g.get(a.xa) || 0)) {
            b = iW(b, "20px", d.L.Ra, d.g.get(a.xa) || 0);
            for (var g of c.getElementsByClassName("google-anno-sa-intent-icon")) g.replaceWith(b)
        }
        c = a.xa;
        g = K(d.V, 19);
        f.ariaLabel = g.replace("TERM", c);
        d = d.M;
        f = new jm;
        f = Qh(f, 2, $g(a.Bc));
        f = Qi(f, 4, a.xa);
        a = d.handle;
        c = $W(d, 15);
        f = B(c, 6, Zm, f);
        return a.call(d, f)
    }

    function vX(a, b, c, d) {
        if (fX(b, d)) return null;
        a.Qf = c.ra(24);
        d = tX(b, c, a, d, () => {
            var f = c.M;
            var g = new gm;
            g = ei(g, 3, $g(a.Bc), "0");
            var h = Qi(g, 2, a.xa);
            g = f.handle;
            var k = $W(f, 22);
            h = B(k, 12, Zm, h);
            return g.call(f, h)
        }, () => {
            var f = c.M,
                g = new hm,
                h = f.handle,
                k = $W(f, 23);
            g = B(k, 13, Zm, g);
            return h.call(f, g)
        });
        const e = uX(a, b, d, c, a.xa);
        b.document.body.appendChild(d);
        return e
    }

    function wX(a, b, c, d, e, f, g) {
        if (a.xa !== e || a.Bc !== d || a.g !== f) {
            if (a.xd !== null) {
                var h = a.xd,
                    k = c.M;
                var l = new im;
                l = Oi(l, 1, h);
                h = k.handle;
                var m = $W(k, 16);
                l = B(m, 7, Zm, l);
                h.call(k, l)
            }
            k = a.xa;
            a.xa = e;
            a.Bc = d;
            a.g = f;
            J(c.V, 17) || (d = b.document.getElementById("google-anno-sa"), a.xd = d ? uX(a, b, d, c, k) : vX(a, b, c, g))
        }
    }
    var xX = class {
        constructor() {
            this.xa = "";
            this.Bc = null;
            this.g = "";
            this.Qf = this.xd = null
        }
    };

    function yX(a, b) {
        a.i >= a.g.length && (a.i = 0);
        if (uW) tW.g.push(() => void yX(a, b));
        else {
            var c = a.g[a.i++];
            a.j = !1;
            wX(a.A, a.win, a.config, c.g, c.Ha, c.i, a.l);
            wW(a.config, 898, a.win, () => void yX(a, b), a.yf)
        }
    }
    var zX = class {
        constructor(a, b, c) {
            var d = new xX;
            this.win = a;
            this.config = b;
            this.A = d;
            this.l = c;
            this.g = [];
            this.j = !0;
            this.i = 0;
            this.yf = b.params.yf
        }
    };
    class AX {
        constructor(a, b, c) {
            this.g = a;
            this.Ha = b;
            this.i = c
        }
    };
    const BX = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function CX(a, b, c, d, e) {
        d.g.ra(5) >= d.i && await TV(d, 6);
        if (!c.L.Ie) {
            const f = CV(c.V);
            f.length && DX(a, b, c, e, f)
        }
        c.L.Je && !EX(a) || await c.pa(898, RW(a, c, d, e, b));
        c.L.Ke || await FX(a, c, () => new bX, d, e)
    }

    function EX(a) {
        try {
            const b = a.location ? .href ? .match(/goog_fac=1/);
            return b !== null && b !== void 0
        } catch (b) {
            return !1
        }
    }
    async function FX(a, b, c, d, e) {
        var f = CV(b.V);
        var g = new KW(b.i);
        for (const h of f) K(h, 6) !== "" && (f = K(h, 1), LW(g, f, f));
        MW(g);
        g = new NW(g);
        g.isEmpty() || await b.pa(898, GX(a, b, d, e, g, new cW(b.params.Yj, b.params.qf, b.params.re, b.params.Ed), c()))
    }
    async function GX(a, b, c, d, e, f, g) {
        var h = a.document.body;
        if (J(b.V, 17) || x(b.V, Eq, 21))
            for (; h;) {
                c.g.ra(7) >= c.i && await TV(c, 8);
                if (h.nodeType === Node.TEXT_NODE && h.textContent !== "" && h.parentElement) {
                    var k = h.parentElement;
                    a: {
                        var l = a;
                        var m = b,
                            n = k,
                            p = h.textContent,
                            r = d,
                            y = e,
                            D = f;
                        const fb = [];b: {
                            var E = p;
                            switch (m.i) {
                                case 1:
                                    var G = Array(E.length),
                                        H = 0;
                                    for (var z = 0; z < E.length; z++) HW.test(E[z]) || H++, G[z] = H;
                                    E = G;
                                    break b;
                                default:
                                    G = Array(E.length);
                                    for (z = H = 0; z < E.length;) {
                                        for (;
                                            /\s/.test(E[z]);) G[z] = H, z++;
                                        for (var I = !1; z < E.length &&
                                            !/\s/.test(E[z]);) I = !0, G[z] = H, z++;
                                        I && (H++, G[z - 1] = H)
                                    }
                                    E = G
                            }
                        }
                        y = p.includes("\u00bb") ? [] : OW(y, p);H = -1;
                        for (const gb of y)
                            if (y = gb.j, G = gb.l, !(y < H)) {
                                z = D;
                                var F = gb.Ha;
                                dW(z.i, z.g + E[y]);
                                I = z;
                                var ba = I.i;
                                if ((ba.g.has(F) ? ba.g.get(F).length : 0) < I.qf && z.i.j < z.re) {
                                    z = l.getComputedStyle(n);
                                    I = z.fontSize.match(/\d+/);
                                    if (!(I && Number(I[0]) >= 12 && Number(I[0]) <= 22 && ab(BX, z.display))) {
                                        D.g += E[E.length - 1];
                                        l = [];
                                        break a
                                    }
                                    H += 1;
                                    H < y && fb.push(l.document.createTextNode(p.substring(H, y)));
                                    H = p.substring(y, G + 1);
                                    z = p;
                                    I = y;
                                    ba = G + 1;
                                    ba = z.substring(Math.max(I -
                                        30, 0), I) + "~~" + z.substring(ba, Math.min(ba + 30, z.length));
                                    I = l;
                                    var bb = m.M.Md++;
                                    z = n;
                                    var xa = H,
                                        fa = ba,
                                        la = gb.Ha;
                                    F = E[y];
                                    ba = z.getBoundingClientRect();
                                    bb = vm(um(new wm, bb), 2);
                                    xa = Qi(bb, 2, xa);
                                    xa = Qi(xa, 3, fa);
                                    la = Qi(xa, 4, la);
                                    F = Mi(la, 5, F);
                                    F = Mi(F, 6, Math.round(ba.x));
                                    ba = Mi(F, 7, Math.round(ba.y));
                                    I = I.getComputedStyle(z);
                                    F = new tm;
                                    F = Qi(F, 1, I.fontFamily);
                                    la = GW(I.color);
                                    F = A(F, 7, la);
                                    la = GW(I.backgroundColor);
                                    F = A(F, 8, la);
                                    la = I.fontSize.match(/^(\d+(\.\d+)?)px$/);
                                    F = Mi(F, 4, la ? Math.round(Number(la[1])) : 0);
                                    la = Math.round(Number(I.fontWeight));
                                    isNaN(la) || la === 400 || Mi(F, 5, la);
                                    I.textDecorationLine !== "none" && Qi(F, 6, I.textDecorationLine);
                                    I = A(ba, 8, F);
                                    ba = [];
                                    for (xa = z; xa && ba.length < 20;) {
                                        z = ba;
                                        F = z.push;
                                        la = xa;
                                        fa = new rm;
                                        fa = Qi(fa, 1, la.tagName);
                                        la.className !== "" && di(fa, 2, la.className.split(" "), ah);
                                        F.call(z, fa);
                                        if (xa.tagName === "BODY") break;
                                        xa = xa.parentElement
                                    }
                                    z = ba.reverse();
                                    z = oi(I, 9, z);
                                    r.entries.push(Fh(z));
                                    fb.push(HX(l, m, Fi(z), gb.Ha, H, n));
                                    eW(D.i, gb.Ha, D.g + E[y]);
                                    H = G;
                                    if (aW(D)) break
                                }
                            }
                        m = H + 1;m !== 0 && m < p.length && fb.push(l.document.createTextNode(p.substring(m)));
                        D.g += E[E.length - 1];l = fb
                    }
                    if (l.length && !J(b.V, 17)) {
                        !b.L.Vb && aX(g, a, b.params.gg ? OV(a, b.params.gg) : void 0, K(b.V, 3), x(b.V, Eq, 21).i(), b.M);
                        for (const fb of l) k.insertBefore(fb, h), IX(fb);
                        k.removeChild(h);
                        for (h = l[l.length - 1]; h.lastChild;) h = h.lastChild;
                        if (aW(f)) break
                    }
                }
                a: {
                    k = f;l = b.i;
                    if (h.firstChild && (h.nodeType !== Node.ELEMENT_NODE ? 0 : !h.classList ? .contains("google-anno-skip") && h.offsetHeight)) {
                        b: {
                            switch (h.tagName ? .toUpperCase ? .()) {
                                case "IFRAME":
                                case "A":
                                case "AUDIO":
                                case "BUTTON":
                                case "CANVAS":
                                case "CITE":
                                case "CODE":
                                case "EMBED":
                                case "FOOTER":
                                case "FORM":
                                case "KBD":
                                case "LABEL":
                                case "OBJECT":
                                case "PRE":
                                case "SAMP":
                                case "SCRIPT":
                                case "SELECT":
                                case "STYLE":
                                case "SUB":
                                case "SUPER":
                                case "SVG":
                                case "TEXTAREA":
                                case "TIME":
                                case "VAR":
                                case "VIDEO":
                                case null:
                                    p = !1;
                                    break b
                            }
                            p = !(h.className.toUpperCase ? .() ? .includes("CRUMB") || h.id.toUpperCase ? .() ? .includes("CRUMB"))
                        }
                        if (p) {
                            h = h.firstChild;
                            break a
                        }
                        if (h.textContent ? .length) {
                            b: switch (p = h.textContent, l) {
                                case 1:
                                    l = p;
                                    p = 0;
                                    for (D = l.length - 1; D >= 0; D--) HW.test(l[D]) || p++;
                                    l = p;
                                    break b;
                                default:
                                    l = p.trim(), l = l === "" ? 0 : l.split(/\s+/).length
                            }
                            dW(k.i, k.g + l)
                        }
                    }
                    for (;;) {
                        if (h.nextSibling) {
                            h = h.nextSibling;
                            break a
                        }
                        if (!h.parentNode) {
                            h = null;
                            break a
                        }
                        h = h.parentNode
                    }
                    h = void 0
                }
            }
    }

    function JX(a, b) {
        b = {
            X: b.X(),
            ma: b.ma,
            T: Un(a),
            W: P(a)
        };
        if (b.W >= 400) {
            var c;
            if ((c = cX(a, b)) != null) var d = c;
            else a: {
                c = b.T;
                var e = kX(a, b);a = 16;
                for (d of e) {
                    e = d.start;
                    const f = d.end;
                    if (e > a) {
                        if (e - a - 16 >= 200) {
                            d = iX(b, e, a);
                            break a
                        }
                        a = f + 16
                    } else f >= a && (a = f + 16)
                }
                d = c - a - 16 >= 200 ? iX(b, c, a) : null
            }
        } else d = null;
        return d
    }

    function DX(a, b, c, d, e) {
        function f() {
            return h ? ? (h = c.Yd(898, a, () => {
                g || (a.clearInterval(h), g = !0, KX(a, b, c, d, e), LX(c.M, RV(d, c.V)))
            }, c.L.Zb))
        }
        let g = !1,
            h = void 0;
        const k = MX(c, a, () => {
            a.scrollY <= c.L.pe || g || (c.L.Zb > 0 && !JX(a, c) ? h = f() : (g = !0, a.removeEventListener("scroll", k), KX(a, b, c, d, e), LX(c.M, RV(d, c.V))))
        });
        wW(c, 898, a, () => {
            g || (c.L.Zb > 0 && !JX(a, c) ? h = f() : (g = !0, KX(a, b, c, d, e), LX(c.M, RV(d, c.V))))
        }, c.L.ne)
    }

    function KX(a, b, c, d, e) {
        if (c.L.Ze) NX(a, b, c, d, e);
        else if (e = e.filter(h => K(h, 7).length).map(h => K(h, 1)), e.length !== 0) {
            var f = JX(a, c);
            if (f) {
                var g = new zX(a, c, f);
                e.forEach(h => {
                    var k = EW(c.M.Md++, h);
                    d.entries.push(Fh(k));
                    k = Fi(k);
                    g.g.push(new AX(k, h, h));
                    g.j && yX(g, b)
                })
            }
        }
    }

    function NX(a, b, c, d, e) {
        e = e.filter(h => K(h, 7).length);
        if (e.length) {
            var f = JX(a, c);
            if (f) {
                var g = new zX(a, c, f);
                e.forEach(h => {
                    var k = c.M.Md++,
                        l = K(h, 1);
                    const m = C(h, 2);
                    k = EW(k, l, m == null ? void 0 : m, Hi(h, 4));
                    d.entries.push(Fh(k));
                    k = Fi(k);
                    l = K(h, 1);
                    h = K(h, 1);
                    g.g.push(new AX(k, l, h));
                    g.j && yX(g, b)
                })
            }
        }
    }

    function IX(a) {
        if (a.nodeType === Node.ELEMENT_NODE) {
            if (a.tagName === "A") {
                var b = $V(YV(getComputedStyle(a.parentElement).color)),
                    c = $V(YV(getComputedStyle(a).color));
                var d = ZV(a);
                if (d = b && c && d ? IM(c, d) < Math.min(IM(b, d), 2.5) ? b : null : b) {
                    b = d[0];
                    c = d[1];
                    d = d[2];
                    b = Number(b);
                    c = Number(c);
                    d = Number(d);
                    if (b != (b & 255) || c != (c & 255) || d != (d & 255)) throw Error('"(' + b + "," + c + "," + d + '") is not a valid RGB color');
                    c = b << 16 | c << 8 | d;
                    b = b < 16 ? "#" + (16777216 | c).toString(16).slice(1) : "#" + c.toString(16);
                    u(a, {
                        color: b
                    })
                }
            }
            for (b = 0; b < a.childElementCount; b++) IX(a.children[b])
        }
    }
    class OX {
        constructor() {
            this.g = null
        }
        get i() {
            return this.g
        }
    }

    function HX(a, b, c, d, e, f) {
        const g = a.document.createElement("SPAN");
        g.className = "google-anno-t";
        fW(g);
        u(g, {
            "text-decoration": "underline"
        });
        u(g, {
            "text-decoration-style": "dotted"
        });
        u(g, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        u(g, {
            color: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit"
        });
        g.appendChild(a.document.createTextNode(e));
        e = a.document.createElement("A");
        fW(e);
        u(e, {
            "text-decoration": "none",
            fill: "currentColor"
        });
        rd(e);
        e.className = "google-anno";
        b.L.vf && (e.appendChild(gW(a, a.getComputedStyle(f).fontSize)), e.appendChild(a.document.createTextNode("\u00a0")));
        e.appendChild(g);
        const h = PX(b, c, e);
        WW(b, 999, e, k => {
            try {
                if (b.Ua === MV) return !1;
                var l = b.M,
                    m = Om(Mm(d), c);
                var n = Ni(m, 2, h.i);
                const p = XW(l, n);
                AW(a, b, p, d, b.B.get(d) || "", b.Ua, b.L.Vb ? b.j.get(d) || "" : null);
                return !1
            } finally {
                k.preventDefault(), k.stopImmediatePropagation()
            }
        });
        return e
    }

    function PX(a, b, c) {
        const d = new OX;
        ZW(a, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = b;
                    e = a.M;
                    var g = new Tm;
                    g = f = ei(g, 2, $g(f), "0");
                    f = e.handle;
                    var h = $W(e, 13);
                    g = B(h, 4, Zm, g);
                    e = f.call(e, g);
                    d.g = e
                } else d.g && (e = a.M, f = new Sm, g = f = Oi(f, 1, d.g), f = e.handle, h = $W(e, 14), g = B(h, 5, Zm, g), f.call(e, g), d.g = null)
        }).observe(c);
        return d
    };

    function xW(a, b) {
        var c = a.handle,
            d = $W(a, 19);
        b = B(d, 9, Zm, b);
        c.call(a, b)
    }

    function XW(a, b) {
        var c = a.handle,
            d = $W(a, 12);
        b = B(d, 8, Zm, b);
        return c.call(a, b)
    }

    function LX(a, b) {
        var c = a.handle,
            d = $W(a, 11);
        b = B(d, 14, Zm, b);
        c.call(a, b)
    }

    function $W(a, b) {
        var c = new Ym;
        var d = a.B++;
        c = Oi(c, 1, d);
        b = Oi(c, 2, Math.round(a.g.ra(b) - a.i));
        b = A(b, 10, a.j);
        return Ki(b, 15, a.l ? !0 : void 0)
    }
    var QX = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.i = b;
            this.j = c;
            this.l = d;
            this.Md = this.B = 1;
            this.A = [...e]
        }
        handle(a) {
            for (const b of this.A) b(a);
            return Ci(a, 1)
        }
    };

    function wW(a, b, c, d, e) {
        c.setTimeout(RX(a, b, d), e)
    }

    function WW(a, b, c, d) {
        c.addEventListener("click", RX(a, b, d))
    }

    function ZW(a, b) {
        return new IntersectionObserver(RX(a, 1065, b), {
            threshold: .98
        })
    }

    function MX(a, b, c) {
        a = RX(a, 898, c);
        b.addEventListener("scroll", a, {
            passive: !0
        });
        return a
    }

    function RX(a, b, c) {
        return a.Ia.Ca(b, c, void 0, d => {
            d.es = a.L.Ob.join(",")
        })
    }
    var TX = class {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.Jc = a;
            this.ma = b;
            this.V = c;
            this.Ia = d;
            this.M = e;
            this.C = f;
            this.params = g;
            this.L = h;
            this.Ua = k;
            this.B = new Map;
            this.l = new Map;
            this.A = new Map;
            this.g = new Map;
            this.j = new Map;
            this.i = ab(SX, K(c, 7)) ? 1 : 0;
            for (const l of CV(this.V)) C(l, 6) != null && this.B.set(K(l, 1), K(l, 6)), C(l, 7) != null && this.l.set(K(l, 1), K(l, 7)), C(l, 5) != null && this.A.set(K(l, 1), K(l, 5)), Ai(l, 10) != null && this.g.set(K(l, 1), Ei(l, 10)), C(l, 11) != null && this.j.set(K(l, 1), K(l, 11))
        }
        ke(a, b, c) {
            a = RX(this, a, c);
            b.addEventListener("message",
                a);
            return a
        }
        Yd(a, b, c, d) {
            return b.setInterval(RX(this, a, c), d)
        }
        pa(a, b) {
            this.Ia.pa(a, b, c => {
                c.es = this.L.Ob.join(",")
            });
            return b
        }
        ra(a) {
            return this.C.ra(a)
        }
        X() {
            return Ei(this.V, 12) === 2
        }
    };
    const SX = ["ja", "zh_CN", "zh_TW"];

    function UX(a, b) {
        return b == null ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function VX(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function WX() {
        const a = new Set,
            b = jy();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function XX(a) {
        a = a.id;
        return a != null && (WX().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function YX(a, b, c) {
        if (!a.sources) return !1;
        switch (ZX(a)) {
            case 2:
                const d = $X(a);
                if (d) return c.some(f => aY(d, f));
                break;
            case 1:
                const e = bY(a);
                if (e) return b.some(f => aY(e, f))
        }
        return !1
    }

    function ZX(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function bY(a) {
        return cY(a, b => b.currentRect)
    }

    function $X(a) {
        return cY(a, b => b.previousRect)
    }

    function cY(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function aY(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : 100 * c * a / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }

    function dY() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(XX),
            b = [...WX()].map(c => document.getElementById(c)).filter(c => c !== null);
        eY = window.scrollX;
        fY = window.scrollY;
        return gY = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function hY(a, b) {
        const c = eY !== window.scrollX || fY !== window.scrollY ? [] : gY,
            d = dY();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                iY(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Bb = Math.floor(b.renderTime || b.loadTime);
                a.ib = b.size;
                break;
            case "first-input":
                b = e;
                a.Ea = Number((b.processingStart - b.startTime).toFixed(3));
                a.La = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || jY(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.C +=
                    b;
                a.H = Math.max(a.H, b);
                a.ca += 1;
                break;
            case "event":
                jY(a, e);
                break;
            default:
                td(b, void 0)
        }
    }

    function kY(a) {
        a.A || (a.A = new PerformanceObserver(Ou(640, b => {
            hY(a, b)
        })));
        return a.A
    }

    function lY(a) {
        const b = Ou(641, () => {
                TO(document) === 2 && mY(a)
            }),
            c = Ou(641, () => void mY(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.ta = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            kY(a).disconnect()
        }
    }

    function mY(a) {
        if (!a.Gf) {
            a.Gf = !0;
            kY(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += VX("cls", a.G), b += VX("mls", a.I), b += UX("nls", a.R), window.LayoutShiftAttribution && (b += VX("cas", a.B), b += UX("nas", a.Ff), b += VX("was", a.Yf)), b += VX("wls", a.ia), b += VX("tls", a.Vf));
            window.LargestContentfulPaint && (b += UX("lcp", a.Bb), b += UX("lcps", a.ib));
            window.PerformanceEventTiming && a.La && (b += UX("fid", a.Ea));
            window.PerformanceLongTaskTiming && (b += UX("cbt", a.C),
                b += UX("mbt", a.H), b += UX("nlt", a.ca));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) XX(c) && d++;
            b += UX("nif", d);
            b += UX("ifi", nk(window));
            c = O(Dn).g();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${q===q.top?1:0}`;
            b += a.If ? `&${"qqid"}=${encodeURIComponent(a.If)}` : UX("pvsid", Ye(q));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.A ? a.hb : performance.interactionCount || 0) / 50));
            c >= 0 && (c = a.g[c].latency, c >= 0 && (b += UX("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.ta()
        }
    }

    function iY(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.G += Number(b.value);
            Number(b.value) > a.I && (a.I = Number(b.value));
            a.R += 1;
            if (c = YX(b, c, d)) a.B += b.value, a.Ff++;
            if (b.startTime - a.Oc > 5E3 || b.startTime - a.Hf > 1E3) a.Oc = b.startTime, a.i = 0, a.j = 0;
            a.Hf = b.startTime;
            a.i += b.value;
            c && (a.j += b.value);
            a.i > a.ia && (a.ia = a.i, a.Yf = a.j, a.Vf = b.startTime + b.duration)
        }
    }

    function jY(a, b) {
        nY(a, b);
        const c = a.g[a.g.length - 1],
            d = a.F[b.interactionId];
        if (d || a.g.length < 10 || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.F[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.F[e.id]
        })
    }

    function nY(a, b) {
        b.interactionId && (a.O = Math.min(a.O, b.interactionId), a.l = Math.max(a.l, b.interactionId), a.hb = a.l ? (a.l - a.O) / 7 + 1 : 0)
    }
    var oY = class {
            constructor() {
                this.j = this.i = this.R = this.I = this.G = 0;
                this.Hf = this.Oc = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.F = {};
                this.hb = 0;
                this.O = Infinity;
                this.Ea = this.ib = this.Bb = this.Ff = this.Yf = this.B = this.Vf = this.ia = this.l = 0;
                this.La = !1;
                this.ca = this.H = this.C = 0;
                this.A = null;
                this.Gf = !1;
                this.ta = () => {};
                const a = document.querySelector("[data-google-query-id]");
                this.If = a ? a.getAttribute("data-google-query-id") : null;
                this.mi = {
                    fi: !1
                }
            }
            observe() {
                var a = window;
                if (!a.google_plmetrics && window.PerformanceObserver) {
                    a.google_plmetrics = !0;
                    a = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                    this.mi.fi && a.push("event");
                    for (const b of a) a = {
                        type: b,
                        buffered: !0
                    }, b === "event" && (a.durationThreshold = 40), kY(this).observe(a);
                    lY(this)
                }
            }
        },
        eY, fY, gY = [];
    async function pY(a, b, c, d, e, f, g, h) {
        var k = W,
            l = ((h = HO(new LO(a), "__gads", h)) ? ze(h + "t2Z7mVic") % 20 : null) ? ? Math.floor(we() * 20);
        h = f.ra(0);
        const m = Un(a) < 488,
            n = c.V;
        var p = c.L;
        l = Pm(l);
        p = fi(l, p.Ob);
        e = new QX(f, h, p, J(n, 17), e);
        k = new TX(d, m, n, k, e, f, c.params, c.L, c.Ua);
        d = new SV;
        b = await qY(a, a.document, b, k, g, d);
        c = PV(d, m, c.bd, a.location.hostname, c.Qi, n, f.ra(11) - h, b);
        a = e.handle;
        f = $W(e, 11);
        c = B(f, 3, Zm, c);
        a.call(e, c)
    }
    async function qY(a, b, c, d, e, f) {
        b = b.body;
        if (!b || !rY(b)) return [nm()];
        e.g.ra(3) >= e.i && await TV(e, 4);
        b = (b = K(d.V, 7)) ? (b = b.match(/^[a-z]{2,3}/i)) ? b[0].toLowerCase() : "" : "";
        f.language = b;
        b = [];
        if (a.document.querySelector('script[src*="www.google.com/adsense/search/ads.js"]')) {
            var g = b.push;
            var h = new om;
            var k = new mm;
            h = B(h, 3, pm, k);
            g.call(b, h)
        }(d.L.Jd && Un(a) < d.L.Jd || d.L.Id && P(a) < d.L.Id) && b.push(nm());
        b.length || await CX(a, c, d, e, f);
        return b
    }

    function rY(a) {
        try {
            (new ResizeObserver(() => {})).disconnect(), (new MutationObserver(() => {})).disconnect()
        } catch {
            return !1
        }
        return a.classList && a.classList.contains !== void 0 && a.attachShadow !== void 0
    }

    function sY() {
        var a = V(wt),
            b = W;
        if (Math.random() < a) try {
            (new oY).observe()
        } catch (c) {
            b.ba(1161, c instanceof Error ? c : Error("Unknown error."))
        }
    };
    async function tY(a, b, c, d, e, f, g) {
        Kd() || (sY(), d.push(async () => {
            delete window.google_plmetrics
        }));
        U(ht) || (a = await uY(a, b, c, d, e, f, g), a.pb.length && vY(b, c, g, a))
    }
    async function uY(a, b, c, d, e, f, g) {
        const h = a.performance ? .now ? new VV(a.performance) : new WV;
        a = new UV(a, h);
        if (typeof e !== "string") return e = new om, b = new mm, {
            Ta: null,
            pb: [B(e, 12, pm, b)]
        };
        const k = HV(e);
        e = li(k, DV);
        if (!b) return b = new om, d = new mm, b = B(b, 9, pm, d), {
            Ta: e,
            pb: [b]
        };
        const l = c.google_ad_client;
        if (typeof l !== "string") return b = new om, d = new mm, b = B(b, 11, pm, d), {
            Ta: e,
            pb: [b]
        };
        if (Jd()) return {
            Ta: e,
            pb: [nm()]
        };
        if (Be()) return b = new om, d = new mm, b = B(b, 13, pm, d), {
            Ta: e,
            pb: [b]
        };
        var m = O(hF);
        c = wY(c);
        var n = xY(e);
        a: {
            try {
                const y =
                    b ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
                if (!y) {
                    var p = null;
                    break a
                }
                var r = decodeURIComponent(y[1]);
                p = EV(r);
                break a
            } catch (y) {
                p = null;
                break a
            }
            p = void 0
        }
        p = p || li(k, DV);
        r = k.U;
        r = mi(r, r[v], Mq, 3, 1);
        r = {
            Yj: V(pt),
            qf: V(tt),
            re: V(rt),
            Ed: V(st),
            gg: r,
            yf: V(xt)
        };
        g = {
            V: p,
            bd: c,
            Qi: g,
            params: r,
            L: new NV({
                Ob: n,
                Sg: V(wt),
                Ie: U(Os),
                Ke: U(Qs),
                Jd: V(vt),
                Id: V(ut),
                Zb: V(nt),
                me: cu(Rs),
                Ra: cu(Ss),
                ne: V(mt),
                pe: V(ot),
                Je: U(Ps),
                ye: cu(Ls),
                Xc: cu(Ms),
                Gd: V(bt),
                Vb: U(it),
                Ne: du(Us),
                Ue: U(Xs),
                Fd: V(at),
                lf: U(gt),
                Ze: U($s),
                vf: U(jt)
            }),
            Ua: LV
        };
        await yY(b,
            d, m, g, l, h, a, f);
        return {
            Ta: e,
            pb: []
        }
    }

    function xY(a) {
        const b = O(Dn).g();
        a && b.push(...Wh(a, 24, Kg, w()));
        b.push(...du(lt).map(Number));
        b.push(42);
        b.sort((c, d) => c - d);
        return b
    }

    function vY(a, b, c, d) {
        a = PV(new SV, !!a && Un(a) < 488, wY(b), a ? .location ? .hostname ? ? "", c, d.Ta ? ? new DV, 0, d.pb);
        c = Math.floor(we() * 20);
        b = new Ym;
        b = Oi(b, 1, 1);
        b = Oi(b, 2, 0);
        c = Pm(c);
        var e = xY(d.Ta);
        c = fi(c, e);
        b = A(b, 10, c);
        a = B(b, 3, Zm, a);
        zY(O(hF), a, Date.now(), d.Ta)
    }
    async function yY(a, b, c, d, e, f, g, h) {
        const k = cA(a);
        k.wasReactiveAdConfigReceived[42] || (k.wasReactiveAdConfigReceived[42] = !0, await pY(a, b, d, e, [l => {
            zY(c, l, f.ra(21), d.V)
        }], f, g, h))
    }

    function zY(a, b, c, d) {
        a && W.pa(1214, lF(a, b, c), e => {
            e.es = xY(d).join(",")
        })
    }

    function wY(a) {
        a = a.google_page_url;
        return typeof a === "string" ? a : ""
    };
    const AY = (a, b) => {
        const c = ue("STYLE", a);
        c.textContent = Ac(Vc `* { pointer-events: none; }`);
        a ? .head.appendChild(c);
        setTimeout(() => {
            a ? .head.removeChild(c)
        }, b)
    };
    var CY = (a, b, c) => {
        if (!a.body) return null;
        const d = new BY;
        d.apply(a, b);
        return () => {
            var e = c || 0;
            e > 0 && AY(b.document, e);
            Yj(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.j,
                position: d.l,
                top: d.A
            });
            b.scrollTo(0, d.i)
        }
    };
    class BY {
        constructor() {
            this.g = this.A = this.l = this.j = null;
            this.i = 0
        }
        apply(a, b) {
            this.j = a.body.style.overflow;
            this.l = a.body.style.position;
            this.A = a.body.style.top;
            this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
            this.i = bo(b);
            Yj(a.body, "top", -this.i + "px")
        }
    };

    function DY(a, b) {
        var c;
        if (!a.j)
            for (a.j = [], c = a.g.parentElement; c;) {
                a.j.push(c);
                if (a.H(c)) break;
                c = c.parentNode && c.parentNode.nodeType === 1 ? c.parentNode : null
            }
        c = a.j.slice();
        let d, e;
        for (d = 0; d < c.length; ++d)(e = c[d]) && b.call(a, e, d, c)
    }
    var EY = class extends Q {
        constructor(a, b, c) {
            super();
            this.g = a;
            this.O = b;
            this.C = c;
            this.j = null;
            xo(this, () => this.j = null)
        }
        H(a) {
            return this.C === a
        }
    };

    function FY(a, b) {
        const c = a.C;
        c && (b ? (lA(a.F), u(c, {
            display: "block"
        }), a.A.body && !a.l && (a.l = CY(a.A, a.O, a.R)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.A.body.setAttribute("aria-hidden", "true")) : (mA(a.F), u(c, {
            display: "none"
        }), a.l && (a.l(), a.l = null), a.A.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
    }

    function GY(a) {
        FY(a, !1);
        const b = a.C;
        if (b) {
            var c = HY(a.I);
            DY(a, d => {
                u(d, c);
                go(d)
            });
            a.g.setAttribute("width", "");
            a.g.setAttribute("height", "");
            Yj(a.g, c);
            Yj(a.g, IY);
            Yj(b, JY);
            Yj(b, {
                background: "transparent"
            });
            u(b, {
                display: "none",
                position: "fixed"
            });
            go(b);
            go(a.g);
            cf(a.I) <= 1 || (Yj(b, {
                overflow: "scroll",
                "max-width": "100vw"
            }), Pe(b))
        }
    }
    class KY extends EY {
        constructor(a, b, c) {
            var d = V(Ot);
            super(a, b, c);
            this.l = null;
            this.A = b.document;
            this.R = d;
            this.F = fA(new kA(b), 2147483646);
            this.I = b
        }
    }

    function HY(a) {
        a = cf(a);
        a = 100 * (a < 1 ? 1 : a);
        return {
            width: `${a}vw`,
            height: `${a}vh`
        }
    }
    var JY = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        IY = {
            left: "0",
            position: "absolute",
            top: "0"
        };
    var LY = class extends KY {
        constructor(a, b, c) {
            super(b, a, c);
            GY(this)
        }
        H(a) {
            return a.classList ? a.classList.contains("adsbygoogle") : ab(a.classList ? a.classList : (typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || "").match(/\S+/g) || [], "adsbygoogle")
        }
    };
    const MY = {
        [1]: "closed",
        [2]: "granted",
        [3]: "cancelled"
    };
    async function NY(a, b, c, d) {
        a = new OY(a, b, c, d);
        await a.J();
        return a
    }

    function PY(a) {
        return setTimeout(gy(728, () => {
            QY(() => {
                a.A.reject()
            });
            a.dispose()
        }), V(Gt) * 1E3)
    }

    function RY(a, b) {
        var c = NM(a.g).then(() => {
            clearTimeout(b);
            a.A.resolve()
        });
        W.pa(1005, c);
        c = OM(a.g).then(d => {
            SY(a, MY[d.status])
        });
        W.pa(1006, c);
        c = PM(a.g).then(() => {
            SY(a, "error")
        });
        W.pa(1004, c)
    }

    function TY(a) {
        if (U(Ht)) {
            a.win.location.hash !== "" && hy("pub_hash", {
                o_url: a.win.location.href
            }, .1);
            a.win.location.hash = "goog_fullscreen_ad";
            var b = gy(950, c => {
                c.oldURL.endsWith("#goog_fullscreen_ad") && (a.l === 10 ? SY(a, "closed") : a.g.Be.postMessage(JSON.stringify({
                    eventType: "backButton",
                    googMsgType: "fullscreen"
                }), "*"), a.win.removeEventListener("hashchange", b))
            });
            a.win.addEventListener("hashchange", b);
            xo(a, () => {
                a.win.removeEventListener("hashchange", b);
                a.win.location.hash === "#goog_fullscreen_ad" && a.win.history.back()
            })
        }
    }

    function QY(a) {
        try {
            a()
        } catch (b) {}
    }

    function SY(a, b) {
        FY(a.F, !1);
        a.j && QY(() => {
            a.j(b)
        });
        a.dispose()
    }
    var OY = class extends Q {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.C = b;
            this.H = c;
            this.l = d;
            this.j = null;
            this.F = new LY(a, c, b);
            a = new RM(this.l === 10 ? 1 : 2, this.win, this.H.contentWindow);
            a.J();
            this.g = a;
            this.A = new SK;
            this.C.dataset["slotcar" + (this.l === 10 ? "Interstitial" : "Rewarded")] = "true"
        }
        async J() {
            const a = PY(this);
            RY(this, a);
            xo(this, () => {
                this.g.dispose();
                clearTimeout(a);
                be(this.C)
            });
            await this.A.promise
        }
        show(a) {
            this.B || (this.j = a, FY(this.F, !0), q.IntersectionObserver || this.g.Be.postMessage(JSON.stringify({
                eventType: "visible",
                googMsgType: "fullscreen"
            }), "*"), TY(this))
        }
        disposeAd() {
            this.dispose()
        }
    };

    function UY({
        bg: a,
        ih: b
    }) {
        return a || (b === "dev" ? "dev" : "")
    };

    function VY(a, b) {
        a.tf(c => {
            c.shv = String(b);
            c.mjsv = UY({
                bg: CE(),
                ih: b
            });
            c.eid = vQ(q)
        })
    };

    function WY() {
        var a = q.adsbygoogle;
        try {
            const b = a.pageState;
            ng(b, sg);
            return KV(b)
        } catch (b) {
            return new JV
        }
    };
    var XY = typeof sttc === "undefined" ? void 0 : sttc;

    function YY(a) {
        var b = W;
        try {
            return ng(a, sg), new dQ(JSON.parse(a))
        } catch (c) {
            b.ba(838, c instanceof Error ? c : Error(String(c)))
        }
        return new dQ
    };

    function ZY(a, b, c, d) {
        const e = new SK;
        let f = "";
        const g = k => {
            try {
                const l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                f === l.paw_id && (Ib(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
            } catch (l) {}
        };
        var h = typeof a.gmaSdk ? .getQueryInfo === "function" ? a.gmaSdk : void 0;
        if (h) return Hb(a, "message", g), f = c(h), e.promise;
        c = typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage === "function" || typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage === "function" ? a.webkit.messageHandlers :
            void 0;
        return c ? (f = String(Math.floor(we() * 2147483647)), Hb(a, "message", g), b(c, f), e.promise) : null
    }

    function $Y(a) {
        return ZY(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    }(function(a) {
        return pg(b => {
            if (!wg(b)) return !1;
            for (const [c, d] of Object.entries(a)) {
                const e = c,
                    f = d;
                if (!(e in b)) {
                    if (f.ej === !0) continue;
                    return !1
                }
                if (!f(b[e])) return !1
            }
            return !0
        })
    })({
        vc: sg,
        pn: sg,
        eid: sg,
        vnm: function(a) {
            return xg(pg((b, c) => b === void 0 ? !0 : a(b, c)))
        }(sg),
        js: sg
    }, "RawGmaSdkStaticSignalObject");
    const aZ = (a, b) => {
        try {
            const k = J(b, 6) === void 0 ? !0 : J(b, 6);
            var c = fj(Ei(b, 2)),
                d = K(b, 3);
            a: switch (Ei(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new hj(c, d, e),
                g = x(b, aj, 5) ? .g() ? ? "";
            f.yc = g;
            f.g = k;
            f.win = a;
            var h = f.build();
            Zi(h)
        } catch {}
    };

    function bZ(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), a.document.readyState === "complete" ? aZ(a, b) : Hb(a, "load", () => void aZ(a, b)))
    };

    function cZ(a) {
        const b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function dZ(a) {
        if (a === a.top || pe(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && cZ(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        const c = new SK;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            d.data.msgType === "__goog_top_url_resp" && c.resolve({
                qc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };

    function UE() {
        return navigator.cookieDeprecationLabel ? Promise.race([navigator.cookieDeprecationLabel.getValue().then(a => ({
            status: 1,
            label: a
        })).catch(() => ({
            status: 2
        })), $e(V(Et), {
            status: 5
        })]) : Promise.resolve({
            status: 3
        })
    }

    function eZ(a) {
        a = a.innerInsElement;
        if (!a) throw Error("no_wrapper_element_in_loader_provided_slot");
        return a
    }
    async function fZ({
        na: a,
        wa: b,
        Wa: c,
        slot: d
    }) {
        const e = d.vars,
            f = se(d.pubWin),
            g = eZ(d),
            h = new xQ({
                K: f,
                pubWin: d.pubWin,
                D: e,
                na: a,
                wa: b,
                Wa: c,
                ea: g
            });
        h.H = Date.now();
        Ij(1, [h.D]);
        fy(1032, () => {
            if (f && U(Zt)) {
                var k = h.D;
                LE(GE(), 32, !1) || (ME(GE(), 32, !0), XU(f, k.google_loader_used === "sd" ? 5 : 9))
            }
        });
        try {
            await gZ(h)
        } catch (k) {
            if (!W.ba(159, k, void 0, void 0)) throw k;
        }
        fy(639, () => {
            var k;
            var l = h.D;
            (k = h.K) && l.google_responsive_auto_format === 1 && l.google_full_width_responsive_allowed === !0 ? (l = (l = k.document.getElementById(l.google_async_iframe_id)) ?
                ge(l, "INS", "adsbygoogle") : null) ? (k = new XP(k, l), k.g = q.setInterval(Ja(k.i, k), 500), k.i(), k = !0) : k = !1 : k = !1;
            return k
        });
        f ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) ? iy(1008, hZ(d.pubWin, f, e, h.j, Si(FV()), h.g, K(a, 8)), k => {
            k.es = xY(null).join(",")
        }) : KM(h.pubWin, "affa", k => {
            iy(1008, hZ(d.pubWin, f, e, h.j, k.config, h.g, K(a, 8)), l => {
                l.es = xY(null).join(",")
            });
            return !0
        });
        iZ(h);
        return h
    }
    async function hZ(a, b, c, d, e, f, g) {
        await tY(a, b, c, d, e, f, g)
    }

    function gZ(a) {
        if (/_sdo/.test(a.D.google_ad_format)) return Promise.resolve();
        var b = a.pubWin;
        tQ(13, b);
        tQ(11, b);
        a.F = Gi(a.na, bQ, 13, eQ) ? .g() ? ? !0;
        b = GE();
        var c = LE(b, 23, !1);
        c || ME(b, 23, !0);
        if (!c) {
            b = a.D.google_ad_client;
            c = a.na;
            b = Th(c, bQ, ki(c, eQ) === 13 ? 13 : -1) !== void 0 ? x(Gi(c, bQ, 13, eQ), QK, 2) : mb(Gi(c, cQ, 14, eQ) ? .g() ? ? [], [b]) ? x(x(Gi(c, cQ, 14, eQ), bQ, 2), QK, 2) : new QK;
            c = a.pubWin;
            var d = a.D.google_ad_client,
                e = J(a.na, 6),
                f = J(a.na, 20);
            b = new RK(c, d, b, e, f);
            b.i = !0;
            c = x(b.B, Nq, 1);
            if (b.i && (d = b.g, b.j && !yE(c) ? (e = new IK, e = Qh(e, 1,
                    Hg(1))) : e = null, e)) {
                e = Si(e);
                try {
                    d.localStorage.setItem("google_auto_fc_cmp_setting", e)
                } catch (g) {}
            }
            d = yE(c) && (b.j || b.A);
            c && d && qF(new rF(b.g, new $F(b.g, b.l), c, new kA(b.g)))
        }
        b = !Qj() && !Id();
        return !b || b && !jZ(a) ? kZ(a) : Promise.resolve()
    }

    function lZ(a, b, c = !1) {
        b = FO(a.K, b);
        const d = Uj() || BO(a.pubWin.top);
        if (!b || b.y === -12245933 || d.width === -12245933 || d.height === -12245933 || !d.height) return 0;
        let e = 0;
        try {
            const f = a.pubWin.top;
            e = DO(f.document, f).y
        } catch (f) {
            return 0
        }
        a = e + d.height;
        return b.y < e ? c ? 0 : (e - b.y) / d.height : b.y > a ? (b.y - a) / d.height : 0
    }

    function jZ(a) {
        return mZ(a) || nZ(a)
    }

    function mZ(a) {
        const b = a.D;
        if (!b.google_pause_ad_requests) return !1;
        const c = q.setTimeout(() => {
                hy("abg:cmppar", {
                    client: a.D.google_ad_client,
                    url: a.D.google_page_url
                })
            }, 1E4),
            d = gy(450, () => {
                b.google_pause_ad_requests = !1;
                q.clearTimeout(c);
                a.pubWin.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
                if (!jZ(a)) {
                    const e = kZ(a);
                    W.pa(1222, e)
                }
            });
        a.pubWin.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
        return !0
    }

    function nZ(a) {
        const b = a.pubWin.document,
            c = a.ea;
        if (TO(b) === 3) return WO(gy(332, () => {
            if (!oZ(a, pZ().visible, c)) {
                const g = kZ(a);
                W.pa(1222, g)
            }
        }), b), !0;
        const d = pZ();
        if (d.hidden < 0 && d.visible < 0) return !1;
        const e = UO(b);
        if (!e) return !1;
        if (!VO(b)) return oZ(a, d.visible, c);
        if (lZ(a, c) <= d.hidden) return !1;
        let f = gy(332, () => {
            if (!VO(b) && f) {
                Ib(b, e, f);
                if (!oZ(a, d.visible, c)) {
                    const g = kZ(a);
                    W.pa(1222, g)
                }
                f = null
            }
        });
        return Hb(b, e, f)
    }

    function pZ() {
        var a = V(Nr);
        const b = V(Or);
        return b === 3 && a === 6 ? (a = {
            hidden: 0,
            visible: 3
        }, q.IntersectionObserver || (a.visible = -1), ke() && (a.visible *= 2), a) : {
            hidden: 0,
            visible: q.IntersectionObserver ? ke() ? a : b : -1
        }
    }

    function oZ(a, b, c) {
        if (!c || b < 0) return !1;
        var d = a.D;
        if (!$n(d.google_reactive_ad_format) && (tP(d) || d.google_reactive_ads_config) || !EO(c) || lZ(a, c) <= b) return !1;
        var e = GE(),
            f = LE(e, 8, {});
        e = LE(e, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        const g = !!a.pubWin.google_apltlad;
        if (!f[d] && !e[d] && !g) return !1;
        f = new Promise(h => {
            const k = new q.IntersectionObserver((l, m) => {
                Ua(l, n => {
                    n.intersectionRatio <= 0 || (m.unobserve(n.target), h(void 0))
                })
            }, {
                rootMargin: `${b*100}%`
            });
            a.I = k;
            k.observe(c)
        });
        e = new Promise(h => {
            c.addEventListener("adsbygoogle-close-to-visible-event",
                () => {
                    h(void 0)
                })
        });
        ma(Promise, "any").call(Promise, [f, e]).then(() => {
            fy(294, () => {
                const h = kZ(a);
                W.pa(1222, h)
            })
        });
        return !0
    }

    function kZ(a) {
        fy(326, () => {
            var c = a.pubWin,
                d = a.K,
                e = a.na,
                f = a.wa;
            if (nk(a.D) === 1) {
                var g = U($t);
                if ((g || U(Yt)) && c === d) {
                    var h = new tj;
                    d = new uj;
                    var k = h.setCorrelator(Ye(c));
                    var l = vQ(c);
                    k = Qi(k, 5, l);
                    M(k, 2, 1);
                    h = A(d, 1, h);
                    k = new sj;
                    k = L(k, 10, !0);
                    l = U(Tt);
                    k = L(k, 8, l);
                    l = U(Ut);
                    k = L(k, 12, l);
                    l = U(Xt);
                    k = L(k, 7, l);
                    l = U(Wt);
                    k = L(k, 13, l);
                    A(h, 2, k);
                    c.google_rum_config = Ti(d);
                    e = J(e, 9) && g ? f.Dj : f.Ej;
                    te(c.document, e)
                } else Ek(ey)
            }
        });
        a.D.google_ad_channel = qZ(a, a.D.google_ad_channel);
        a.D.google_tag_partner = rZ(a, a.D.google_tag_partner);
        sZ(a);
        const b = a.D.google_start_time;
        typeof b === "number" && (Kn = b, a.D.google_start_time = null);
        dO(a);
        a.K && xP(a.K, gd(a.wa.oi, new Map(Object.entries(SO()))));
        PE() && dL({
            win: a.pubWin,
            webPropertyCode: a.D.google_ad_client,
            jb: gd(a.wa.jb, new Map(Object.entries(SO())))
        });
        tP(a.D) && (bL() && (a.D.google_adtest = a.D.google_adtest || "on"), a.D.google_pgb_reactive = a.D.google_pgb_reactive || 3);
        return tZ(a)
    }

    function qZ(a, b) {
        return (b ? [b] : []).concat(VE(a.pubWin).ad_channels || []).join("+")
    }

    function rZ(a, b) {
        return (b ? [b] : []).concat(VE(a.pubWin).tag_partners || []).join("+")
    }

    function uZ(a) {
        const b = ue("IFRAME");
        xe(a, (c, d) => {
            c != null && b.setAttribute(d, c)
        });
        return b
    }

    function vZ(a, b, c) {
        return a.D.google_reactive_ad_format === 9 && ge(a.ea, null, "fsi_container") ? (a.ea.appendChild(b), Promise.resolve(b)) : EP(a.wa.Zg, 525, d => {
            a.ea.appendChild(b);
            const e = xj(c, a.pubWin);
            d.createAdSlot(a.K, a.D, b, a.ea.parentElement, e);
            return b
        })
    }

    function wZ(a, b, c, d) {
        gF();
        O(hF).bd = a.D.google_page_url;
        bZ(a.pubWin, dj(cj(M(M(bj(new ej, $i(new aj, String(Ye(a.pubWin)))), 4, 1), 2, 1), K(a.na, 2)), d.g()));
        const e = a.K;
        if (a.D.google_acr)
            if (a.D.google_wrap_fullscreen_ad) {
                const h = a.D.google_acr;
                NY(a.pubWin, a.ea.parentElement, b, a.D.google_reactive_ad_format).then(h).catch(() => {
                    h(null)
                })
            } else a.D.google_acr(b);
        Hb(b, "load", () => {
            b && b.setAttribute("data-load-complete", !0);
            const h = e ? VE(e).enable_overlap_observer || !1 : !1;
            (a.D.ovlp || h) && e && e === a.pubWin && xZ(e, a, a.ea,
                b)
        });
        d = h => {
            h && a.j.push(() => {
                h.dispose()
            })
        };
        const f = yZ(a, b);
        NO(a.pubWin, a.g, b.contentWindow, a.j);
        !e || tP(a.D) && !HP(a.D) || (a.D.no_resize || d(new GR(e, b, a.ea)), d(new YQ(a, b)), d(e.IntersectionObserver ? null : new $Q(e, b, a.ea)), e.IntersectionObserver && d(QR(e, b, a.D, a.ea, gy(1225, () => {
            f();
            for (const h of a.j) h();
            a.j.length = 0
        }))));
        if (e) {
            d(SQ(e, b, a.g));
            if (U(us)) {
                var g = IR(e, b, a.g);
                g && d(g)
            }
            a.j.push(RP(e, a.D));
            O(WP).J(e);
            a.j.push(LQ(e, a.ea, b))
        }
        b && b.setAttribute("data-google-container-id", c);
        c = a.D.iaaso;
        c != null && (d =
            a.ea, g = d.parentElement, (g && su.test(g.className) ? g : d).setAttribute("data-auto-ad-size", c));
        b.setAttribute("tabindex", "0");
        b.setAttribute("title", "Advertisement");
        b.setAttribute("aria-label", "Advertisement");
        zZ(a);
        FU(a)
    }

    function yZ(a, b) {
        const c = a.pubWin,
            d = a.D.google_ad_client,
            e = OE();
        let f = null;
        const g = JM(c, "pvt", (h, k) => {
            typeof h.token === "string" && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), e[d].length > 100 && e[d].shift())
        });
        a.j.push(g);
        return () => {
            f && Array.isArray(e[d]) && (cb(e[d], f), e[d].length || delete e[d], f = null)
        }
    }

    function zZ(a) {
        const b = Qj(a.pubWin);
        if (b)
            if (b.container === "AMP-STICKY-AD") {
                const c = d => {
                    d.data === "fill_sticky" && b.renderStart && b.renderStart()
                };
                Hb(a.pubWin, "message", W.Ca(616, c));
                a.j.push(() => {
                    Ib(a.pubWin, "message", c)
                })
            } else b.renderStart && b.renderStart()
    }

    function xZ(a, b, c, d) {
        hN(new qN(a), c).then(e => {
            Ij(8, [e]);
            return e
        }).then(e => {
            const f = c.parentElement;
            (f && su.test(f.className) ? f : c).setAttribute("data-overlap-observer-io", String(e.Dg));
            return e
        }).then(e => {
            const f = b.D.armr || "",
                g = e.Fi || "",
                h = b.D.iaaso == null ? "" : Number(b.D.iaaso),
                k = Number(e.Dg),
                l = Xa(e.entries, E => `${E.ub}:${E.Qg}:${E.Rg}`),
                m = Number(e.tj.toFixed(2)),
                n = d.dataset.googleQueryId || "",
                p = m * e.Xb.width * e.Xb.height,
                r = `${e.hh.scrollX},${e.hh.scrollY}`,
                y = ok(e.target),
                D = [e.Xb.left, e.Xb.top, e.Xb.right,
                    e.Xb.bottom
                ].join();
            e = `${e.uh.width}x${e.uh.height}`;
            hy("ovlp", {
                adf: b.D.google_ad_dom_fingerprint,
                armr: f,
                client: b.D.google_ad_client,
                eid: vQ(b.D),
                et: g,
                fwrattr: b.D.google_full_width_responsive,
                iaaso: h,
                io: k,
                saldr: b.D.google_loader_used,
                oa: m,
                oe: l.join(","),
                qid: n,
                rafmt: b.D.google_responsive_auto_format,
                roa: p,
                slot: b.D.google_ad_slot,
                sp: r,
                tgt: y,
                tr: D,
                url: b.D.google_page_url,
                vp: e,
                pvc: Ye(a)
            }, 1)
        }).catch(e => {
            Ij(8, ["Error:", e.message, c]);
            hy("ovlp-err", {
                err: e.message
            }, 1)
        })
    }

    function AZ(a, b) {
        b.allow = b.allow && b.allow.length > 0 ? b.allow + ("; " + a) : a
    }

    function BZ(a, b, c) {
        var d = a.D,
            e = d.google_async_iframe_id;
        const f = d.google_ad_width,
            g = d.google_ad_height,
            h = IP(d);
        e = {
            id: e,
            name: e
        };
        var k = a.D,
            l = a.l;
        lQ("browsing-topics", a.pubWin.document) && JQ(c, k) && !U(It) && !GQ(l ? .label) && (e.browsingTopics = "true");
        e.style = h ? [`width:${f}px !IMPORTANT`, `height:${g}px !IMPORTANT`].join(";") : "left:0;position:absolute;top:0;border:0;" + `width:${f}px;` + `height:${g}px;`;
        k = Je();
        k["allow-top-navigation-by-user-activation"] && k["allow-popups-to-escape-sandbox"] && (h || (k = "=" + encodeURIComponent("1"),
            b = ne(b, "fsb" + k)), e.sandbox = Ie().join(" "));
        d.google_video_play_muted === !1 && AZ("autoplay", e);
        k = b;
        k.length > 61440 && (k = k.substring(0, 61432), k = k.replace(/%\w?$/, ""), k = k.replace(/&[^=]*=?$/, ""), k += "&trunc=1");
        k !== b && (l = b.lastIndexOf("&", 61432), l === -1 && (l = b.lastIndexOf("?", 61432)), hy("trn", {
            ol: b.length,
            tr: l === -1 ? "" : b.substring(l + 1),
            url: b
        }, .01));
        b = k;
        f != null && (e.width = String(f));
        g != null && (e.height = String(g));
        e.frameborder = "0";
        e.marginwidth = "0";
        e.marginheight = "0";
        e.vspace = "0";
        e.hspace = "0";
        e.allowtransparency =
            "true";
        e.scrolling = "no";
        d.dash && (e.srcdoc = d.dash);
        kQ("attribution-reporting", a.pubWin.document) && AZ("attribution-reporting", e);
        kQ("run-ad-auction", a.pubWin.document) && AZ("run-ad-auction", e);
        U(zt) && (d = a.pubWin, d.credentialless !== void 0 && (U(At) || d.crossOriginIsolated) && (e.credentialless = "true"));
        if (h) e.src = b, e = uZ(e), a = vZ(a, e, c);
        else {
            c = {};
            c.dtd = yQ((new Date).getTime(), Kn);
            c = kk(c, b);
            e.src = c;
            c = a.pubWin;
            c = c == c.top;
            e = uZ(e);
            c && a.j.push(Wj(a.pubWin, e));
            a.ea.style.visibility = "visible";
            for (a = a.ea; c = a.firstChild;) a.removeChild(c);
            a.appendChild(e);
            a = Promise.resolve(e)
        }
        return a
    }
    async function CZ(a) {
        var b = a.D,
            c = a.pubWin;
        const d = a.g;
        DZ(a);
        d.g() && MO(new LO(a.pubWin), a.g, a.pubWin.location.hostname);
        var e = xj(d, a.pubWin);
        if (!d.g() && !a.F) return hy("afc_noc_req", {
            client: a.D.google_ad_client,
            isGdprCountry: J(a.na, 6).toString()
        }, V(Lr)), Promise.resolve();
        var f = EZ(a.wa, d);
        f && document.documentElement.appendChild(f);
        U(Ct) && d.g() && (a.l = await TE());
        a.G = HQ(a.pubWin, d);
        uQ(a.pubWin, d);
        if (f = a.D.google_reactive_ads_config) {
            DP(a.K, f);
            const g = xj(d);
            JP(f, a, g);
            f = f.page_level_pubvars;
            Da(f) && Pb(a.D,
                f)
        }
        f = lQ("shared-storage", a.pubWin.document);
        a.G && d.g() && f && !U(yt) && !LE(GE(), 34, !1) && (ME(GE(), 34, !0), f = a.G.then(g => {
            g({
                message: "goog:spam:client_age",
                pvsid: Ye(a.pubWin)
            })
        }), W.pa(1069, f));
        await IQ(a, a.pubWin, d, a.D, a.G, a.l);
        await a.B ? .si;
        f = "";
        IP(b) ? (f = (d.g() ? a.wa.Ah : a.wa.zh).toString() + "#" + (encodeURIComponent("RS-" + b.google_reactive_sra_index + "-") + "&" + jk({
            adk: b.google_ad_unit_key,
            client: b.google_ad_client,
            fa: b.google_reactive_ad_format
        })), kV(b, GE()), FZ(b)) : (b.google_pgb_reactive === 5 && b.google_reactive_ads_config ||
            !uP(b) || sP(c, b, e)) && FZ(b) && (f = bV(a, d));
        Ij(2, [b, f]);
        if (!f) return Promise.resolve();
        b.google_async_iframe_id || mk(c);
        e = nk(b);
        b = a.pubWin === a.K ? "a!" + e.toString(36) : `${e.toString(36)}.${Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)}`;
        c = lZ(a, a.ea, !0) > 0;
        e = {
            ifi: e,
            uci: b
        };
        c && (c = GE(), e.btvi = LE(c, 21, 1), NE(c, 21));
        f = kk(e, f);
        c = BZ(a, f, d);
        a.D.rpe && ER(a.pubWin, a.ea, {
            height: a.D.google_ad_height,
            xf: "force",
            Rc: !0,
            nf: !0,
            he: a.D.google_ad_client
        });
        c = await c;
        try {
            wZ(a, c, b, d)
        } catch (g) {
            W.ba(223, g, void 0, void 0)
        }
    }

    function GZ(a) {
        var b = Ke(q.top, "googlefcPresent");
        q.googlefc && !b && hy("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    }

    function HZ(a, b) {
        return JF(a, b === ".google.cn") ? KF(a) : Promise.resolve(null)
    }

    function IZ(a) {
        const b = V(Jr);
        if (b <= 0) return null;
        const c = xk(),
            d = $Y(a.pubWin);
        if (!d) return null;
        a.C = "0";
        return Promise.race([d, $e(b, "0")]).then(e => {
            hy("adsense_paw", {
                time: xk() - c
            });
            e ? .length > 1E4 ? W.ba(809, Error(`ML:${e.length}`), void 0, void 0) : a.C = e
        }).catch(e => {
            W.ba(809, e, void 0, void 0)
        })
    }

    function DZ(a) {
        var b = a.pubWin;
        const c = a.ea;
        var d = a.D;
        const e = a.Wa,
            f = V(Qt);
        d = !$n(d.google_reactive_ad_format) && (tP(d) || d.google_reactive_ads_config);
        if (!(a.B ? .Qe || f <= 0 || se(b) || !q.IntersectionObserver || d)) {
            a.B = {};
            var g = V(Rt),
                h = new wn(e),
                k = xk();
            b = new Promise(l => {
                let m = 0;
                const n = a.B,
                    p = new q.IntersectionObserver(gy(1236, r => {
                        if (r = r.find(y => y.target === c)) on(h.C.g.g.g.g, {
                            Qj: xk() - k,
                            Vj: ++m
                        }), n.bj = r.isIntersecting && r.intersectionRatio >= g, l()
                    }), {
                        threshold: [g]
                    });
                p.observe(c);
                n.Qe = p
            });
            a.B.si = Promise.race([b, $e(f,
                null)]).then(l => {
                var m = xk() - k,
                    n = l === null ? "TIMEOUT" : "OK";
                l = pn;
                var p = h.C.g.g.g.i.Z,
                    r = Zk("xR0Czf"),
                    y = new Vk;
                n = hi(y, 1, Wk, bh(n));
                r = qi(r, 4, Vk, n);
                n = new Xk;
                m = hi(n, 4, Yk, Cg(m));
                m = A(r, 3, m);
                l(p, m)
            })
        }
    }

    function JZ(a) {
        const b = xk();
        return Promise.race([fy(832, () => dZ(a)), $e(200)]).then(c => {
            hy("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: xk() - b,
                tms: 200
            });
            return c ? .qc
        })
    }
    async function KZ(a) {
        const b = xk(),
            c = a.na;
        iF(f => {
            if (Ei(f, 1) === 0) {
                var g = !!J(c, 6);
                f = L(f, 2, g);
                g = !!J(c, 20);
                f = L(f, 6, g);
                M(f, 1, 1)
            }
        });
        zM(a.pubWin);
        GZ(a.D.google_ad_client);
        iF(f => {
            Ei(f, 1) === 1 && M(f, 1, 2)
        });
        const d = new MF(a.pubWin);
        await HZ(d, K(c, 8));
        iF(f => {
            Ei(f, 1) === 2 && (f = L(f, 3, !0), M(f, 1, 3))
        });
        await AO(a, {
            Ka: J(c, 6),
            cj: J(c, 25)
        });
        const e = xk();
        iF(f => {
            if (Ei(f, 1) === 3) {
                f = L(f, 3, e - b > 500);
                var g = !!a.g ? .A();
                f = L(f, 4, g);
                g = !!a.g ? .g();
                f = L(f, 5, g);
                g = !!a.g ? .j();
                f = L(f, 7, g);
                g = !!a.g ? .l();
                f = L(f, 8, g);
                M(f, 1, 4)
            }
        })
    }
    async function LZ(a) {
        const b = IZ(a),
            c = fy(868, () => JZ(a.pubWin));
        await KZ(a);
        await b;
        a.qc = await c || "";
        await CZ(a)
    }

    function tZ(a) {
        af(a.pubWin) !== a.pubWin && (a.i |= 4);
        TO(a.pubWin.document) === 3 && (a.i |= 32);
        var b;
        if (b = a.K) {
            b = a.K;
            const c = Un(b);
            b = !(Yn(b).scrollWidth <= c)
        }
        b && (a.i |= 1024);
        a.pubWin.Prototype ? .Version && (a.i |= 16384);
        a.D.google_loader_features_used && (a.i |= a.D.google_loader_features_used);
        return LZ(a)
    }

    function FZ(a) {
        const b = GE(),
            c = a.google_ad_section;
        tP(a) && NE(b, 15);
        if (pk(a)) {
            if (NE(b, 5) > 100) return !1
        } else if (NE(b, 6) - LE(b, 15, 0) > 100 && c === "") return !1;
        return !0
    }

    function EZ(a, b) {
        a: {
            var c = [q.top];
            var d = [];
            let f = 0,
                g;
            for (; g = c[f++];) {
                d.push(g);
                try {
                    if (g.frames)
                        for (let h = 0; h < g.frames.length && c.length < 1024; ++h) c.push(g.frames[h])
                } catch {}
            }
            c = d;
            for (d = 0; d < c.length; d++) try {
                var e = c[d].frames.google_esf;
                if (e) {
                    qj = e;
                    break a
                }
            } catch (h) {}
            qj = null
        }
        if (qj) return null;e = ue("IFRAME");e.id = "google_esf";e.name = "google_esf";a = b.g() ? a.Ah : a.zh;e.src = dc(a).toString();e.style.display = "none";
        return e
    }

    function iZ(a) {
        U(Dr) && QE() && q.setTimeout(gy(1244, () => void WN(a.K || a.pubWin, {
            Ka: J(a.na, 6)
        })), 1E3)
    }

    function sZ(a) {
        const b = a.K;
        if (b && !VE(b).ads_density_stats_processed && !Qj(b) && (VE(b).ads_density_stats_processed = !0, U(ws) || we() < .01)) {
            const c = () => {
                if (b) {
                    var d = gJ(bJ(b), a.D.google_ad_client, b.location.hostname, vQ(a.D).split(","));
                    hy("ama_stats", d, 1)
                }
            };
            Ze(b, () => {
                q.setTimeout(c, 1E3)
            })
        }
    };
    (function(a, b, c) {
        fy(843, () => {
            if (!q.google_sa_impl) {
                var d = new An(b);
                try {
                    ig(k => {
                        var l = new fn;
                        var m = new en;
                        try {
                            var n = Ye(window);
                            Oi(m, 1, n)
                        } catch (D) {}
                        try {
                            var p = O(Dn).g();
                            di(m, 2, p, Jg)
                        } catch (D) {}
                        try {
                            Qi(m, 3, window.document.URL)
                        } catch (D) {}
                        l = A(l, 2, m);
                        m = new dn;
                        m = M(m, 1, 1192);
                        try {
                            var r = sg(k ? .name) ? k.name : "Unknown error";
                            Qi(m, 2, r)
                        } catch (D) {}
                        try {
                            var y = sg(k ? .message) ? k.message : `Caught ${k}`;
                            Qi(m, 3, y)
                        } catch (D) {}
                        try {
                            const D = sg(k ? .stack) ? k.stack : Error().stack;
                            D && di(m, 4, D.split(/\n\s*/), ah)
                        } catch (D) {}
                        k = A(l, 1, m);
                        r = new cn;
                        try {
                            Qi(r, 1, CE())
                        } catch {}
                        B(k, 6, gn, r);
                        Oi(k, 5, 1);
                        rn(d, k)
                    })
                } catch (k) {}
                var e = new JV;
                U(Bt) && (e = WY());
                var f = YY(a);
                VY(W, K(f, 2));
                hQ(J(f, 6));
                Ij(16, [3, Ti(f)]);
                var g = UY({
                        bg: b,
                        ih: K(f, 2)
                    }),
                    h = c(g, f, Bi(li(e, IV), 1));
                q.google_sa_impl = k => fZ({
                    na: f,
                    wa: h,
                    Wa: g,
                    slot: k
                });
                rQ(jQ(q));
                q.google_process_slots ? .();
                e = (q.Prototype || {}).Version;
                e != null && hy("prtpjs", {
                    version: e
                })
            }
        })
    })(XY, CE(), function(a, b, c) {
        c = U(Bt) ? c : Bi(b, 1);
        c = c > 2012 ? `_fy${c}` : "";
        const d = K(b, 3);
        b = K(b, 2);
        return {
            Ej: fd `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum${c}.js`,
            Dj: fd `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum_debug${c}.js`,
            Zg: fd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/reactive_library${c}.js`,
            oi: fd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/debug_card_library${c}.js`,
            to: fd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${c}.js`,
            jo: fd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/gallerify${c}.js`,
            jb: fd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/autogames${c}.js`,
            Ah: fd `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup${c}.html`,
            zh: fd `https://pagead2.googlesyndication.com/pagead/html/${b}/${d}/zrt_lookup${c}.html`
        }
    });
}).call(this, "[2021,\"r20240814\",\"r20110914\",null,null,null,null,\".google.com.pk\"]");